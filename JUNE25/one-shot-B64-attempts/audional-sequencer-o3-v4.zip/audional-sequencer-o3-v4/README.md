# Audional Sequencer - Framework Overview & Developer Guide

This document provides an overview of the Audional Sequencer's architecture, key modules, data flow, and conventions. It is intended as a reference guide for ongoing and future development.

## Table of Contents

1.  [High-Level Overview](#high-level-overview)
2.  [Core Principles](#core-principles)
3.  [Project Structure](#project-structure)
4.  [Key Modules & Responsibilities](#key-modules--responsibilities)
    *   [State Management (`state.js`)](#state-management-statejs)
    *   [Application Core (`app.js`)](#application-core-appjs)
    *   [Audio Engine Subsystem](#audio-engine-subsystem)
        *   [`audioCore.js`](#audiocorejs)
        *   [`playbackEngine.js`](#playbackenginejs)
        *   [`audioEngine.js` (Facade)](#audioenginejs-facade)
    *   [UI System](#ui-system)
        *   [`ui.js` (Orchestrator)](#uijs-orchestrator)
        *   [`channelManager.js`](#channelmanagerjs)
        *   [`uiState.js`](#uistatejs)
        *   [`uiUtils.js`](#uiutilsjs)
        *   [`uiAnimator.js`](#uianimatorjs)
    *   [Waveform Display (`waveformDisplay.js`)](#waveform-display-waveformdisplayjs)
    *   [Utilities](#utilities)
        *   [`utils.js`](#utilsjs)
        *   [`fileTypeHandler.js`](#filetypehandlerjs)
    *   [Sample Data (`samples.js`)](#sample-data-samplesjs)
5.  [Data Flow & Interaction Patterns](#data-flow--interaction-patterns)
    *   [State Updates & Reactions](#state-updates--reactions)
    *   [UI Event Handling](#ui-event-handling)
    *   [Audio Playback Scheduling](#audio-playback-scheduling)
    *   [Sample Loading](#sample-loading)
6.  [Development Guidelines & Conventions](#development-guidelines--conventions)
7.  [Future Development Considerations](#future-development-considerations)

---

## 1. High-Level Overview

The Audional Sequencer is a web-based digital audio workstation (DAW) focused on step sequencing and sample manipulation. It allows users to load audio samples, arrange them in a 64-step sequencer, apply various audio effects, and control playback parameters like BPM, volume, mute, and solo. The project can be saved and loaded.

The architecture emphasizes a clear separation of concerns, with distinct modules for state management, audio processing, UI rendering, and utility functions.

---

## 2. Core Principles

*   **Single Source of Truth:** All application data (project settings, channel configurations, playback status) is managed by a central `State` module.
*   **Reactive Updates:** UI and other components subscribe to state changes and react accordingly, rather than directly manipulating each other.
*   **Modularity:** Functionality is broken down into smaller, focused modules with clear responsibilities.
*   **Immutability (for State Updates):** When updating the state, new objects/arrays are created rather than mutating existing ones directly, which helps in tracking changes and can simplify debugging.
*   **Separation of Concerns:**
    *   Audio logic is distinct from UI logic.
    *   Data management is separate from its presentation.

---

## 3. Project Structure

The primary JavaScript code resides in the `js/` directory (or root, depending on setup).
Use code with caution.
Markdown
/
├── app.js # Main application setup, global event listeners, project save/load
├── state.js # Centralized application state management
│
├── audioEngine.js # Facade for the audio engine subsystem
├── audioCore.js # Core Web Audio API setup, channel gain nodes, global audio state sync
├── playbackEngine.js # Sequencer logic, step scheduling, transport controls (play/stop)
│
├── ui.js # Main UI orchestrator, global UI elements, subscribes to state for rendering
├── channelManager.js # Manages rendering, event wiring, and updates for individual channel strips
├── uiState.js # Stores UI-specific state (playheads, zoom states)
├── uiUtils.js # Utility functions specifically for the UI
├── uiAnimator.js # Handles requestAnimationFrame loop for UI animations (e.g., transport playhead)
├── waveformDisplay.js # Renders audio waveforms to canvas elements
│
├── utils.js # General utility functions (sample loading, URL resolution)
├── fileTypeHandler.js # Logic for extracting audio from various file types/formats
├── samples.js # Predefined list of sample IDs and labels
│
└── index.html # Main HTML file
└── style.css # Stylesheets
---

## 4. Key Modules & Responsibilities

### State Management (`state.js`)

*   **Purpose:** The single source of truth for the entire application. Holds all mutable data like project name, BPM, channel configurations, playback status, current step, etc.
*   **Key Exports:**
    *   `State.get()`: Returns the current state object.
    *   `State.update(patch)`: Updates the global state with the given patch object.
    *   `State.updateChannel(index, patch)`: Updates a specific channel's state.
    *   `State.addChannel(channelObject)`: Adds a new channel.
    *   `State.subscribe(listenerFn)`: Allows other modules to listen for state changes. The `listenerFn` receives `(newState, oldState)`.
*   **Interaction:** Core to the application. Almost all significant actions result in a state update, which then triggers reactions in subscribed modules (UI, audio engine).

### Application Core (`app.js`)

*   **Purpose:** Initializes the application, sets up global event listeners (play/stop buttons, BPM input, add channel, save/load project), and orchestrates the initial setup of core components.
*   **Key Functions:**
    *   `makeChannel(index)`: Factory function to create a default channel object.
    *   Event listeners for global controls (save, load, play, stop, BPM).
    *   Project save/load logic, including sanitizing channel data (removing buffers before saving).
    *   `createReversedBuffer()`: Utility to create a reversed AudioBuffer (used by UI and load project).
*   **Interaction:** Bridges user interactions on global controls to `State` updates or `audioEngine` calls. Manages the overall application lifecycle regarding project data.

### Audio Engine Subsystem

#### `audioCore.js`

*   **Purpose:** Manages the core Web Audio API `AudioContext` and the basic audio graph structure for each channel (specifically master gain nodes). It also listens to `State` changes for volume, mute, and solo to update these gain nodes.
*   **Key Exports:**
    *   `ctx`: The global `AudioContext` instance.
    *   `channelGainNodes`: Array of `GainNode` instances, one per channel, connected to `ctx.destination`.
    *   `EQ_BANDS_DEFS`: Definitions for EQ band parameters.
*   **Interaction:** Provides the `AudioContext` for all audio operations. Automatically syncs channel gain levels based on `State` (volume, mute, solo). `playbackEngine.js` uses `ctx` and `channelGainNodes`.

#### `playbackEngine.js`

*   **Purpose:** Handles the sequencing logic, scheduling of audio events using the Web Audio API, and transport controls (start/stop).
*   **Key Exports:**
    *   `start()`: Initiates playback.
    *   `stop()`: Stops playback and clears scheduled sounds.
    *   `playStartTime`: The `AudioContext.currentTime` when playback last started.
*   **Interaction:** Reads channel data (steps, buffer, FX settings) from `State` to schedule sounds. Uses `audioCore.ctx` and `audioCore.channelGainNodes` to create and connect audio nodes for playback. Updates `State` with `currentStep` and `playing` status.

#### `audioEngine.js` (Facade)

*   **Purpose:** Acts as a simplified public interface (facade) for the audio engine subsystem. It re-exports key functionalities from `audioCore.js` and `playbackEngine.js`.
*   **Key Exports:**
    *   `ctx` (from `audioCore.js`)
    *   `start()` (from `playbackEngine.js`)
    *   `stop()` (from `playbackEngine.js`)
    *   `playStartTime` (from `playbackEngine.js`)
*   **Interaction:** Modules like `app.js` and `ui.js` interact with the audio system primarily through this facade, simplifying their imports and decoupling them from the internal structure of the audio engine.

### UI System

#### `ui.js` (Orchestrator)

*   **Purpose:** Initializes the overall UI, manages global UI elements (project name, BPM input display), and subscribes to `State` to trigger re-rendering of the UI components.
*   **Key Exports:**
    *   `init()`: Sets up global UI elements, event listeners, and subscribes to `State`.
*   **Key Functions:**
    *   `renderGlobalUI()`: Updates global UI parts like project name and BPM display.
    *   `render()`: The main render loop callback, invoked on state changes. It manages the creation, update, or removal of channel strips in the DOM.
*   **Interaction:** Listens to `State`. Delegates channel-specific rendering and event handling to `channelManager.js`. Coordinates with `uiAnimator.js` for animations.

#### `channelManager.js`

*   **Purpose:** Responsible for creating, updating, and wiring event listeners for individual channel strips in the UI. This includes channel name, faders, sample loading controls, step sequencer grid, waveform display interaction, and FX controls.
*   **Key Exports:**
    *   `wireChannel(element, index)`: Sets up all event listeners for a newly created channel element.
    *   `updateChannelUI(element, channelData, playheadStep, index)`: Updates an existing channel element's display based on new channel data and global playback state.
*   **Interaction:** Called by `ui.js` during the render process. Reads channel-specific data from `State` (via `channelData` prop). Updates `State` in response to user interactions within a channel (e.g., toggling a step, changing a fader). Uses `renderWaveformToCanvas` for waveform visuals.

#### `uiState.js`

*   **Purpose:** Stores UI-specific, mutable state that is shared across different UI modules but might not belong in the global application `State`. This includes things like playhead positions for waveform previews and channel zoom states.
*   **Key Exports:**
    *   `previewPlayheads`: Map of `channelIndex -> previewPlayheadRatio`.
    *   `mainTransportPlayheadRatios`: Map of `channelIndex -> mainPlayheadRatio`.
    *   `channelZoomStates`: Array of booleans indicating zoom state per channel.
    *   `MIN_TRIM_SEPARATION`: Constant for minimum trim handle distance.
*   **Interaction:** Used by `channelManager.js` and `uiAnimator.js` to manage and display visual playheads and zoom behavior.

#### `uiUtils.js`

*   **Purpose:** Contains stateless utility functions used by various UI modules.
*   **Key Exports:**
    *   `clamp()`, `debounce()`, `formatHz()`, `setSlider()`, `updateHandles()`, `auditionSample()`.
*   **Interaction:** Imported and used by `ui.js`, `channelManager.js`, etc., for common UI-related tasks.

#### `uiAnimator.js`

*   **Purpose:** Manages the `requestAnimationFrame` loop for UI animations, specifically for updating the main transport playhead position on channel waveforms during playback.
*   **Key Exports:**
    *   `animateTransport()`: The function called in the animation loop.
*   **Interaction:** Reads playback information from `State` (via `channel.activePlayback...` properties) and `ctx.currentTime` to calculate playhead positions. Calls `renderWaveformToCanvas` to redraw waveforms with updated playheads.

### Waveform Display (`waveformDisplay.js`)

*   **Purpose:** Dedicated module for rendering audio waveforms, trim regions, fades, and playheads onto HTML5 Canvas elements.
*   **Key Exports:**
    *   `renderWaveformToCanvas(canvas, buffer, trimStart, trimEnd, options)`: The main drawing function.
*   **Interaction:** Used by `channelManager.js` (for initial render and updates due to trim/zoom changes) and `uiAnimator.js` (for playhead updates during transport).

### Utilities

#### `utils.js`

*   **Purpose:** General utility functions, primarily focused on sample loading and URL/ID resolution for Ordinals.
*   **Key Exports:**
    *   `loadSample(source)`: Asynchronously loads an audio sample from a File object or URL, decodes it, and returns `{ buffer: AudioBuffer, imageData: string|null }`.
    *   `resolveOrdinalURL(rawUrl)`: Converts various Ordinal ID formats or URLs into a standard content URL.
    *   `extractOrdinalId(str)`: Extracts an Ordinal ID from a string.
*   **Interaction:** `loadSample` is used by `channelManager.js` (for user-loaded samples) and `app.js` (for reloading samples when a project is loaded).

#### `fileTypeHandler.js`

*   **Purpose:** Contains logic to extract audio data (typically base64 encoded) from various file types like HTML, JSON, or plain text, which might embed audio.
*   **Key Exports:**
    *   `extractAudioAndImage(response)`: Processes a Fetch API `Response` object to find and return an `ArrayBuffer` for audio and an image data URL if present.
*   **Interaction:** Used by `utils.js` within the `loadSample` function when dealing with non-direct audio file types.

### Sample Data (`samples.js`)

*   **Purpose:** Provides a predefined list of Audinal sample IDs and their descriptive labels for use in the UI's sample picker.
*   **Key Exports:**
    *   `audionalIDs`: An array of objects `{ id, label }`.
*   **Interaction:** Used by `channelManager.js` to populate the preset sample dropdown.

---

## 5. Data Flow & Interaction Patterns

### State Updates & Reactions

1.  **Trigger:** User interaction (e.g., clicking a step, dragging a fader) or an internal process (e.g., scheduler advancing a step).
2.  **Action:** The relevant event handler (in `app.js` or `channelManager.js`) calls `State.update()` or `State.updateChannel()`.
3.  **Notification:** `State` notifies all subscribed listeners (e.g., in `ui.js`, `audioCore.js`).
4.  **Reaction:**
    *   `ui.js`: Receives the new state and triggers a re-render of affected UI components.
    *   `audioCore.js`: Adjusts `GainNode` parameters (volume, mute, solo) if relevant properties changed.
    *   Other modules might react if they subscribe to state.

### UI Event Handling

1.  User interacts with a UI element within a channel (e.g., toggles a step).
2.  The event listener (wired by `channelManager.js`) is triggered.
3.  The listener calls `State.updateChannel()` with the new data for that specific channel property.
4.  `State` change propagates, leading to UI re-render (showing the step as 'on') and potential audio engine adjustments.

### Audio Playback Scheduling

1.  User clicks "Play" -> `app.js` calls `playbackEngine.start()`.
2.  `playbackEngine.start()`:
    *   Resumes `AudioContext`.
    *   Sets `State.playing = true`.
    *   Initializes `internalPlayStartTime`, `nextStep`.
    *   Starts a `setInterval` timer for the `scheduler()`.
3.  `scheduler()` (called periodically):
    *   Calculates time for upcoming 16th notes based on BPM and `AudioContext.currentTime`.
    *   For each step to be scheduled within the `lookAhead` window:
        *   Reads channel data (steps, buffer, FX, trim, pitch, etc.) from `State.get()`.
        *   If a channel has a step active and a buffer loaded:
            *   Creates `AudioBufferSourceNode` and necessary FX nodes (filters, EQ) using `audioCore.ctx`.
            *   Configures nodes based on channel settings.
            *   Connects nodes to the channel's master gain node (`audioCore.channelGainNodes[i]`).
            *   Schedules `source.start(scheduledEventTime, offset, duration)`.
            *   Updates `channel.activePlayback...` properties in `State` for UI animation.
        *   Updates `State.currentStep`.
    *   Advances `nextStep`.
4.  When "Stop" is clicked, `playbackEngine.stop()` clears the timer, stops all scheduled sources, and resets playback state.

### Sample Loading

1.  User selects a file or enters a URL in a channel strip.
2.  Event listener in `channelManager.js` is triggered.
3.  `utils.loadSample(source)` is called.
    *   `loadSample` fetches/reads the file.
    *   If not a direct audio file, it may use `fileTypeHandler.extractAudioAndImage`.
    *   Decodes the `ArrayBuffer` into an `AudioBuffer` using `audioCore.ctx.decodeAudioData()`.
4.  On success, `channelManager.js` calls `State.updateChannel()` with the new `buffer`, `reversedBuffer` (if applicable), `src`, and resets trim.
5.  `State` change triggers UI update (waveform display).

---

## 6. Development Guidelines & Conventions

*   **State First:** Always aim to modify application data by calling `State.update()` or its variants. Avoid direct manipulation of data outside of `State` if that data is meant to be persistent or reactive.
*   **Subscribe, Don't Poll:** Use `State.subscribe()` to react to changes. Avoid repeatedly calling `State.get()` in a loop to check for changes.
*   **Modularity:**
    *   Keep modules focused on a single responsibility.
    *   Minimize direct dependencies between modules where possible. Use `State` as the intermediary.
    *   When refactoring, consider if functionality can be extracted into a new, more specialized module.
*   **Immutability in State Updates:** When providing a `patch` to `State.update()`, ensure that if you are modifying nested objects or arrays, you are creating new instances of those objects/arrays rather than mutating them in place.
    *   Example: `State.updateChannel(i, { steps: [...newStepsArray] });`
*   **UI Updates:**
    *   Primary UI updates should be driven by `State` subscriptions and the `render` functions.
    *   Direct DOM manipulation is acceptable for initial event listener wiring in `wireChannel` or for highly localized, non-state-driven animations if necessary (though `requestAnimationFrame` in `uiAnimator.js` is preferred for state-driven animations).
*   **Error Handling:** Implement `try...catch` blocks for operations that can fail (e.g., file loading, API calls, audio decoding) and provide user feedback (e.g., `alert()`, console messages).
*   **Comments:** Write clear and concise comments, especially for complex logic, public APIs of modules, and non-obvious code sections. JSDoc-style comments are encouraged for functions.
*   **Asynchronous Operations:** Use `async/await` for cleaner asynchronous code.
*   **Performance:**
    *   Be mindful of operations within the `scheduler` loop; keep them efficient.
    *   Debounce frequent UI events (e.g., slider inputs) before updating state if updates are expensive.
    *   Optimize canvas rendering in `waveformDisplay.js` and `uiAnimator.js`.
*   **Naming Conventions:** Follow standard JavaScript naming conventions (camelCase for variables and functions, PascalCase for classes/constructors if any).

---

## 7. Future Development Considerations

*   **Testing:** Implement unit and integration tests for core modules (State, audio processing, utilities).
*   **Advanced Effects:** Consider a more robust FX chain system per channel.
*   **MIDI Input/Output:** Allow control via MIDI controllers or outputting sequences as MIDI.
*   **Performance Optimization:** Profile and optimize CPU-intensive parts, especially audio scheduling and UI rendering with many channels.
*   **UI/UX Enhancements:** Improve visual feedback, add more sophisticated controls, and refine the overall user experience.
*   **WebAssembly (WASM):** For performance-critical audio processing tasks, consider using WASM.
*   **TypeScript:** Migrating to TypeScript could improve code maintainability and reduce runtime errors.

---

This guide should provide a solid foundation for understanding and contributing to the Audional Sequencer project. Remember to keep it updated as the framework evolves.