import State from './state.js';

export const ctx = new (window.AudioContext || window.webkitAudioContext)();

// Transport info for UI (imported by ui.js)
export let playStartTime = 0;

let startTime = 0;
let nextStep = 0;
let timer = null;
const lookAhead = 0.1;
const tickMs = 25;

let scheduledSources = []; // Array of all currently playing buffer sources

function scheduleStep(stepIdx, time, channels) {
  channels.forEach(ch => {
    if (!ch.buffer || !ch.steps[stepIdx]) return;
    const src = ctx.createBufferSource();
    src.buffer = ch.buffer;
    src.playbackRate.value = ch.pitch || 1;
    const start = ch.buffer.duration * (ch.trimStart ?? 0);
    const end = ch.buffer.duration * (ch.trimEnd ?? 1);
    const gain = ctx.createGain();
    gain.gain.value = ch.mute ? 0 : (ch.volume ?? 0.8);
    src.connect(gain).connect(ctx.destination);
    src.start(time, start, Math.max(end - start, 0.001));
    scheduledSources.push(src);
    src.onended = () => {
      scheduledSources = scheduledSources.filter(node => node !== src);
      try { gain.disconnect(); } catch {}
      try { src.disconnect(); } catch {}
    };
  });
}

function scheduler() {
  const s = State.get();
  const spb = 60 / s.bpm;
  const sp16 = spb / 4;
  const now = ctx.currentTime;
  while (true) {
    const stepTime = startTime + nextStep * sp16;
    if (stepTime > now + lookAhead) break;
    scheduleStep(nextStep % 64, stepTime, s.channels);
    if (typeof State.update === "function")
      State.update({ currentStep: nextStep % 64 });
    nextStep++;
  }
}

export function start() {
  if (timer) return;
  ctx.resume();
  const s = State.get();
  startTime = ctx.currentTime + 0.03;
  playStartTime = startTime; // Exported for UI transport animation
  nextStep = 0;
  State.update({ playing: true, currentStep: 0 });
  scheduler();
  timer = setInterval(scheduler, tickMs);
}

export function stop() {
  if (!timer) return;
  clearInterval(timer);
  timer = null;
  State.update({ playing: false, currentStep: 0 });
  // --- Immediately stop all scheduled/playing sounds ---
  scheduledSources.forEach(src => {
    try { src.stop(0); } catch {}
    try { src.disconnect(); } catch {}
  });
  scheduledSources = [];
  playStartTime = 0;
  startTime = 0;
  nextStep = 0;
}
