/**
 * Audio Visualizer Components for Enhanced Interactive Story Experience
 */

class AudioVisualizer {
    constructor(container, options = {}) {
        this.container = container;
        this.options = Object.assign({
            particleCount: 100,
            particleColor: '#00e5ff',
            particleSize: 2,
            particleSpeed: 1,
            responsive: true,
            mode: 'standard' // standard, saga, epic
        }, options);
        
        this.canvas = document.createElement('canvas');
        this.canvas.className = 'visualizer';
        this.ctx = this.canvas.getContext('2d');
        this.container.appendChild(this.canvas);
        
        this.particles = [];
        this.audioData = null;
        this.isActive = false;
        this.animationFrame = null;
        
        this.resize();
        if (this.options.responsive) {
            window.addEventListener('resize', () => this.resize());
        }
        
        this.init();
    }
    
    init() {
        this.createParticles();
    }
    
    resize() {
        const rect = this.container.getBoundingClientRect();
        this.width = rect.width;
        this.height = rect.height;
        this.canvas.width = this.width;
        this.canvas.height = this.height;
    }
    
    createParticles() {
        this.particles = [];
        const count = this.options.mode === 'epic' ? 
                      this.options.particleCount * 2 : 
                      this.options.particleCount;
                      
        for (let i = 0; i < count; i++) {
            this.particles.push(this.createParticle());
        }
    }
    
    createParticle() {
        return {
            x: Math.random() * this.width,
            y: Math.random() * this.height,
            size: Math.random() * this.options.particleSize + 1,
            speedX: (Math.random() - 0.5) * this.options.particleSpeed,
            speedY: (Math.random() - 0.5) * this.options.particleSpeed,
            color: this.getParticleColor(),
            alpha: Math.random() * 0.8 + 0.2
        };
    }
    
    getParticleColor() {
        switch(this.options.mode) {
            case 'saga':
                return `hsl(${280 + Math.random() * 40}, 100%, 70%)`;
            case 'epic':
                return `hsl(${40 + Math.random() * 20}, 100%, 60%)`;
            default:
                return this.options.particleColor;
        }
    }
    
    updateAudioData(audioData) {
        this.audioData = audioData;
    }
    
    start() {
        if (this.isActive) return;
        this.isActive = true;
        this.animate();
    }
    
    stop() {
        this.isActive = false;
        if (this.animationFrame) {
            cancelAnimationFrame(this.animationFrame);
            this.animationFrame = null;
        }
    }
    
    animate() {
        if (!this.isActive) return;
        
        this.ctx.clearRect(0, 0, this.width, this.height);
        this.updateParticles();
        this.drawParticles();
        
        this.animationFrame = requestAnimationFrame(() => this.animate());
    }
    
    updateParticles() {
        const audioIntensity = this.getAudioIntensity();
        
        this.particles.forEach(p => {
            // Apply audio reactivity
            const speed = audioIntensity > 0.1 ? 
                          this.options.particleSpeed * (1 + audioIntensity * 2) : 
                          this.options.particleSpeed;
            
            p.x += p.speedX * speed;
            p.y += p.speedY * speed;
            
            // Wrap around edges
            if (p.x < 0) p.x = this.width;
            if (p.x > this.width) p.x = 0;
            if (p.y < 0) p.y = this.height;
            if (p.y > this.height) p.y = 0;
            
            // Pulse size with audio
            p.displaySize = p.size * (1 + audioIntensity * 3);
            
            // Adjust alpha based on audio
            p.displayAlpha = p.alpha * (1 + audioIntensity);
            if (p.displayAlpha > 1) p.displayAlpha = 1;
        });
    }
    
    drawParticles() {
        this.particles.forEach(p => {
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.displaySize || p.size, 0, Math.PI * 2);
            this.ctx.fillStyle = p.color.replace(')', `,${p.displayAlpha || p.alpha})`);
            this.ctx.fill();
        });
        
        // Draw connections in Saga and Epic modes
        if (this.options.mode === 'saga' || this.options.mode === 'epic') {
            this.drawConnections();
        }
    }
    
    drawConnections() {
        const maxDistance = this.options.mode === 'epic' ? 150 : 100;
        const audioIntensity = this.getAudioIntensity();
        
        for (let i = 0; i < this.particles.length; i++) {
            for (let j = i + 1; j < this.particles.length; j++) {
                const p1 = this.particles[i];
                const p2 = this.particles[j];
                
                const dx = p1.x - p2.x;
                const dy = p1.y - p2.y;
                const distance = Math.sqrt(dx * dx + dy * dy);
                
                if (distance < maxDistance) {
                    const alpha = (1 - distance / maxDistance) * 0.5 * (p1.alpha + p2.alpha) * (1 + audioIntensity);
                    
                    this.ctx.beginPath();
                    this.ctx.moveTo(p1.x, p1.y);
                    this.ctx.lineTo(p2.x, p2.y);
                    
                    if (this.options.mode === 'saga') {
                        this.ctx.strokeStyle = `rgba(156, 39, 176, ${alpha})`;
                    } else {
                        this.ctx.strokeStyle = `rgba(255, 193, 7, ${alpha})`;
                    }
                    
                    this.ctx.lineWidth = 0.5 + audioIntensity;
                    this.ctx.stroke();
                }
            }
        }
    }
    
    getAudioIntensity() {
        if (!this.audioData) return 0;
        
        // Calculate average amplitude from audio data
        let sum = 0;
        for (let i = 0; i < this.audioData.length; i++) {
            sum += Math.abs(this.audioData[i]);
        }
        return sum / this.audioData.length;
    }
}

class ImpactVisualizer extends AudioVisualizer {
    constructor(container, options = {}) {
        super(container, Object.assign({
            particleCount: 200,
            particleSize: 3,
            particleSpeed: 2,
            mode: 'standard'
        }, options));
        
        this.canvas.className = 'visualizer visualizer-impact';
        this.explosionTime = 0;
        this.explosionDuration = 2000; // ms
    }
    
    createParticles() {
        this.particles = [];
        // Particles will be created during explosion
    }
    
    triggerExplosion(intensity = 1) {
        const centerX = this.width / 2;
        const centerY = this.height / 2;
        const count = this.options.mode === 'epic' ? 
                      this.options.particleCount * 2 : 
                      this.options.particleCount;
        
        this.particles = [];
        
        for (let i = 0; i < count; i++) {
            const angle = Math.random() * Math.PI * 2;
            const speed = (Math.random() * 5 + 2) * intensity;
            
            this.particles.push({
                x: centerX,
                y: centerY,
                size: Math.random() * this.options.particleSize * intensity + 1,
                speedX: Math.cos(angle) * speed,
                speedY: Math.sin(angle) * speed,
                color: this.getExplosionColor(),
                alpha: Math.random() * 0.8 + 0.2,
                life: 1.0
            });
        }
        
        this.explosionTime = Date.now();
        this.canvas.style.opacity = '1';
        this.start();
    }
    
    getExplosionColor() {
        switch(this.options.mode) {
            case 'saga':
                return `hsl(${280 + Math.random() * 60}, 100%, ${70 + Math.random() * 30}%)`;
            case 'epic':
                return `hsl(${20 + Math.random() * 40}, 100%, ${70 + Math.random() * 30}%)`;
            default:
                return `hsl(${180 + Math.random() * 40}, 100%, ${70 + Math.random() * 30}%)`;
        }
    }
    
    updateParticles() {
        const elapsed = Date.now() - this.explosionTime;
        const progress = Math.min(elapsed / this.explosionDuration, 1);
        
        if (progress >= 1) {
            this.canvas.style.opacity = '0';
            if (this.particles.length === 0) {
                this.stop();
            }
        }
        
        const audioIntensity = this.getAudioIntensity();
        const remainingParticles = [];
        
        this.particles.forEach(p => {
            p.life -= 0.01;
            if (p.life <= 0) return;
            
            p.x += p.speedX;
            p.y += p.speedY;
            
            // Slow down over time
            p.speedX *= 0.98;
            p.speedY *= 0.98;
            
            // Fade out
            p.displayAlpha = p.alpha * p.life * (1 + audioIntensity);
            
            // Adjust size with audio
            p.displaySize = p.size * (1 + audioIntensity * 2) * p.life;
            
            remainingParticles.push(p);
        });
        
        this.particles = remainingParticles;
    }
}

class StreamVisualizer extends AudioVisualizer {
    constructor(container, options = {}) {
        super(container, Object.assign({
            particleCount: 150,
            particleSize: 2,
            particleSpeed: 1.5,
            mode: 'standard'
        }, options));
        
        this.canvas.className = 'visualizer visualizer-stream';
        this.flowDirection = { x: 1, y: 0 }; // Default flow direction
    }
    
    setFlowDirection(x, y) {
        const magnitude = Math.sqrt(x * x + y * y);
        if (magnitude > 0) {
            this.flowDirection = {
                x: x / magnitude,
                y: y / magnitude
            };
        }
    }
    
    createParticle() {
        // Create particles along the edge opposite to flow direction
        let x, y;
        
        if (Math.abs(this.flowDirection.x) > Math.abs(this.flowDirection.y)) {
            // Flow is more horizontal
            x = this.flowDirection.x > 0 ? 0 : this.width;
            y = Math.random() * this.height;
        } else {
            // Flow is more vertical
            x = Math.random() * this.width;
            y = this.flowDirection.y > 0 ? 0 : this.height;
        }
        
        return {
            x,
            y,
            size: Math.random() * this.options.particleSize + 1,
            speedX: this.flowDirection.x * (Math.random() * 2 + 3) * this.options.particleSpeed,
            speedY: this.flowDirection.y * (Math.random() * 2 + 3) * this.options.particleSpeed,
            color: this.getParticleColor(),
            alpha: Math.random() * 0.8 + 0.2,
            tail: []
        };
    }
    
    startStream(duration = 5000) {
        this.canvas.style.opacity = '1';
        this.start();
        
        // Stop after duration
        setTimeout(() => {
            this.canvas.style.opacity = '0';
            setTimeout(() => this.stop(), 1000); // Allow fade out animation
        }, duration);
    }
    
    updateParticles() {
        const audioIntensity = this.getAudioIntensity();
        const newParticles = [];
        
        // Add new particles to replace those that have gone off-screen
        while (this.particles.length < this.options.particleCount) {
            this.particles.push(this.createParticle());
        }
        
        this.particles.forEach(p => {
            // Store previous position for tail
            if (this.options.mode !== 'standard') {
                p.tail.unshift({ x: p.x, y: p.y });
                if (p.tail.length > 5) {
                    p.tail.pop();
                }
            }
            
            // Apply audio reactivity
            const speed = audioIntensity > 0.1 ? 
                          1 + audioIntensity * 3 : 
                          1;
            
            p.x += p.speedX * speed;
            p.y += p.speedY * speed;
            
            // Check if particle is still on screen
            if (p.x >= 0 && p.x <= this.width && p.y >= 0 && p.y <= this.height) {
                newParticles.push(p);
            }
        });
        
        this.particles = newParticles;
    }
    
    drawParticles() {
        this.particles.forEach(p => {
            // Draw tail in Saga and Epic modes
            if ((this.options.mode === 'saga' || this.options.mode === 'epic') && p.tail.length > 0) {
                this.ctx.beginPath();
                this.ctx.moveTo(p.x, p.y);
                
                for (let i = 0; i < p.tail.length; i++) {
                    this.ctx.lineTo(p.tail[i].x, p.tail[i].y);
                }
                
                const gradient = this.ctx.createLinearGradient(
                    p.x, p.y, 
                    p.tail[p.tail.length - 1].x, 
                    p.tail[p.tail.length - 1].y
                );
                
                gradient.addColorStop(0, p.color.replace(')', `,${p.alpha})`));
                gradient.addColorStop(1, p.color.replace(')', `,0)`));
                
                this.ctx.strokeStyle = gradient;
                this.ctx.lineWidth = p.size * 0.8;
                this.ctx.stroke();
            }
            
            // Draw particle
            this.ctx.beginPath();
            this.ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            this.ctx.fillStyle = p.color.replace(')', `,${p.alpha})`);
            this.ctx.fill();
        });
    }
}

// Export visualizer classes
window.AudioVisualizer = AudioVisualizer;
window.ImpactVisualizer = ImpactVisualizer;
window.StreamVisualizer = StreamVisualizer;

