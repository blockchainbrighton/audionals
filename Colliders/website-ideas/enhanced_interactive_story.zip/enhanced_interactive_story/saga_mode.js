/**
 * Saga Mode Implementation
 * The Colliders - Interactive Experience
 */

class SagaMode {
    constructor() {
        this.isActive = false;
        this.currentChoice = null;
        this.choiceTimeout = null;
        this.visualizers = {};
        this.additionalAudioBuffers = {};
    }
    
    /**
     * Initialize Saga mode
     * @param {Object} options - Configuration options
     */
    async initialize(options = {}) {
        this.options = Object.assign({
            audioContext: null,
            container: document.getElementById('container'),
            visualContainer: document.getElementById('visual-container'),
            textDisplay: document.getElementById('text-display'),
            audioBuffers: {},
            onComplete: () => {}
        }, options);
        
        // Create UI elements for Saga mode
        this.createUI();
        
        // Initialize visualizers
        this.initializeVisualizers();
        
        // Load additional audio files for Saga mode
        await this.loadAdditionalAudio();
        
        console.log('Saga mode initialized');
    }
    
    /**
     * Create UI elements specific to Saga mode
     */
    createUI() {
        // Create progress indicator
        this.progressContainer = document.createElement('div');
        this.progressContainer.className = 'progress-container';
        this.progressBar = document.createElement('div');
        this.progressBar.className = 'progress-bar';
        this.progressMarker = document.createElement('div');
        this.progressMarker.className = 'progress-marker';
        this.progressBar.appendChild(this.progressMarker);
        this.progressContainer.appendChild(this.progressBar);
        
        // Create choice interface
        this.choiceContainer = document.createElement('div');
        this.choiceContainer.className = 'choice-container';
        this.choiceContainer.style.display = 'none';
        
        const yesButton = document.createElement('button');
        yesButton.className = 'choice-button yes';
        yesButton.textContent = 'YES';
        yesButton.addEventListener('click', () => this.handleChoice('yes'));
        
        const noButton = document.createElement('button');
        noButton.className = 'choice-button no';
        noButton.textContent = 'NO';
        noButton.addEventListener('click', () => this.handleChoice('no'));
        
        this.choiceContainer.appendChild(yesButton);
        this.choiceContainer.appendChild(noButton);
        
        // Append UI elements to container
        this.options.container.appendChild(this.progressContainer);
        this.options.container.appendChild(this.choiceContainer);
        
        // Add saga-specific class to body
        document.body.classList.add('saga-mode');
    }
    
    /**
     * Initialize visualizers for Saga mode
     */
    initializeVisualizers() {
        // Create ambient visualizer
        this.visualizers.ambient = new AudioVisualizer(this.options.visualContainer, {
            particleCount: 150,
            particleColor: '#9c27b0',
            particleSize: 2,
            particleSpeed: 0.5,
            mode: 'saga'
        });
        
        // Create impact visualizer for strike moments
        this.visualizers.impact = new ImpactVisualizer(this.options.visualContainer, {
            particleCount: 250,
            particleSize: 3,
            particleSpeed: 2.5,
            mode: 'saga'
        });
        
        // Create stream visualizer for stream moments
        this.visualizers.stream = new StreamVisualizer(this.options.visualContainer, {
            particleCount: 200,
            particleSize: 2.5,
            particleSpeed: 2,
            mode: 'saga'
        });
    }
    
    /**
     * Load additional audio files for Saga mode
     */
    async loadAdditionalAudio() {
        const additionalFiles = [
            'saga-ambient.webm',
            'saga-transition.webm',
            'saga-choice.webm'
        ];
        
        // Use existing audio context
        const audioCtx = this.options.audioContext;
        
        // Fetch and decode all clips in parallel
        const fetchAndDecode = async file => {
            try {
                const res = await fetch(`audio/${file}`);
                if (!res.ok) { 
                    console.warn('Missing:', file); 
                    return; 
                }
                const buf = await res.arrayBuffer();
                this.additionalAudioBuffers[file] = await audioCtx.decodeAudioData(buf);
            } catch (err) {
                console.error('Error loading', file, err);
            }
        };
        
        await Promise.all(additionalFiles.map(fetchAndDecode));
        console.log('Additional audio files loaded for Saga mode');
    }
    
    /**
     * Start Saga mode experience
     */
    start() {
        if (this.isActive) return;
        this.isActive = true;
        
        // Start ambient visualizer
        this.visualizers.ambient.start();
        
        // Play saga ambient sound
        this.playAmbienceLoop();
        
        // Play saga sequence
        this.playSagaSequence();
    }
    
    /**
     * Play ambient loop specific to Saga mode
     */
    playAmbienceLoop(fadeIn = 2.0, volume = 0.6) {
        const audioCtx = this.options.audioContext;
        const buffer = this.additionalAudioBuffers['saga-ambient.webm'] || this.options.audioBuffers['particle-ambience.webm'];
        if (!buffer) return;
        
        this.ambienceGain = audioCtx.createGain();
        this.ambienceGain.gain.setValueAtTime(0, audioCtx.currentTime);
        this.ambienceGain.connect(audioCtx.destination);
        
        this.ambienceNode = audioCtx.createBufferSource();
        this.ambienceNode.buffer = buffer;
        this.ambienceNode.loop = true;
        this.ambienceNode.connect(this.ambienceGain);
        this.ambienceNode.start();
        
        // Smooth fade-in
        this.ambienceGain.gain.linearRampToValueAtTime(
            volume,
            audioCtx.currentTime + fadeIn
        );
    }
    
    /**
     * Stop ambient loop
     */
    stopAmbience(fadeOut = 1.5) {
        if (!this.ambienceNode || !this.ambienceGain) return;
        
        const audioCtx = this.options.audioContext;
        const now = audioCtx.currentTime;
        this.ambienceGain.gain.cancelScheduledValues(now);
        this.ambienceGain.gain.setValueAtTime(this.ambienceGain.gain.value, now);
        this.ambienceGain.gain.linearRampToValueAtTime(0, now + fadeOut);
        
        this.ambienceNode.stop(now + fadeOut + 0.05);
        this.ambienceNode.onended = () => {
            this.ambienceNode.disconnect();
            this.ambienceGain.disconnect();
            this.ambienceNode = null;
            this.ambienceGain = null;
        };
    }
    
    /**
     * Play the Saga sequence
     */
    playSagaSequence() {
        this.clearAllTimeouts();
        this.options.textDisplay.innerHTML = ""; // Clear at start
        let endTime = 0;
        
        // Process each entry in the Saga timeline
        for (let i = 0; i < SAGA_TL.length; ++i) {
            const entry = SAGA_TL[i];
            const inTime = entry.time;
            let outTime;
            
            // Update progress bar
            const progress = i / SAGA_TL.length;
            this.scheduledTimeouts.push(setTimeout(() => {
                this.updateProgress(progress);
            }, inTime * 1000));
            
            // For strike or stream, text vanishes when sound ends (abrupt out)
            if (typeof entry.strike !== "undefined") {
                this.playSound(STRIKE_FILES[entry.strike], inTime);
                outTime = inTime + STRIKE_DUR[entry.strike];
                
                // Trigger impact visualizer
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.visualizers.impact.triggerExplosion(1.5);
                }, inTime * 1000));
            } else if (typeof entry.stream !== "undefined") {
                this.playSound(STREAM_FILES[entry.stream], inTime);
                outTime = inTime + STREAM_DUR[entry.stream];
                
                // Trigger stream visualizer
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.visualizers.stream.startStream(STREAM_DUR[entry.stream] * 1000);
                }, inTime * 1000));
            } else if (typeof entry.fadeStart !== "undefined") {
                outTime = entry.fadeStart;
            } else {
                outTime = inTime + 3.5; // fallback
            }
            
            // Handle interactive elements
            if (entry.interactive) {
                this.showAndHideInteractiveText(entry.text, inTime, outTime);
            } else {
                this.showAndHideText(entry.text, inTime, outTime);
            }
            
            endTime = Math.max(endTime, outTime);
        }
        
        // Sequence end: stop ambience, fade out, then play trailer video
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = "Preparing final transmission…";
            this.stopAmbience();
            this.cleanup();
            setTimeout(() => {
                this.options.onComplete();
            }, 1400);
            this.isActive = false;
        }, (endTime + 1) * 1000));
    }
    
    /**
     * Play choice response sequence
     */
    playChoiceResponse(choice) {
        this.clearAllTimeouts();
        this.options.textDisplay.innerHTML = ""; // Clear at start
        let endTime = 0;
        
        const responses = CHOICE_RESPONSES[choice];
        
        // Play choice sound
        this.playSound('saga-choice.webm', 0);
        
        // Process each response entry
        for (let i = 0; i < responses.length; ++i) {
            const entry = responses[i];
            const inTime = entry.time;
            const outTime = entry.fadeStart;
            
            this.showAndHideText(entry.text, inTime, outTime);
            endTime = Math.max(endTime, outTime);
        }
        
        // After responses, continue with main sequence
        this.scheduledTimeouts.push(setTimeout(() => {
            this.playSagaSequence();
        }, (endTime + 1) * 1000));
    }
    
    /**
     * Show and hide text with Saga-specific animations
     */
    showAndHideText(text, delay, outDelay) {
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = text;
            this.options.textDisplay.className = 'saga-text-in';
        }, delay * 1000));
        
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.className = 'text-fade-out';
            setTimeout(() => {
                this.options.textDisplay.innerHTML = "";
                this.options.textDisplay.className = '';
            }, 500);
        }, outDelay * 1000));
    }
    
    /**
     * Show interactive text with choice options
     */
    showAndHideInteractiveText(text, delay, outDelay) {
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = text;
            this.options.textDisplay.className = 'saga-text-in';
            
            // Show choice interface after a short delay
            setTimeout(() => {
                this.choiceContainer.style.display = 'flex';
                this.choiceContainer.style.opacity = '0';
                setTimeout(() => {
                    this.choiceContainer.style.opacity = '1';
                }, 100);
                
                // Set timeout for choice
                this.choiceTimeout = setTimeout(() => {
                    this.handleChoice('no'); // Default to 'no' if no choice made
                }, (outDelay - delay - 1) * 1000);
            }, 1000);
        }, delay * 1000));
    }
    
    /**
     * Handle user choice
     */
    handleChoice(choice) {
        if (this.choiceTimeout) {
            clearTimeout(this.choiceTimeout);
            this.choiceTimeout = null;
        }
        
        this.currentChoice = choice;
        this.choiceContainer.style.opacity = '0';
        setTimeout(() => {
            this.choiceContainer.style.display = 'none';
            this.options.textDisplay.innerHTML = "";
            this.options.textDisplay.className = '';
            
            // Play response sequence based on choice
            this.playChoiceResponse(choice);
        }, 500);
    }
    
    /**
     * Play a sound with the given delay
     */
    playSound(filename, delay) {
        const audioCtx = this.options.audioContext;
        
        this.scheduledTimeouts.push(setTimeout(() => {
            // Check in additional buffers first, then fall back to standard buffers
            const buffer = this.additionalAudioBuffers[filename] || this.options.audioBuffers[filename];
            
            if (buffer) {
                const src = audioCtx.createBufferSource();
                src.buffer = buffer;
                src.connect(audioCtx.destination);
                src.start();
                
                // Update visualizer audio data
                if (this.analyser && this.analyserData) {
                    const analyser = this.analyser;
                    const analyserData = this.analyserData;
                    
                    // Connect source to analyser
                    src.connect(analyser);
                    
                    // Set up animation loop to update visualizers
                    const updateVisualizers = () => {
                        if (!this.isActive) return;
                        
                        analyser.getFloatTimeDomainData(analyserData);
                        
                        // Update all visualizers with audio data
                        Object.values(this.visualizers).forEach(visualizer => {
                            if (visualizer.isActive) {
                                visualizer.updateAudioData(analyserData);
                            }
                        });
                        
                        requestAnimationFrame(updateVisualizers);
                    };
                    
                    updateVisualizers();
                }
            }
        }, delay * 1000));
    }
    
    /**
     * Update progress indicator
     */
    updateProgress(progress) {
        if (!this.progressBar) return;
        
        this.progressBar.style.width = `${progress * 100}%`;
        this.progressMarker.style.left = `${progress * 100}%`;
    }
    
    /**
     * Clear all scheduled timeouts
     */
    clearAllTimeouts() {
        if (this.scheduledTimeouts) {
            this.scheduledTimeouts.forEach(id => clearTimeout(id));
        }
        this.scheduledTimeouts = [];
    }
    
    /**
     * Set up audio analyser for visualizers
     */
    setupAudioAnalyser() {
        const audioCtx = this.options.audioContext;
        
        this.analyser = audioCtx.createAnalyser();
        this.analyser.fftSize = 2048;
        this.analyserData = new Float32Array(this.analyser.fftSize);
        this.analyser.connect(audioCtx.destination);
    }
    
    /**
     * Clean up resources
     */
    cleanup() {
        // Stop visualizers
        Object.values(this.visualizers).forEach(visualizer => {
            if (visualizer.isActive) {
                visualizer.stop();
            }
        });
        
        // Clear timeouts
        this.clearAllTimeouts();
        
        // Hide UI elements
        this.progressContainer.style.opacity = '0';
        this.choiceContainer.style.display = 'none';
        
        // Remove saga-specific class
        document.body.classList.remove('saga-mode');
    }
}

// Export SagaMode class
window.SagaMode = SagaMode;

