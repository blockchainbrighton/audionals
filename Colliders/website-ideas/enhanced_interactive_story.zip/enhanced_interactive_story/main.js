/**
 * Main JavaScript for Enhanced Interactive Story Experience
 * The Colliders - Interactive Experience
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize the application
    const app = new InteractiveStoryApp();
    app.initialize();
});

/**
 * Interactive Story Application
 */
class InteractiveStoryApp {
    constructor() {
        // DOM elements
        this.container = document.getElementById('container');
        this.visualContainer = document.getElementById('visual-container');
        this.textDisplay = document.getElementById('text-display');
        
        // Audio context
        this.audioContext = new (window.AudioContext || window.webkitAudioContext)();
        
        // Audio buffers
        this.audioBuffers = {};
        
        // Mode instances
        this.standardMode = null;
        this.sagaMode = null;
        this.epicMode = null;
        
        // Current mode
        this.currentMode = 'standard';
        
        // Enhancers
        this.audioEnhancer = null;
        this.visualEnhancer = null;
    }
    
    /**
     * Initialize the application
     */
    async initialize() {
        try {
            // Create loading indicator
            this.showLoadingIndicator();
            
            // Load audio files
            await this.loadAudioFiles();
            
            // Initialize enhancers
            this.initializeEnhancers();
            
            // Initialize modes
            await this.initializeModes();
            
            // Create mode selection interface
            this.createModeSelectionInterface();
            
            // Hide loading indicator
            this.hideLoadingIndicator();
            
            // Start standard mode
            this.startMode('standard');
            
            console.log('Interactive Story App initialized');
        } catch (error) {
            console.error('Error initializing app:', error);
            this.showErrorMessage('Failed to initialize the experience. Please refresh the page.');
        }
    }
    
    /**
     * Show loading indicator
     */
    showLoadingIndicator() {
        const loadingIndicator = document.createElement('div');
        loadingIndicator.id = 'loading-indicator';
        loadingIndicator.innerHTML = `
            <div class="loading-spinner"></div>
            <div class="loading-text">Loading Experience...</div>
        `;
        document.body.appendChild(loadingIndicator);
    }
    
    /**
     * Hide loading indicator
     */
    hideLoadingIndicator() {
        const loadingIndicator = document.getElementById('loading-indicator');
        if (loadingIndicator) {
            loadingIndicator.classList.add('fade-out');
            setTimeout(() => {
                loadingIndicator.parentNode.removeChild(loadingIndicator);
            }, 500);
        }
    }
    
    /**
     * Show error message
     */
    showErrorMessage(message) {
        const errorMessage = document.createElement('div');
        errorMessage.id = 'error-message';
        errorMessage.innerHTML = `
            <div class="error-icon">⚠️</div>
            <div class="error-text">${message}</div>
            <button class="error-button">Retry</button>
        `;
        document.body.appendChild(errorMessage);
        
        // Add retry button event listener
        const retryButton = errorMessage.querySelector('.error-button');
        retryButton.addEventListener('click', () => {
            errorMessage.parentNode.removeChild(errorMessage);
            window.location.reload();
        });
    }
    
    /**
     * Load audio files
     */
    async loadAudioFiles() {
        const audioFiles = [
            'particle-ambience.webm',
            'particle-strike-1.webm',
            'particle-strike-2.webm',
            'particle-strike-3.webm',
            'particle-strike-4.webm',
            'particle-strike-5.webm',
            'particle-strike-6.webm',
            'particle-stream-1.webm',
            'particle-stream-2.webm'
        ];
        
        // Fetch and decode all clips in parallel
        const fetchAndDecode = async file => {
            try {
                const res = await fetch(`audio/${file}`);
                if (!res.ok) { 
                    console.warn('Missing:', file); 
                    return; 
                }
                const buf = await res.arrayBuffer();
                this.audioBuffers[file] = await this.audioContext.decodeAudioData(buf);
            } catch (err) {
                console.error('Error loading', file, err);
            }
        };
        
        await Promise.all(audioFiles.map(fetchAndDecode));
        console.log('Audio files loaded');
    }
    
    /**
     * Initialize enhancers
     */
    initializeEnhancers() {
        // Initialize audio enhancer
        this.audioEnhancer = new AudioEnhancer({
            audioContext: this.audioContext,
            container: this.container,
            visualizerContainer: this.visualContainer
        });
        
        // Initialize visual enhancer
        this.visualEnhancer = new VisualEnhancer({
            container: this.container,
            visualContainer: this.visualContainer,
            textDisplay: this.textDisplay
        });
        
        console.log('Enhancers initialized');
    }
    
    /**
     * Initialize modes
     */
    async initializeModes() {
        // Initialize standard mode
        this.standardMode = new StandardMode();
        await this.standardMode.initialize({
            audioContext: this.audioContext,
            container: this.container,
            visualContainer: this.visualContainer,
            textDisplay: this.textDisplay,
            audioBuffers: this.audioBuffers,
            onComplete: () => this.handleModeComplete('standard')
        });
        
        // Initialize saga mode
        this.sagaMode = new SagaMode();
        await this.sagaMode.initialize({
            audioContext: this.audioContext,
            container: this.container,
            visualContainer: this.visualContainer,
            textDisplay: this.textDisplay,
            audioBuffers: this.audioBuffers,
            onComplete: () => this.handleModeComplete('saga')
        });
        
        // Initialize epic mode
        this.epicMode = new EpicMode();
        await this.epicMode.initialize({
            audioContext: this.audioContext,
            container: this.container,
            visualContainer: this.visualContainer,
            textDisplay: this.textDisplay,
            audioBuffers: this.audioBuffers,
            onComplete: () => this.handleModeComplete('epic')
        });
        
        console.log('Modes initialized');
    }
    
    /**
     * Create mode selection interface
     */
    createModeSelectionInterface() {
        const modeSelection = document.createElement('div');
        modeSelection.className = 'mode-selection';
        
        // Create mode buttons
        const standardButton = document.createElement('button');
        standardButton.className = 'mode-button standard active';
        standardButton.textContent = 'Standard';
        standardButton.addEventListener('click', () => this.switchMode('standard'));
        
        const sagaButton = document.createElement('button');
        sagaButton.className = 'mode-button saga';
        sagaButton.textContent = 'Saga';
        sagaButton.addEventListener('click', () => this.switchMode('saga'));
        
        const epicButton = document.createElement('button');
        epicButton.className = 'mode-button epic';
        epicButton.textContent = 'EPIC';
        epicButton.addEventListener('click', () => this.switchMode('epic'));
        
        // Add buttons to mode selection
        modeSelection.appendChild(standardButton);
        modeSelection.appendChild(sagaButton);
        modeSelection.appendChild(epicButton);
        
        // Add mode selection to container
        this.container.appendChild(modeSelection);
        
        // Store buttons for later use
        this.modeButtons = {
            standard: standardButton,
            saga: sagaButton,
            epic: epicButton
        };
        
        console.log('Mode selection interface created');
    }
    
    /**
     * Switch to a different mode
     */
    async switchMode(mode) {
        if (this.currentMode === mode) return;
        
        // Update active button
        Object.keys(this.modeButtons).forEach(key => {
            this.modeButtons[key].classList.remove('active');
        });
        this.modeButtons[mode].classList.add('active');
        
        // Create transition effect
        await this.visualEnhancer.createTransition('fade', {
            duration: 2000,
            color: mode === 'epic' ? '#000' : '#111',
            onMidpoint: () => {
                // Stop current mode
                this.stopCurrentMode();
                
                // Set new current mode
                this.currentMode = mode;
                
                // Start new mode
                this.startMode(mode);
            }
        });
    }
    
    /**
     * Start a mode
     */
    startMode(mode) {
        switch (mode) {
            case 'standard':
                this.standardMode.start();
                break;
            case 'saga':
                this.sagaMode.start();
                break;
            case 'epic':
                this.epicMode.start();
                break;
        }
    }
    
    /**
     * Stop current mode
     */
    stopCurrentMode() {
        switch (this.currentMode) {
            case 'standard':
                this.standardMode.cleanup();
                break;
            case 'saga':
                this.sagaMode.cleanup();
                break;
            case 'epic':
                this.epicMode.cleanup();
                break;
        }
    }
    
    /**
     * Handle mode completion
     */
    handleModeComplete(mode) {
        console.log(`${mode} mode completed`);
        
        // Show completion message
        const completionMessage = document.createElement('div');
        completionMessage.className = 'completion-message';
        completionMessage.innerHTML = `
            <h2>Experience Complete</h2>
            <p>You have completed the ${mode} mode of The Colliders.</p>
            <p>Select another mode to continue exploring the story.</p>
        `;
        
        this.container.appendChild(completionMessage);
        
        // Auto-hide after 5 seconds
        setTimeout(() => {
            if (completionMessage.parentNode) {
                completionMessage.parentNode.removeChild(completionMessage);
            }
        }, 5000);
    }
}

/**
 * Standard Mode Implementation
 * This is a placeholder for the original implementation
 */
class StandardMode {
    constructor() {
        this.isActive = false;
        this.scheduledTimeouts = [];
    }
    
    /**
     * Initialize Standard mode
     */
    async initialize(options = {}) {
        this.options = options;
        console.log('Standard mode initialized');
    }
    
    /**
     * Start Standard mode
     */
    start() {
        if (this.isActive) return;
        this.isActive = true;
        
        // Add standard-mode class to body
        document.body.classList.add('standard-mode');
        
        // Start the standard experience
        this.playStandardSequence();
    }
    
    /**
     * Play the standard sequence
     */
    playStandardSequence() {
        // This would be the original implementation
        // For now, just show a placeholder message
        this.options.textDisplay.innerHTML = "Standard mode active. The original experience.";
        
        // Schedule completion after a delay (for testing)
        this.scheduledTimeouts.push(setTimeout(() => {
            if (this.options.onComplete) {
                this.options.onComplete();
            }
        }, 10000));
    }
    
    /**
     * Clear all scheduled timeouts
     */
    clearAllTimeouts() {
        if (this.scheduledTimeouts) {
            this.scheduledTimeouts.forEach(id => clearTimeout(id));
        }
        this.scheduledTimeouts = [];
    }
    
    /**
     * Clean up resources
     */
    cleanup() {
        this.clearAllTimeouts();
        this.isActive = false;
        
        // Remove standard-mode class from body
        document.body.classList.remove('standard-mode');
    }
}

// Add loading styles
const loadingStyles = document.createElement('style');
loadingStyles.textContent = `
    #loading-indicator {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: #000;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 9999;
        transition: opacity 0.5s ease;
    }
    
    #loading-indicator.fade-out {
        opacity: 0;
    }
    
    .loading-spinner {
        width: 50px;
        height: 50px;
        border: 5px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: #fff;
        animation: spin 1s ease-in-out infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }
    
    .loading-text {
        margin-top: 20px;
        color: #fff;
        font-size: 18px;
    }
    
    #error-message {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.9);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: 9999;
    }
    
    .error-icon {
        font-size: 48px;
        margin-bottom: 20px;
    }
    
    .error-text {
        color: #fff;
        font-size: 18px;
        margin-bottom: 20px;
        text-align: center;
        max-width: 80%;
    }
    
    .error-button {
        padding: 10px 20px;
        background-color: #f44336;
        color: #fff;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-size: 16px;
    }
    
    .completion-message {
        position: fixed;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background-color: rgba(0, 0, 0, 0.8);
        padding: 20px;
        border-radius: 8px;
        text-align: center;
        color: #fff;
        z-index: 100;
        max-width: 80%;
    }
    
    .completion-message h2 {
        margin-top: 0;
        color: #ffc107;
    }
`;

document.head.appendChild(loadingStyles);

