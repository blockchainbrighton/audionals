/**
 * EPIC Mode Implementation
 * The Colliders - Interactive Experience
 */

class EpicMode {
    constructor() {
        this.isActive = false;
        this.currentInteraction = null;
        this.interactionTimeout = null;
        this.visualizers = {};
        this.visualEffects = {};
        this.additionalAudioBuffers = {};
        this.userChoices = {};
        this.scheduledTimeouts = [];
        this.particleSystems = [];
    }
    
    /**
     * Initialize EPIC mode
     * @param {Object} options - Configuration options
     */
    async initialize(options = {}) {
        this.options = Object.assign({
            audioContext: null,
            container: document.getElementById('container'),
            visualContainer: document.getElementById('visual-container'),
            textDisplay: document.getElementById('text-display'),
            audioBuffers: {},
            onComplete: () => {}
        }, options);
        
        // Create UI elements for EPIC mode
        this.createUI();
        
        // Initialize visualizers and effects
        this.initializeVisualizers();
        this.initializeVisualEffects();
        
        // Set up audio analyzer for visualizations
        this.setupAudioAnalyser();
        
        // Load additional audio files for EPIC mode
        await this.loadAdditionalAudio();
        
        console.log('EPIC mode initialized');
    }
    
    /**
     * Create UI elements specific to EPIC mode
     */
    createUI() {
        // Create background effects container
        this.backgroundEffects = document.createElement('div');
        this.backgroundEffects.className = 'background-effects';
        
        // Create stars background
        this.starsBackground = document.createElement('div');
        this.starsBackground.className = 'stars';
        this.backgroundEffects.appendChild(this.starsBackground);
        
        // Create progress indicator with enhanced styling
        this.progressContainer = document.createElement('div');
        this.progressContainer.className = 'progress-container epic-progress';
        this.progressBar = document.createElement('div');
        this.progressBar.className = 'progress-bar';
        this.progressMarker = document.createElement('div');
        this.progressMarker.className = 'progress-marker';
        this.progressBar.appendChild(this.progressMarker);
        this.progressContainer.appendChild(this.progressBar);
        
        // Create interaction interface
        this.interactionContainer = document.createElement('div');
        this.interactionContainer.className = 'interaction-container';
        this.interactionContainer.style.display = 'none';
        
        // Append UI elements to container
        document.body.insertBefore(this.backgroundEffects, document.body.firstChild);
        this.options.container.appendChild(this.progressContainer);
        this.options.container.appendChild(this.interactionContainer);
        
        // Add epic-specific class to body
        document.body.classList.add('epic-mode');
    }
    
    /**
     * Initialize visualizers for EPIC mode
     */
    initializeVisualizers() {
        // Create ambient visualizer with enhanced settings
        this.visualizers.ambient = new AudioVisualizer(this.options.visualContainer, {
            particleCount: 200,
            particleColor: '#ffc107',
            particleSize: 2.5,
            particleSpeed: 0.7,
            mode: 'epic'
        });
        
        // Create impact visualizer for strike moments with enhanced settings
        this.visualizers.impact = new ImpactVisualizer(this.options.visualContainer, {
            particleCount: 350,
            particleSize: 4,
            particleSpeed: 3,
            mode: 'epic'
        });
        
        // Create stream visualizer for stream moments with enhanced settings
        this.visualizers.stream = new StreamVisualizer(this.options.visualContainer, {
            particleCount: 300,
            particleSize: 3,
            particleSpeed: 2.5,
            mode: 'epic'
        });
    }
    
    /**
     * Initialize visual effects for EPIC mode
     */
    initializeVisualEffects() {
        // Create container for visual effects
        this.effectsContainer = document.createElement('div');
        this.effectsContainer.className = 'effects-container';
        this.options.visualContainer.appendChild(this.effectsContainer);
        
        // Initialize effect layers
        this.visualEffects = {
            timeshift: this.createEffectLayer('timeshift-effect'),
            locationReveal: this.createEffectLayer('location-reveal-effect'),
            dimensionShift: this.createEffectLayer('dimension-shift-effect'),
            catastrophe: this.createEffectLayer('catastrophe-effect'),
            realityTear: this.createEffectLayer('reality-tear-effect'),
            cosmicUnravel: this.createEffectLayer('cosmic-unravel-effect'),
            cosmicErasure: this.createEffectLayer('cosmic-erasure-effect'),
            quantumFoam: this.createEffectLayer('quantum-foam-effect'),
            quantumBridge: this.createEffectLayer('quantum-bridge-effect'),
            reachPrompt: this.createEffectLayer('reach-prompt-effect'),
            silence: this.createEffectLayer('silence-effect'),
            distortion: this.createEffectLayer('distortion-effect'),
            arrival: this.createEffectLayer('arrival-effect'),
            heartbeat: this.createEffectLayer('heartbeat-effect'),
            networkEmbed: this.createEffectLayer('network-embed-effect'),
            timeProgression: this.createEffectLayer('time-progression-effect'),
            deathbed: this.createEffectLayer('deathbed-effect'),
            awakening: this.createEffectLayer('awakening-effect'),
            dateReveal: this.createEffectLayer('date-reveal-effect'),
            networkChoice: this.createEffectLayer('network-choice-effect'),
            broadcast: this.createEffectLayer('broadcast-effect'),
            finalReveal: this.createEffectLayer('final-reveal-effect'),
            connectionEstablished: this.createEffectLayer('connection-established-effect'),
            alienWorld: this.createEffectLayer('alien-world-effect'),
            timeRunningOut: this.createEffectLayer('time-running-out-effect'),
            networkJoined: this.createEffectLayer('network-joined-effect'),
            countdown: this.createEffectLayer('countdown-effect')
        };
    }
    
    /**
     * Create a visual effect layer
     */
    createEffectLayer(className) {
        const layer = document.createElement('div');
        layer.className = `effect-layer ${className}`;
        layer.style.opacity = '0';
        this.effectsContainer.appendChild(layer);
        return layer;
    }
    
    /**
     * Set up audio analyser for visualizations
     */
    setupAudioAnalyser() {
        const audioCtx = this.options.audioContext;
        
        this.analyser = audioCtx.createAnalyser();
        this.analyser.fftSize = 2048;
        this.analyserData = new Float32Array(this.analyser.fftSize);
        this.analyser.connect(audioCtx.destination);
    }
    
    /**
     * Load additional audio files for EPIC mode
     */
    async loadAdditionalAudio() {
        const additionalFiles = [
            'epic-ambient.webm',
            'epic-transition.webm',
            'epic-impact.webm',
            'epic-interaction.webm',
            'epic-heartbeat.webm',
            'epic-silence.webm',
            'epic-distortion.webm'
        ];
        
        // Use existing audio context
        const audioCtx = this.options.audioContext;
        
        // Fetch and decode all clips in parallel
        const fetchAndDecode = async file => {
            try {
                const res = await fetch(`audio/${file}`);
                if (!res.ok) { 
                    console.warn('Missing:', file); 
                    return; 
                }
                const buf = await res.arrayBuffer();
                this.additionalAudioBuffers[file] = await audioCtx.decodeAudioData(buf);
            } catch (err) {
                console.error('Error loading', file, err);
            }
        };
        
        await Promise.all(additionalFiles.map(fetchAndDecode));
        console.log('Additional audio files loaded for EPIC mode');
    }
    
    /**
     * Start EPIC mode experience
     */
    start() {
        if (this.isActive) return;
        this.isActive = true;
        
        // Start ambient visualizer
        this.visualizers.ambient.start();
        
        // Play epic ambient sound
        this.playAmbienceLoop();
        
        // Play epic sequence
        this.playEpicSequence();
    }
    
    /**
     * Play ambient loop specific to EPIC mode
     */
    playAmbienceLoop(fadeIn = 2.0, volume = 0.7) {
        const audioCtx = this.options.audioContext;
        const buffer = this.additionalAudioBuffers['epic-ambient.webm'] || this.options.audioBuffers['particle-ambience.webm'];
        if (!buffer) return;
        
        this.ambienceGain = audioCtx.createGain();
        this.ambienceGain.gain.setValueAtTime(0, audioCtx.currentTime);
        this.ambienceGain.connect(audioCtx.destination);
        
        this.ambienceNode = audioCtx.createBufferSource();
        this.ambienceNode.buffer = buffer;
        this.ambienceNode.loop = true;
        this.ambienceNode.connect(this.ambienceGain);
        this.ambienceNode.connect(this.analyser);
        this.ambienceNode.start();
        
        // Smooth fade-in
        this.ambienceGain.gain.linearRampToValueAtTime(
            volume,
            audioCtx.currentTime + fadeIn
        );
    }
    
    /**
     * Stop ambient loop
     */
    stopAmbience(fadeOut = 1.5) {
        if (!this.ambienceNode || !this.ambienceGain) return;
        
        const audioCtx = this.options.audioContext;
        const now = audioCtx.currentTime;
        this.ambienceGain.gain.cancelScheduledValues(now);
        this.ambienceGain.gain.setValueAtTime(this.ambienceGain.gain.value, now);
        this.ambienceGain.gain.linearRampToValueAtTime(0, now + fadeOut);
        
        this.ambienceNode.stop(now + fadeOut + 0.05);
        this.ambienceNode.onended = () => {
            this.ambienceNode.disconnect();
            this.ambienceGain.disconnect();
            this.ambienceNode = null;
            this.ambienceGain = null;
        };
    }
    
    /**
     * Play the EPIC sequence
     */
    playEpicSequence() {
        this.clearAllTimeouts();
        this.options.textDisplay.innerHTML = ""; // Clear at start
        let endTime = 0;
        
        // Process each entry in the EPIC timeline
        for (let i = 0; i < EPIC_TL.length; ++i) {
            const entry = EPIC_TL[i];
            const inTime = entry.time;
            let outTime;
            
            // Update progress bar
            const progress = i / EPIC_TL.length;
            this.scheduledTimeouts.push(setTimeout(() => {
                this.updateProgress(progress);
            }, inTime * 1000));
            
            // For strike or stream, text vanishes when sound ends (abrupt out)
            if (typeof entry.strike !== "undefined") {
                this.playSound(STRIKE_FILES[entry.strike], inTime, 'epic-impact.webm');
                outTime = inTime + STRIKE_DUR[entry.strike];
                
                // Trigger impact visualizer with enhanced intensity
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.visualizers.impact.triggerExplosion(2.0);
                }, inTime * 1000));
            } else if (typeof entry.stream !== "undefined") {
                this.playSound(STREAM_FILES[entry.stream], inTime);
                outTime = inTime + STREAM_DUR[entry.stream];
                
                // Trigger stream visualizer with enhanced duration
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.visualizers.stream.startStream(STREAM_DUR[entry.stream] * 1200);
                }, inTime * 1000));
            } else if (typeof entry.fadeStart !== "undefined") {
                outTime = entry.fadeStart;
            } else {
                outTime = inTime + 3.5; // fallback
            }
            
            // Handle visual effects
            if (entry.visualEffect) {
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.triggerVisualEffect(entry.visualEffect);
                }, inTime * 1000));
            }
            
            // Handle interactive elements
            if (entry.interactive) {
                this.showAndHideInteractiveText(entry.text, inTime, outTime, entry.interactive);
            } else {
                this.showAndHideText(entry.text, inTime, outTime);
            }
            
            endTime = Math.max(endTime, outTime);
        }
        
        // Sequence end: stop ambience, fade out, then play trailer video
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = '<span class="epic-final-message">Preparing final transmission…</span>';
            this.stopAmbience();
            this.cleanup();
            setTimeout(() => {
                this.options.onComplete();
            }, 1400);
            this.isActive = false;
        }, (endTime + 1) * 1000));
    }
    
    /**
     * Play interaction response sequence
     */
    playInteractionResponse(type, choice) {
        this.clearAllTimeouts();
        this.options.textDisplay.innerHTML = ""; // Clear at start
        let endTime = 0;
        
        const responses = EPIC_CHOICE_RESPONSES[type][choice];
        
        // Play interaction sound
        this.playSound('epic-interaction.webm', 0);
        
        // Process each response entry
        for (let i = 0; i < responses.length; ++i) {
            const entry = responses[i];
            const inTime = entry.time;
            const outTime = entry.fadeStart;
            
            // Handle visual effects in responses
            if (entry.visualEffect) {
                this.scheduledTimeouts.push(setTimeout(() => {
                    this.triggerVisualEffect(entry.visualEffect);
                }, inTime * 1000));
            }
            
            this.showAndHideText(entry.text, inTime, outTime);
            endTime = Math.max(endTime, outTime);
        }
        
        // After responses, continue with main sequence
        this.scheduledTimeouts.push(setTimeout(() => {
            this.playEpicSequence();
        }, (endTime + 1) * 1000));
    }
    
    /**
     * Show and hide text with EPIC-specific animations
     */
    showAndHideText(text, delay, outDelay) {
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = text;
            this.options.textDisplay.className = 'epic-text-in';
        }, delay * 1000));
        
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.className = 'text-fade-out';
            setTimeout(() => {
                this.options.textDisplay.innerHTML = "";
                this.options.textDisplay.className = '';
            }, 500);
        }, outDelay * 1000));
    }
    
    /**
     * Show interactive text with choice options
     */
    showAndHideInteractiveText(text, delay, outDelay, interactionType) {
        this.scheduledTimeouts.push(setTimeout(() => {
            this.options.textDisplay.innerHTML = text;
            this.options.textDisplay.className = 'epic-text-in';
            
            // Create interaction interface based on type
            this.createInteractionInterface(interactionType);
            
            // Show interaction interface after a short delay
            setTimeout(() => {
                this.interactionContainer.style.display = 'flex';
                this.interactionContainer.style.opacity = '0';
                setTimeout(() => {
                    this.interactionContainer.style.opacity = '1';
                }, 100);
                
                // Set timeout for interaction
                this.interactionTimeout = setTimeout(() => {
                    this.handleInteraction(interactionType, 'no'); // Default to 'no' if no choice made
                }, (outDelay - delay - 1) * 1000);
            }, 1000);
        }, delay * 1000));
    }
    
    /**
     * Create interaction interface based on type
     */
    createInteractionInterface(type) {
        // Clear previous interface
        this.interactionContainer.innerHTML = '';
        
        // Create buttons based on interaction type
        const yesButton = document.createElement('button');
        yesButton.className = 'interaction-button yes';
        
        const noButton = document.createElement('button');
        noButton.className = 'interaction-button no';
        
        // Set button text based on interaction type
        if (type === 'bridge') {
            yesButton.textContent = 'REACH OUT';
            noButton.textContent = 'STAY BACK';
        } else if (type === 'join') {
            yesButton.textContent = 'JOIN NETWORK';
            noButton.textContent = 'DECLINE';
        }
        
        // Add event listeners
        yesButton.addEventListener('click', () => this.handleInteraction(type, 'yes'));
        noButton.addEventListener('click', () => this.handleInteraction(type, 'no'));
        
        // Add buttons to container
        this.interactionContainer.appendChild(yesButton);
        this.interactionContainer.appendChild(noButton);
    }
    
    /**
     * Handle user interaction
     */
    handleInteraction(type, choice) {
        if (this.interactionTimeout) {
            clearTimeout(this.interactionTimeout);
            this.interactionTimeout = null;
        }
        
        // Store user choice
        this.userChoices[type] = choice;
        
        // Hide interaction interface
        this.interactionContainer.style.opacity = '0';
        setTimeout(() => {
            this.interactionContainer.style.display = 'none';
            this.options.textDisplay.innerHTML = "";
            this.options.textDisplay.className = '';
            
            // Play response sequence based on choice
            this.playInteractionResponse(type, choice);
        }, 500);
    }
    
    /**
     * Trigger a visual effect
     */
    triggerVisualEffect(effectName) {
        const effect = this.visualEffects[effectName];
        if (!effect) return;
        
        // Play effect-specific sound if available
        if (effectName === 'heartbeat') {
            this.playSound('epic-heartbeat.webm', 0);
        } else if (effectName === 'silence') {
            this.playSound('epic-silence.webm', 0);
        } else if (effectName === 'distortion') {
            this.playSound('epic-distortion.webm', 0);
        }
        
        // Show effect
        effect.style.opacity = '1';
        
        // Create particle effect based on effect type
        this.createParticleEffect(effectName);
        
        // Hide effect after duration
        setTimeout(() => {
            effect.style.opacity = '0';
        }, 3000);
    }
    
    /**
     * Create particle effect based on effect type
     */
    createParticleEffect(effectName) {
        // Different particle effects based on the effect type
        switch(effectName) {
            case 'catastrophe':
                this.createExplosionParticles();
                break;
            case 'cosmicUnravel':
                this.createVortexParticles();
                break;
            case 'arrival':
                this.createPortalParticles();
                break;
            case 'broadcast':
                this.createWaveParticles();
                break;
            case 'finalReveal':
                this.createStarburstParticles();
                break;
        }
    }
    
    /**
     * Create explosion particle effect
     */
    createExplosionParticles() {
        // Implementation would create an explosion particle effect
        console.log('Explosion particle effect triggered');
    }
    
    /**
     * Create vortex particle effect
     */
    createVortexParticles() {
        // Implementation would create a vortex particle effect
        console.log('Vortex particle effect triggered');
    }
    
    /**
     * Create portal particle effect
     */
    createPortalParticles() {
        // Implementation would create a portal particle effect
        console.log('Portal particle effect triggered');
    }
    
    /**
     * Create wave particle effect
     */
    createWaveParticles() {
        // Implementation would create a wave particle effect
        console.log('Wave particle effect triggered');
    }
    
    /**
     * Create starburst particle effect
     */
    createStarburstParticles() {
        // Implementation would create a starburst particle effect
        console.log('Starburst particle effect triggered');
    }
    
    /**
     * Play a sound with the given delay
     */
    playSound(filename, delay, alternateFile = null) {
        const audioCtx = this.options.audioContext;
        
        this.scheduledTimeouts.push(setTimeout(() => {
            // Try to use alternate file first if provided
            let buffer = null;
            if (alternateFile && this.additionalAudioBuffers[alternateFile]) {
                buffer = this.additionalAudioBuffers[alternateFile];
            } else {
                // Check in additional buffers first, then fall back to standard buffers
                buffer = this.additionalAudioBuffers[filename] || this.options.audioBuffers[filename];
            }
            
            if (buffer) {
                const src = audioCtx.createBufferSource();
                src.buffer = buffer;
                src.connect(audioCtx.destination);
                src.connect(this.analyser);
                src.start();
                
                // Update visualizer audio data
                if (this.analyser && this.analyserData) {
                    const analyser = this.analyser;
                    const analyserData = this.analyserData;
                    
                    // Set up animation loop to update visualizers
                    const updateVisualizers = () => {
                        if (!this.isActive) return;
                        
                        analyser.getFloatTimeDomainData(analyserData);
                        
                        // Update all visualizers with audio data
                        Object.values(this.visualizers).forEach(visualizer => {
                            if (visualizer.isActive) {
                                visualizer.updateAudioData(analyserData);
                            }
                        });
                        
                        requestAnimationFrame(updateVisualizers);
                    };
                    
                    updateVisualizers();
                }
            }
        }, delay * 1000));
    }
    
    /**
     * Update progress indicator
     */
    updateProgress(progress) {
        if (!this.progressBar) return;
        
        this.progressBar.style.width = `${progress * 100}%`;
        this.progressMarker.style.left = `${progress * 100}%`;
    }
    
    /**
     * Clear all scheduled timeouts
     */
    clearAllTimeouts() {
        if (this.scheduledTimeouts) {
            this.scheduledTimeouts.forEach(id => clearTimeout(id));
        }
        this.scheduledTimeouts = [];
    }
    
    /**
     * Clean up resources
     */
    cleanup() {
        // Stop visualizers
        Object.values(this.visualizers).forEach(visualizer => {
            if (visualizer.isActive) {
                visualizer.stop();
            }
        });
        
        // Clear timeouts
        this.clearAllTimeouts();
        
        // Hide UI elements
        this.progressContainer.style.opacity = '0';
        this.interactionContainer.style.display = 'none';
        
        // Hide all visual effects
        Object.values(this.visualEffects).forEach(effect => {
            effect.style.opacity = '0';
        });
        
        // Remove epic-specific class
        document.body.classList.remove('epic-mode');
    }
}

// Export EpicMode class
window.EpicMode = EpicMode;

