Of course. Here is the complete, updated, and enhanced build plan, incorporating the suggested improvements for a more robust, incremental integration testing strategy using mock implementations.

***

### **Enhanced Build Plan: Modular Web3 Digital Audio Workstation**

**Summary**
This document is a staged build plan for a fully modular, Web3-enabled digital audio workstation implemented in the browser. It breaks the system into self-contained directories—platform primitives, timing core, sequencing model, audio engines, Web3 asset handling, integration, and UI adapters—each with clearly defined deliverables, unit tests, contract tests, and incremental integration tests. The build proceeds in manageable chunks, with parallelizable sections where possible, and every stage produces artifacts and golden references to prove correctness and determinism.

The core enhancement is an **evolved integration strategy**. Instead of a single "big bang" integration at the end, this plan introduces mock implementations and intermediate integration tests at key milestones. This ensures that the core logic and data pipelines are validated early and continuously, de-risking the final assembly and making the process more robust. The end result remains a reproducible, deterministic DAW that can run entirely from on-chain assets, with a single source of musical time driving both Web Audio API and Tone.js engines, all wired together through tested contracts for reliable integration.

---

#### **0) Bootstrap, CI Spine, & Test Infrastructure (once)**
*   **Scope:** `/tests/harness.js`, `/tests/assert.js`, `/tests/mocks/`, repo scripts, CI.

*   **Deliverables:**
    *   Minimal test runner and assertion utilities.
    *   npm scripts: `test`, `test:unit`, `test:contract`, `test:int`, `lint`, `build`.
    *   CI workflow (Node + headless browser): runs lint, unit, contract, and then integration tests in sequence.
    *   Coverage and performance baselines saved as artifacts.
    *   **Mock Implementation Directory:** A dedicated `/tests/mocks/` directory containing lightweight, in-memory stubs of key modules. Initial mocks to be created:
        *   `mock-engine.js`: Implements the Engine contract; instead of playing audio, it logs scheduled events with timestamps to an array for inspection.
        *   `mock-resolver.js`: Implements the Web3 Resolver contract; returns byte-for-byte fixture data from memory without making network requests.
        *   `mock-worker-scheduler.js`: Simulates clock ticks in a deterministic, controllable way for testing timing-dependent logic without real-time waits.

*   **Tests / Gates:**
    *   Runner executes a dummy test suite; nonzero exit on failures.
    *   Initial code coverage ≥ 60% (to be ratcheted up per module).
    *   Local test runner time < 2s (sanity check).
    *   Mocks correctly implement their respective contract interfaces.

*   **Artifacts:**
    *   `/.ci/thresholds.json` (coverage targets, performance budgets).
    *   `/tests/mocks/` directory and initial mock implementations.

---

#### **1) Platform Primitives**
*   **Scope:** `/platform/audio-context.js`, `audio-worklet-loader.js`, `worker-scheduler.js`, `prng.js`

*   **Deliverables:**
    *   Safe `AudioContext` factory (handles latency hints, SAB feature detection).
    *   Worklet loader with support for standard URLs and Web3 inscription URIs.
    *   Worker-based high-resolution ticker (`postMessage` clock beats), with a `setTimeout` fallback.
    *   Deterministic Pseudo-Random Number Generator (e.g., xoshiro128** or splitmix64).

*   **Unit tests:**
    *   `platform.prng.test.js`: Verifies fixed seeds produce fixed output sequences; tests jump/skip determinism.
    *   `platform.worker-scheduler.test.js`: Emits ticks at the requested cadence; drift is < 1ms average in a simulated environment (`mock-worker-scheduler`).
    *   `platform.audio-worklet-loader.test.js`: Successfully loads a no-op worklet processor; is idempotent.

*   **Gate (Definition of Done):**
    *   Tick jitter p95 < 3ms (simulated clock).
    *   All unit tests pass; module coverage ≥ 80%.

*   **Artifacts:**
    *   `contracts/platform.json` (API signatures and expected behaviors).

---

#### **2) Time System**
*   **Scope:** `/time/transport-clock.js`, `tempo-map.js`, `quantize.js`, `scheduler.js`

*   **Deliverables:**
    *   `TransportClock`: Manages playback state (start/stop/seek) and converts between musical beats and absolute seconds.
    *   `TempoMap`: Supports constant tempo and linear tempo ramps.
    *   `Quantize`: Provides grid quantization with swing percentage and micro-offsets.
    *   `Scheduler`: Lookahead loop (uses the platform worker); calls a pluggable `target.schedule(event, time)` method.

*   **Unit tests:**
    *   `time.transport-clock.test.js`: Validates start/stop offsets, seek behavior, and BPM conversion accuracy.
    *   `time.tempo-map.test.js`: Checks tempo ramp integration for exactness and boundary event handling.
    *   `time.quantize.test.js`: Verifies swing at 0/50/100%; ensures micro-timings sum to zero (optional).
    *   `time.scheduler.test.js`: Confirms events are emitted exactly once, in correct order, and that lookahead horizon boundaries are precise.

*   **Gate:**
    *   Ramp timing error < 0.5ms across an 8-bar segment.
    *   Scheduler generates no duplicate events when horizons overlap.
    *   100% unit test pass rate.

*   **Artifacts:**
    *   `contracts/time.md` (A document defining the timing rules, invariants, and formulas).

---

#### **3) Sequencing Model (Headless)**
*   **Scope:** `/model/events.js`, `pattern.js`, `clip.js`, `track.js`, `song.js`, `groove.js`

*   **Deliverables:**
    *   Event structures (e.g., `NoteOn`/`Off` generated from a single Note+duration event), `SampleTrig`, `ParamChange`.
    *   A seedable `Pattern` data structure, `Clip` (which can contain a pattern or an audio segment), `Track`, and a `Song` aggregator.

*   **Unit tests:**
    *   `model.pattern.test.js`: Ensures note toggles produce correct `NoteOn`/`Off` events; confirms repeatability when using the platform's PRNG.
    *   `model.clip.test.js`: Tests pattern looping logic, audio clip windowing, and edge cases at clip boundaries.
    *   `model.song.test.js`: Verifies that events from multiple tracks are merged and sorted correctly by time; confirms output is stable across different seeds.

*   **Integration tests (New):**
    *   `integration.time-model.test.js`: This is the first major integration test. It instantiates a `Song` (Model), a `Scheduler` (Time), and wires them to the `mock-engine`. It runs a simple song fixture and asserts that the `mock-engine`'s event log is byte-for-byte identical to a pre-calculated golden log. This **proves the core scheduling pipeline is working correctly** before any audio code is written.

*   **Gate:**
    *   Deterministic: The same seed must produce an identical event list, byte-for-byte.
    *   Event Stability: Chunking the timeline into smaller lookaheads does not alter the set of generated events.
    *   `time-model` integration test passes.

*   **Artifacts:**
    *   `goldens/model/*.json` (Golden reference event lists for test fixtures).

---

#### **4) Web3 Access & Integrity**
*   **Scope:** `/web3/inscription-resolver.js`, `cache.js`, `integrity.js`, `manifest.js`

*   **Deliverables:**
    *   A multi-endpoint read resolver with fallback logic; includes content integrity checking (SRI/hash).
    *   A two-layer cache (in-memory and `CacheStorage`) using content hashes as keys.
    *   A loader for project and library manifests.

*   **Unit tests:**
    *   `web3.inscription-resolver.test.js`: Uses the `mock-resolver` to test fallback on endpoint errors, byte-for-byte integrity checks, and correct caching behavior.
    *   `web3.manifest.test.js`: Validates manifest schema; ensures errors for missing assets are descriptive.

*   **Gate:**
    *   Corrupted data (hash mismatch) results in a hard failure.
    *   Demonstrable >2x speedup on a warm fetch vs. a cold fetch (simulated).

*   **Artifacts:**
    *   `schemas/project.manifest.schema.json`.

---

#### **5) Assets**
*   **Scope:** `/assets/sample-loader.js`, `preset-loader.js`, `project-serializer.js`

*   **Deliverables:**
    *   Sample loader that can decode, cache, and verify audio data against an expected hash.
    *   Preset loader for parsing instrument/effect preset JSON.
    *   Project serializer that provides deterministic output and handles versioning/migrations.

*   **Unit tests:**
    *   `assets.sample-loader.test.js`: Decodes a fixture, verifies its hash, and confirms a cached asset is not re-decoded.
    *   `assets.project-serializer.test.js`: Tests a v1→v2 migration; proves that `JSON.stringify` output is stable, leading to a stable hash.

*   **Integration tests (New):**
    *   `integration.asset-pipeline.test.js`: Wires the `mock-resolver` to the `asset-loader` and `project-serializer`. This test simulates loading a full project manifest, "fetching" all assets via the mock, and verifying that the loaded data structures are correct. This validates the entire data-loading pipeline from manifest to in-memory representation.

*   **Gate:**
    *   Re-serializing a loaded project results in byte-identical output (idempotency).
    *   Decode failures clearly identify the failing asset ID.
    *   `asset-pipeline` integration test passes.

*   **Artifacts:**
    *   `goldens/assets/*.wav` (tiny audio fixtures), `goldens/project/*.json`.

---

*... subsequent stages continue in this enhanced format ...*

#### **6) Engine Contracts & Routing**
*   **Scope:** `/engine/engine.js`, `graph-router.js`, `/engine/fx/*`
*   **Deliverables:** `Engine` interface, `GraphRouter`, minimal FX library.
*   **Contract tests:** Use a fake engine to assert scheduling format.
*   **Gate:** Graph diff is empty; contract suite passes.
*   **Artifacts:** `contracts/engine.schedule.json`.

#### **7) WAEngine (Authoritative Path)**
*   **Scope:** `/engine/wa-engine.js`
*   **Deliverables:** Sample playback, basic synth voice, automation.
*   **Unit tests:** `wa-engine.test.js`, `wa-engine.offline.test.js` (render to hash).
*   **Gate:** p95 start-time error < 0.2ms; golden buffer hash matches.
*   **Artifacts:** `goldens/audio/waengine/8bars.hash.json`.

#### **8) ToneEngine (Adapter with Parity Targets)**
*   **Scope:** `/engine/tone-engine.js`
*   **Deliverables:** Adapter for Tone.js players/synths.
*   **Unit tests:** `tone-engine.test.js` (spy/mocks).
*   **Parity tests:** Feed same song to both engines; event logs must match; rendered hashes must be within tolerance.
*   **Gate:** Event log identical to WAEngine; hash matches within epsilon.
*   **Artifacts:** `goldens/audio/toneengine/8bars.hash.json`, `goldens/logs/fixture.events.json`.

#### **9) Integration: Full System Playback & Offline Render**
*   **Scope:** `/integration/project-player.js`, `render-offline.js`
*   **Description:** This stage is now the *final* assembly, swapping all mocks for their real implementations. Confidence is high due to the successful intermediate integration tests.
*   **Integration tests:**
    *   `integration.master.system.test.js`: The capstone test. Builds a minimal project from a manifest (using the real Web3 resolver), loads assets, and renders 8 bars using the WAEngine. Compares the resulting PCM hash against the golden reference.
    *   `integration.engine-matrix.test.js`: Runs the same manifest on both the WAEngine and ToneEngine. Asserts that event logs match and that rendered audio hashes are identical (for WAEngine) or within a tight epsilon (for ToneEngine).
*   **Gate:** "SYSTEM OK": All system-level tests pass with deterministic outputs. An engine can be swapped without any code changes in the project bootstrap logic.
*   **Artifacts:** `goldens/system-ok.json`.

#### **10) Control & History**
*   **Scope:** `/control/commands.js`, `history.js`
*   **Deliverables:** Undo/redo command system.
*   **Gate:** Undo/redo round-trip is byte-identical.
*   **Artifacts:** `contracts/commands.json`.

#### **11) UI Adapters**
*   **Scope:** `/ui-adapters/arrange-vm.js`, `stepseq-vm.js`
*   **Deliverables:** Read-only view models, command intents.
*   **Gate:** 100% of intents map to valid commands.

#### **12) Performance & Reliability**
*   **Scope:** Performance budgets, GC pressure, memory.
*   **Tests:**
    *   Microbenchmarks for critical paths.
    *   Long-run soak test: 10 minutes playback under a heavy, realistic load (e.g., 128 steps, 16 tracks, multiple FX).
    *   `reliability.soak.test.js`: No missed events, no increasing clock drift, and no unbounded heap growth (via heap snapshots).
*   **Gate:** All performance budgets are met.

#### **13) Packaging & Bootstrap**
*   **Scope:** `/index.html`, `/main.js`, inscriptions.
*   **Deliverables:** Bootstraps from a manifest ID, preloads assets.
*   **Integration tests:** `integration.bootstrap.test.js` (simulates DOM bootstrap).
*   **Gate:** Cold start to first audio < 1.5s in CI headless environment.

---

### **How to "Wire It All Together" with the Evolved Strategy**

The "wiring" is no longer a final, high-risk step but a continuous process of verification:

1.  **Contracts First:** `contracts/*.json` and `goldens/*.json` are the immutable glue. Mocks and real implementations alike adhere to them.
2.  **Incremental Integration:**
    *   The `Time+Model` pipeline was proven correct in Stage 3 using a `mock-engine`.
    *   The `Resolver->Asset` pipeline was proven correct in Stage 5 using a `mock-resolver`.
3.  **Engine Matrix Parity:** A single contract test suite runs against the `mock-engine`, `WAEngine`, and `ToneEngine`. This guarantees behavioral parity and that our mocks are faithful.
4.  **Final Assembly (`ProjectPlayer`):** The final assembly in Stage 9 is low-risk. It uses the same tested contracts but with the real implementations:
    *   `Resolver` (contract: bytes + integrity)
    *   `SampleLoader` (contract: buffer objects)
    *   `Song` (contract: `getEventsInRange`)
    *   `Scheduler` (contract: `target.schedule(e, whenSec)`)
    *   `Engine` (contract: `schedule/setTempo/connectTrack`)
    *   ...and so on for all modules.
5.  **Golden System Test:** The `master.system.test.js` is the ultimate proof. If it stays green, the entire application, from data fetching to audio rendering, works as a deterministic, cohesive unit.