
---

## Summary

The goal is to build a fully modular, browser‑based digital audio workstation (DAW) that can play back projects deterministically.  The system is broken into self‑contained directories—platform primitives, timing core, sequencing model, asset handling, engine contracts, audio engines, integration, control/history, UI adapters, performance, and packaging.  Each directory has clearly defined deliverables, unit/contract tests, and promotion gates.  The build proceeds in manageable stages, with parallelizable sections where possible.  Every stage produces artifacts and golden references to prove correctness and determinism.  Real‑time performance is explicitly tested under load and across browsers, and resource management tests ensure the system doesn’t leak memory or exceed CPU budgets.  Once each module passes its tests and meets performance budgets, the whole system can be assembled and is expected to work “out of the box.”

---

## 0) Bootstrap & CI spine (once)

**Scope:** `/tests/harness.js`, `/tests/assert.js`, repo scripts, CI.

* **Deliverables**

  * Minimal test runner and assertion utils.
  * NPM scripts: `test`, `test:unit`, `test:int`, `lint`, `build`.
  * CI workflow: Node + multiple headless browsers (Chrome, Firefox, Safari if available) to run unit tests first, then integration tests.
  * Baselines for test coverage, performance, and memory usage saved as artifacts.

* **Tests / Gates**

  * Runner executes a dummy test suite; fails on any nonzero exit.
  * Initial coverage threshold ≥ 60%; increments as modules mature.
  * Local test timing < 2 s on baseline hardware.
  * CI must run tests in at least two browsers (Chrome and Firefox) to detect API differences.

* **Artifacts**

  * `/.ci/thresholds.json` holds coverage targets, perf budgets, and memory budgets for later stages.

---

## 1) Platform primitives

**Scope:** `/platform/audio-context.js`, `audio-worklet-loader.js`, `worker-scheduler.js`, `prng.js`

* **Deliverables**

  * Safe `AudioContext` factory (latency hints, sample‑rate sniff).
  * Worklet loader supporting URL loading.
  * Worker‑based ticker using `postMessage`; fallback to main thread.
  * Deterministic PRNG (e.g., xoshiro128\*\*).

* **Unit tests**

  * `platform.prng.test.js`: fixed seeds → fixed sequences; jump/skip determinism.
  * `platform.worker-scheduler.test.js`: emits ticks at requested cadence; drift < 1 ms avg in simulated time.
  * `platform.audio-worklet-loader.test.js`: loads a no‑op processor; idempotent.
  * Resource test: scheduler can run for 10 minutes without unbounded heap growth.

* **Gate (Definition of Done)**

  * Tick jitter p95 < 3 ms (simulated clock).
  * Coverage ≥ 80%.
  * Worker and fallback both pass.
  * Memory allocation remains stable over long‑run test (e.g., RSS plateau or < 5 % growth).

* **Artifacts**

  * `contracts/platform.json` (API signatures + expected behaviors).

---

## 2) Time system

**Scope:** `/time/transport-clock.js`, `tempo-map.js`, `quantize.js`, `scheduler.js`

* **Deliverables**

  * `TransportClock`: start/stop/seek; beats↔seconds conversion.
  * `TempoMap`: constant tempo plus linear ramps.
  * `Quantize`: grid, swing %, micro‑offsets.
  * `Scheduler`: look‑ahead loop (uses worker) with pluggable `target.schedule`.

* **Unit tests**

  * `time.transport-clock.test.js`: start/stop offsets; seek; BPM conversion.
  * `time.tempo-map.test.js`: ramp integration exactness; boundary events.
  * `time.quantize.test.js`: swing at 0 / 50 % produces expected offsets; microtiming offsets sum to zero.
  * `time.scheduler.test.js`: events emitted exactly once and in order; horizon boundaries exact.

* **Gate**

  * Ramp error < 0.5 ms across 8 bars.
  * No duplicate events in overlapping horizons.
  * 100 % test pass; coverage ≥ 80 %.
  * Low‑load jitter < 3 ms p95; high‑load jitter (CPU load simulation) < 10 ms p95.

* **Artifacts**

  * `contracts/time.md` (timing rules & invariants).

---

## 3) Sequencing model (headless)

**Scope:** `/model/events.js`, `pattern.js`, `clip.js`, `track.js`, `song.js`, `groove.js`

* **Deliverables**

  * Event structs: `NoteOn/NoteOff` generated from `NoteOn+dur`, `SampleTrig`, `ParamChange`.
  * `Pattern` (seedable), `Clip` (pattern/audio), `Track` types, `Song` aggregator.
  * All operations are pure and deterministic given a seed.

* **Unit tests**

  * `model.pattern.test.js`: toggles → correct `NoteOn/Off`; repeatability with PRNG.
  * `model.clip.test.js`: pattern loop math; audio clip windows; edge cases.
  * `model.song.test.js`: multi‑track merge sorted by time; stable across seeds.

* **Gate**

  * Deterministic: same seed → identical event lists byte‑for‑byte.
  * Event stability under horizon slicing (chunking doesn’t change set).
  * Coverage ≥ 80 %.
  * Golden event lists stored in `goldens/model/*.json`.

* **Artifacts**

  * `goldens/model/*.json` (event fixtures).

---

## 4) Asset access & integrity

*Original Web3 complexity has been removed; asset retrieval happens over standard HTTP with caching.*

**Scope:** `/assets/sample-loader.js`, `preset-loader.js`, `project-manifest.js`, `cache.js`, `integrity.js`

* **Deliverables**

  * Sample loader: fetches WAV/OGG/MP3 files via fetch, decodes with Web Audio API, caches in memory and `CacheStorage`.
  * Preset loader: parses preset JSON files.
  * Manifest loader: loads project files (song structure, sample references); schema validation.
  * Integrity checker: optional content‑hash verification (e.g., SHA‑256) to detect corruption.

* **Unit tests**

  * `assets.sample-loader.test.js`: decode fixture; hash verify; cached path not re‑decoding; throws on decode failure.
  * `assets.preset-loader.test.js`: valid presets parse; invalid ones yield descriptive errors.
  * `assets.manifest.test.js`: schema validate; missing asset errors are descriptive.
  * Cold vs warm fetch speedup > 2× (simulated network) to demonstrate caching.

* **Gate**

  * Corrupt bytes → hard fail with hash mismatch.
  * Re‑serializing a loaded manifest → identical JSON bytes (idempotent).
  * Resource release: decoded `AudioBuffer`s are held only while needed; they are released/disposed when tracks are removed or on `dispose()`.

* **Artifacts**

  * `schemas/project.manifest.schema.json`.

---

## 5) Engine contracts & routing

**Scope:** `/engine/engine.js`, `graph-router.js`, `/engine/fx/*`

* **Deliverables**

  * Engine interface: `schedule`, `setTempo`, `connectTrack`, `setTrackGain`, `dispose`.
  * `GraphRouter` builds per‑track FX chains and connects them to the master.
  * Minimal FX modules (gain, biquad, convolver, compressor) with identical parameter names across engines.
  * All engines must implement identical public APIs.

* **Unit tests**

  * `engine.graph-router.test.js`: builds declared graph; re‑entrant connections safe; `setTrackGain` reflects on `AudioParams` (mock).
  * `engine.fx.*.test.js`: param mapping & default values.
  * Contract test: `tests/contracts/engine.schedule.contract.test.js` uses a fake engine to assert event scheduling shape & order.

* **Gate**

  * Graph diff (spec vs built) = Ø (no missing nodes).
  * Contract suite passes for all engines.
  * Memory checks: graph creation and disposal should not leak (heap snapshot difference < 5 % after repeated creation/disposal cycles).

* **Artifacts**

  * `contracts/engine.schedule.json` (event envelope schema).

---

## 6) WAEngine (authoritative implementation)

**Scope:** `/engine/wa-engine.js`

* **Deliverables**

  * Sample playback via `AudioBufferSourceNode` (ABSN) with offset/duration; polyphony management.
  * Basic synth voice (e.g., `OscillatorNode` + envelopes) or Worklet synth stub for extensibility.
  * Parameter automation mapping.
  * `dispose()` cleans up all nodes and frees any retained buffers.

* **Unit tests**

  * `engine.wa-engine.test.js`: schedules start/stop accurately; handles tempo changes; parameter ramps.
  * `engine.wa-engine.offline.test.js`: render via `OfflineAudioContext` → hash equals golden for fixture song.
  * Long‑run audio test: play a synthetic 10‑minute sequence offline; ensure no drift in start times and buffer size stable.

* **Gate**

  * Start‑time error p95 < 0.2 ms in Offline context.
  * Golden buffer hash matches (deterministic).
  * CPU occupancy measured during real‑time test < 30 % on baseline hardware.
  * All nodes are garbage‑collected after `dispose()` (verified by heap snapshots).

* **Artifacts**

  * `goldens/audio/waengine/8bars.hash.json`.

---

## 7) ToneEngine (adapter for Tone.js)

**Scope:** `/engine/tone-engine.js`

* **Deliverables**

  * Tone players/synths invoked using absolute seconds.
  * Mirror `setTempo(bpm, whenSec)` into `Tone.Transport.bpm`; avoid `Tone.Transport.schedule` for musical events (use direct instrument APIs).
  * Adapter cleans up created Tone objects and stops the `Tone.Transport` on `dispose`.

* **Unit tests**

  * `engine.tone-engine.test.js`: translate absolute `whenSec` to Tone calls (spy/mocks); tempo mirrored at exact times.
  * Parity tests: feed the same fixture song to WAEngine offline and to ToneEngine live-recorded into an equivalent offline graph; compare event logs and rendered hashes within an epsilon tolerance.

* **Gate**

  * Event log identical to WAEngine for the fixture.
  * Rendered hash within tolerance (allowing denormals/noise floor diff).
  * All Tone objects destroyed on disposal; no residual timers in `Tone.Transport`.
  * Cross‑browser test: ToneEngine behaves identically in Chrome and Firefox.

* **Artifacts**

  * `goldens/audio/toneengine/8bars.hash.json`
  * `goldens/logs/fixture.events.json`

---

## 8) Integration: project playback & offline render

**Scope:** `/integration/project-player.js`, `render-offline.js`

* **Deliverables**

  * `ProjectPlayer` wires: Manifest loader → Assets → Song → Graph → Engine → Scheduler → Clock.
  * Offline renderer: WAEngine + `OfflineAudioContext`; mirrors live schedule for deterministic rendering.
  * Player cleans up all components on stop/dispose.

* **Integration tests**

  * `integration.master.system.test.js`: build a minimal manifest → render 8 bars → compare (1) event log, (2) PCM hash, (3) memory footprint.
  * `integration.engine-matrix.test.js`: run the same manifest on both engines; assert logs match and hashes match/epsilon.
  * Real‑time stress test: run 16 tracks with 128 steps for 10 minutes in a headless browser; no missed events; drift stays within specified jitter threshold; CPU and memory remain within budgets.

* **Gate**

  * “SYSTEM OK” with deterministic outputs.
  * Engine swapping (WAEngine ↔ ToneEngine) requires no code changes.
  * Resource cleanup: after playback stops, heap usage returns to baseline (within 5 %).
  * Real‑time stress test passes in both Chrome and Firefox.

* **Artifacts**

  * `goldens/system-ok.json`.

---

## 9) Control & history

**Scope:** `/control/commands.js`, `history.js`

* **Deliverables**

  * Command system for edit operations: add/move clip, change BPM, toggle step; each command has an inverse for undo/redo.
  * History manager supports linear and branching undo/redo, compaction of similar commands, and invalidation of redo after new ops.

* **Unit tests**

  * `control.history.test.js`: linear and branching undo/redo; command compaction; redo invalidation after new op.
  * Commands return exact state diffs; can be consumed by UI adapters.

* **Gate**

  * Undo/redo round‑trip leaves model byte‑identical.
  * Command payloads match the contract schema.
  * History memory use remains bounded over long edit sessions (snapshot differences < 5 %).

* **Artifacts**

  * `contracts/commands.json` (command payload schema).

---

## 10) UI adapters

*These adapters map UI “intents” to command payloads without coupling to audio playback.  They should be robust, cover all editing features, and be easily testable.*

**Scope:** `/ui-adapters/arrange-vm.js`, `stepseq-vm.js`, `piano-roll-vm.js` (optional)

* **Deliverables**

  * Read‑only view models representing the current arrangement (clips, tracks, cursor) and step sequencer (lanes, steps, toggles).
  * Mapping of user actions (dragging a clip, toggling a step, adjusting a tempo) to command intents.
  * Comprehensive property tests to ensure all UI events produce valid commands.
  * Integration with history manager (commands emitted from UI update history).

* **Unit tests**

  * `ui.arrange-vm.test.js`: selection, cursor movement, clip projections, drag‑drop boundaries.
  * `ui.stepseq-vm.test.js`: lane creation, step toggles → correct command intents; swing quantization mapping.
  * `ui.piano-roll-vm.test.js` (if implemented): note editing, velocity changes → proper command translation.
  * Property‑based tests: for any possible UI event, there exists a corresponding command and the resulting model state matches expectations.

* **Gate**

  * 100 % of UI intents map to valid commands (property test pass).
  * Command payloads conform to `contracts/commands.json`.
  * UI adapters do not leak memory (no listeners remain after view destroyed).
  * End‑to‑end UI simulation test: dispatch a series of user actions, check that resulting playback renders exactly as expected when scheduled through the player.

---

## 11) Performance & reliability

**Scope:** Perf budgets, garbage collection pressure, memory

* **Deliverables**

  * Microbenchmarks for scheduler tick, event range query, engine.schedule.
  * Long‑run soak test: 10‑minute playback @ 128 steps, 16 tracks; repeated creation and disposal of projects.
  * Cross‑browser performance matrix: run the same tests in Chrome, Firefox, and Safari to detect engine differences.
  * Memory profiling harness using browser performance APIs or JS heap snapshots.

* **Tests**

  * `perf.scheduler.bench.js`: p95 tick < 3 ms under normal load; < 10 ms under simulated CPU load (e.g., busy‑loop in worker).
  * `reliability.soak.test.js`: no missed events; drift stays within specified jitter; no unbounded heap growth; CPU stays below budget.
  * `perf.crossbrowser.test.js`: ensures scheduler, engine, and render times consistent across browsers within defined tolerance.
  * `memory.stress.test.js`: repeatedly load/unload large numbers of samples and projects; verify that garbage‑collected memory returns to baseline.

* **Gate**

  * Budgets met and stored in `.ci/thresholds.json` for each supported browser.
  * No memory leaks across repeated runs (heap growth < 5 %).
  * CPU occupancy remains below 30 % in stress tests.
  * CI will fail if cross‑browser differences exceed tolerance.

---

## 12) Packaging & bootstrap

**Scope:** `/index.html`, `/main.js`

* **Deliverables**

  * Main entry point that bootstraps from a project manifest ID or URL; selects engine based on user preference or feature detection.
  * Preloads and pins assets; starts the player; provides UI controls for play/stop, engine selection, and basic transport operations.
  * Cold start optimised: minimal bundle, lazy load of heavy modules (e.g., Tone.js) until needed.
  * Cross‑browser compatibility with proper feature detection (e.g., `AudioWorklet` support).

* **Integration tests**

  * `integration.bootstrap.test.js`: simulate a DOM bootstrap; fetch a small manifest via stubbed loader; start/stop successfully.
  * `integration.coldstart.test.js`: measure cold start to first audio; must be < 1.5 s with cached samples in headless CI; gracefully handle slower networks by displaying a spinner.
  * `integration.browsermatrix.test.js`: run bootstrap tests in all supported browsers; ensure no API errors.

* **Gate**

  * Cold start to first audio < 1.5 s with cached samples; < 3 s on first load.
  * Bundle size stays within target (e.g., < 200 KB gzipped for core; heavy modules lazy loaded).
  * Feature detection gracefully falls back to WAEngine if `AudioWorklet` unsupported.
  * Packaging includes appropriate disposal of engine and graph on page unload to prevent memory leaks.

---

## How to “wire it all together” at the end

* **Contracts first:** produce schemas in `/contracts/*` and golden logs/hashes in `/goldens/*`.  These are the glue and the proof for integration.
* **Engine matrix:** a single engine contract test suite runs against both WAEngine and ToneEngine using the same fixture songs.  This ensures parity.
* **ProjectPlayer assembly:** final assembly uses only published contracts:

  * Manifest loader (contract: JSON schema, event lists).
  * Sample loader (contract: returns `AudioBuffer`).
  * Song (contract: `getEventsInRange` returns sorted list).
  * Scheduler (contract: calls `target.schedule(event, whenSec)` at deterministic times).
  * Engine (contract: `schedule`, `setTempo`, `connectTrack`, `dispose`).
  * GraphRouter (contract: maps track IDs to node IDs).
  * Clock (contract: beats↔seconds; start/stop).
* **Golden system test:** `master.system.test.js` remains green with event log equality and PCM hash equality across engines and browsers.
* **End‑to‑end smoke:** `main.js` bootstrap points to a small manifest; CI runs a headless smoke that starts/stops and renders 1 bar offline in each supported browser; verifies CPU and memory budgets.

---

## Build order & parallelism

* **Parallel tracks:** Stages 1–3 (Platform + Time + Model) and Stages 4–5 (Assets + Engine contracts) can proceed in parallel after Stage 0.
* **Sequential gates:** Engines depend on Time + Model + Assets; WAEngine before ToneEngine; Integration after both engines; UI adapters and control/history can proceed in parallel once model and engine contracts stabilise.
* **Performance & packaging:** run continuously as modules mature; update budgets in `.ci/thresholds.json`.

---

## Promotion criteria (what “ready to move on” means)

For each directory:

* ✅ Unit tests green (≥ 80 % coverage; ratchet upward for critical modules like Time and Engine).
* ✅ Contract tests green (schemas + behavioural invariants).
* ✅ Golden artefacts updated intentionally (PR includes reason).
* ✅ Performance and memory budgets met (per browser).
* ✅ No TODOs or unimplemented methods in public APIs; breaking changes require contract version bump.
* ✅ Cross‑browser tests pass if applicable.

---

## Notes on determinism & parity

* Always convert beats → absolute seconds in the scheduler using `TempoMap` (including ramps and swing) before calling any engine.  Never rely on two engines sharing the same clock.
* Parity tests ensure that WAEngine and ToneEngine produce the same event envelopes and (within tolerance) identical rendered audio.
* Real‑time performance can differ from offline determinism; soak tests in Stage 11 and cross‑browser tests ensure acceptable drift and jitter.

---

### Visual “map” of the whole

```
Platform ─┬─ PRNG
          ├─ WorkerScheduler  ──▶ Time.Scheduler ──▶ Engine.schedule()
          └─ WorkletLoader

Time ──▶ TransportClock + TempoMap + Quantize
                         ▲
Model ── Song ─ Tracks ─┘ (getEventsInRange in beats)

Assets ──▶ SampleLoader / PresetLoader / ManifestLoader

Engine Interface ─┬─ WAEngine ──▶ GraphRouter ─▶ FX ─▶ Master
                  └─ ToneEngine ─┘

Integration ──▶ ProjectPlayer / render‑offline

Control/History ─▶ Commands & History

UI Adapters ──▶ ArrangeVM / StepSeqVM (+ optional PianoRollVM)

Performance ──▶ Benchmarks & Soak tests

Packaging ──▶ main.js bootstrap & CI
```

