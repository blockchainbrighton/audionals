Here is a **clear, comprehensive prompt** that generates the **first segment of the Modular Web3 DAW Build Plan (v2.0)**, including all:

- ✅ **Modules**
- ✅ **Test modules**
- ✅ **Expected results and computations**
- ✅ **Clear pass/fail criteria**
- ✅ **Instructions for execution and verification**

This prompt can be used with an AI code assistant or generator to produce the first working segment (e.g., Platform Primitives + Tests + Mocks + Contracts + Goldens), ready for CI validation.

---

## 🧠 **Prompt for Generating First Segment: Platform Primitives (v2.0)**

> **Generate the complete implementation, unit tests, mocks, contracts, goldens, and CI configuration for the first build segment: "Platform Primitives" — as defined in Modular Web3 DAW Build Plan v2.0. Ensure full compliance with the mock-first integration strategy, deterministic behavior, and test-driven development principles.**

### 🔧 **Scope**
Implement and test the following modules from `/platform/`:
- `audio-context.js`
- `worklet-loader.js`
- `worker-scheduler.js`
- `prng.js`
- `units.js`

Also include:
- Unit tests for each module
- Mock implementations in `/tests/mocks/`
- Contract definitions in `/contracts/platform.json`
- Golden artifacts where applicable
- CI configuration updates in `.github/workflows/ci.yml`

---

### 📁 **Directory Structure to Generate**

```
/
├── platform/
│   ├── audio-context.js
│   ├── worklet-loader.js
│   ├── worker-scheduler.js
│   ├── prng.js
│   └── units.js
├── tests/
│   ├── platform.audio-context.test.js
│   ├── platform.worklet-loader.test.js
│   ├── platform.worker-scheduler.test.js
│   ├── platform.prng.test.js
│   ├── platform.units.test.js
│   └── mocks/
│       ├── mock-audio-context.js
│       ├── mock-worker-scheduler.js
│       └── mock-engine.js
├── contracts/
│   └── platform.json
├── goldens/
│   └── worklets/
│       └── noop.processor.js
└── .github/
    └── workflows/
        └── ci.yml
```

---

### 📌 **Requirements by Module**

#### 1. `platform/audio-context.js`
- Factory function that returns a safe `AudioContext` instance
- Detects `SharedArrayBuffer` support
- Respects latency hints (`latencyHint: 'interactive'`)
- Throws descriptive error if Web Audio API is unavailable

##### ✅ Test Coverage
- `platform.audio-context.test.js`:  
  - Instantiates successfully in headless environment  
  - Fails gracefully with unsupported browser  
  - Latency hint respected

---

#### 2. `platform/worklet-loader.js`
- Loads `.js` file or Inscription ID via resolver
- Caches by content hash (BLAKE3 preferred)
- Supports SRI-style verification
- Returns `AudioWorkletNode` constructor

##### ✅ Test Coverage
- `platform.worklet-loader.test.js`:  
  - Loads valid no-op processor  
  - Idempotent on same hash  
  - Verifies SRI hash  
  - Fails on corrupt bytes

##### 📦 Golden Artifact
- `goldens/worklets/noop.processor.js`: Minimal valid AudioWorkletProcessor

---

#### 3. `platform/worker-scheduler.js`
- Uses `MessageChannel` + `performance.now()` for high-precision ticking
- Emits timestamped ticks every 1ms
- Sub-millisecond interpolation support
- Drift < 0.1ms over 10s simulation

##### ✅ Test Coverage
- `platform.worker-scheduler.test.js`:  
  - Emits ticks at correct intervals  
  - Measures drift under simulated load  
  - Handles tick overflow gracefully

##### 🧪 Mock Implementation
- `mock-worker-scheduler.js`: In-memory ticker for testing

---

#### 4. `platform/prng.js`
- Implements `xoshiro128**` algorithm
- Supports deterministic seed jump/skip
- Fixed seed → fixed sequence
- Skip(n) equivalent to n calls to next()

##### ✅ Test Coverage
- `platform.prng.test.js`:  
  - Same seed → same output  
  - Jump/skip deterministic  
  - Output distribution uniform (chi-squared)

---

#### 5. `platform/units.js`
- Exports constants:
  ```js
  export const SECOND = 1;
  export const MS = 0.001;
  export const BEAT = 1; // default unit
  ```

##### ✅ Test Coverage
- `platform.units.test.js`:  
  - Constants match expected values  
  - Prevents accidental mutation

---

### 🧩 **Mock Implementations (in `/tests/mocks/`)**

#### `mock-audio-context.js`
- Simulates minimal `AudioContext` with `.sampleRate`, `.currentTime`, `.close()`
- No real audio nodes

#### `mock-worker-scheduler.js`
- In-memory ticker emitting ticks at fixed interval
- No real threading or timing

#### `mock-engine.js`
- Logs scheduled events with timestamps
- Implements Engine contract interface

---

### 📜 **Contract Definition**

#### `/contracts/platform.json`
```json
{
  "version": "1.0",
  "modules": [
    {
      "name": "AudioContext",
      "methods": ["create()", "close()", "sampleRate", "currentTime"]
    },
    {
      "name": "WorkletLoader",
      "methods": ["load(urlOrId)", "unload(hash)"]
    },
    {
      "name": "WorkerScheduler",
      "methods": ["start()", "stop()", "onTick(tickFn)"],
      "timingGuarantees": {
        "tickIntervalMs": 1,
        "maxDriftMs": 0.1
      }
    },
    {
      "name": "PRNG",
      "methods": ["next()", "jump()", "skip(n)"],
      "deterministic": true
    },
    {
      "name": "Units",
      "exports": ["SECOND", "MS", "BEAT"]
    }
  ]
}
```

---

### 🧪 **CI Configuration Update**

#### `.github/workflows/ci.yml`
Ensure:
- Runs Node.js 18+
- Executes unit tests: `npm run test:unit`
- Enforces coverage threshold: ≥80%
- Enforces performance budgets:
  - `worker-scheduler.tick.p95` < 3ms
  - `testRunner.duration` < 2s

Example:
```yaml
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: '18'
      - run: npm install
      - run: npm run test:unit
      - run: npm run lint
      - run: npm run perf
```

---

### 🧾 **Pass Criteria for This Segment**

✅ All unit tests pass  
✅ Coverage ≥ 80%  
✅ No DOM/window references (SSR-safe)  
✅ All mocks implement contract interfaces  
✅ Timing drift < 0.1ms over 10s  
✅ Deterministic PRNG passes statistical tests  
✅ Golden artifacts match checksums  
✅ CI pipeline executes without error  
✅ No TODOs in public APIs  

---

### 🎯 **Next Steps After This Prompt**

Once generated:
1. Run `npm run test:unit`
2. Validate mock-first integrations
3. Update goldens intentionally
4. Promote to next phase (Time System)

---

> 🚀 **This prompt ensures that the first critical segment of the Modular Web3 DAW is fully testable, verifiable, and ready for incremental integration.**

Let’s generate it now.