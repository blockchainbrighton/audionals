Of course. Based on the comprehensive plan provided, here is a clear and actionable prompt designed to generate the entire first segment: **"Bootstrap, CI Spine, & Test Infrastructure."**

This prompt is structured to ensure the generated output includes all specified modules, tests, mock implementations, and configuration artifacts, along with a clear definition of success for this initial stage.

***

### **Prompt for Generating Segment 0: Bootstrap, CI Spine, & Test Infrastructure**

**Objective:**
Generate the complete and fully functional codebase for the foundational **"Segment 0: Bootstrap, CI Spine, & Test Infrastructure"** of the Modular Web3 DAW project. The output must be production-ready, follow modern JavaScript best practices, and establish the core testing and continuous integration (CI) framework upon which all subsequent modules will be built.

The system must be self-contained and verifiable. When the generated code is executed via `npm test`, it should run a suite of self-validating tests that prove the infrastructure's correctness and adherence to all specified gates.

**Core Requirements:**
Generate all necessary files, including `package.json`, directory structures, source code for the test harness, assertion library, mock stubs, and CI configuration. The code should be clear, well-commented, and immediately usable.

---

### **Detailed Generation Instructions:**

**1. Project Structure:**
Create the following directory and file structure:
```
/
├── .github/
│   └── workflows/
│       └── ci.yml
├── .ci/
│   └── thresholds.json
├── tests/
│   ├── mocks/
│   │   ├── mock-engine.js
│   │   ├── mock-resolver.js
│   │   ├── mock-worker-scheduler.js
│   │   └── mock-audio-context.js
│   ├── harness.js
│   ├── assert.js
│   └── bootstrap.test.js
└── package.json
```

**2. `package.json`:**
Generate a `package.json` file with the following characteristics:
*   **Scripts:**
    *   `"test"`: "node tests/harness.js"
    *   `"test:unit"`: "node tests/harness.js --grep='unit'" (or similar filtering mechanism)
    *   `"test:contract"`: "node tests/harness.js --grep='contract'"
    *   `"test:int"`: "node tests/harness.js --grep='integration'"
    *   `"lint"`: (A placeholder script, e.g., `echo "Linting not yet configured"`)
    *   `"build"`: (A placeholder script, e.g., `echo "Build not yet configured"`)
    *   `"perf"`: (A placeholder script, e.g., `echo "Performance tests not yet configured"`)
    *   `"golden:update"`: (A placeholder script, e.g., `echo "Golden file updates not yet configured"`)
*   **Dependencies:** Include necessary dev dependencies for future linting, coverage, etc. (e.g., `eslint`, `c8` or `nyc`). For now, no production dependencies are needed.

**3. Test Harness (`/tests/harness.js`):**
*   Implement a minimal, dependency-free test runner.
*   **Functionality:**
    *   It must automatically discover and run test files (e.g., all `*.test.js` files).
    *   It must support `async/await` for asynchronous tests.
    *   It must allow for grouping of tests (e.g., using `describe()`/`it()` or a similar pattern).
    *   It must report the total number of passed and failed tests.
    *   It must measure and report the execution time for each test suite and the total run time.
    *   It must exit with a non-zero status code if any test fails.

**4. Assertion Library (`/tests/assert.js`):**
*   Create a lightweight assertion library to be used by all tests.
*   **Assertions to Implement:**
    *   `assert.ok(value, message)`: Checks for truthiness.
    *   `assert.equal(actual, expected, message)`: For primitive equality.
    *   `assert.deepEqual(actual, expected, message)`: For deep object and array equality.
    *   `assert.throws(fn, message)`: Asserts that a function `fn` throws an error.
    *   `assert.close(actual, expected, epsilon, message)`: Crucial for floating-point comparisons, ensuring `|actual - expected| < epsilon`.
    *   `assert.bufferEqual(buf1, buf2, message)`: For byte-for-byte comparison of binary buffers (like `ArrayBuffer` or `Buffer`).

**5. Mock Implementations (`/tests/mocks/`):**
*   Create stub files for the following mocks. For this initial segment, they can be lightweight classes or objects with placeholder methods that log their calls.
*   `mock-engine.js`:
    *   Implement an `Engine` class with a `schedule(event, timestamp)` method.
    *   The `schedule` method should push an object `{ event, timestamp }` into an internal `log` array for later inspection.
*   `mock-resolver.js`:
    *   Implement an `InscriptionResolver` class with a `resolve(inscriptionId)` method.
    *   This method should return hard-coded fixture data from an internal map (e.g., `return this.fixtures[inscriptionId]`).
*   `mock-worker-scheduler.js`:
    *   Implement a `WorkerScheduler` class that simulates deterministic clock ticks without using `setTimeout` or real-time waits. It should have a `start()` method and an event emitter for `tick` events.
*   `mock-audio-context.js`:
    *   Provide a fake implementation of the Web Audio API, including dummy `createGain()`, `createOscillator()`, etc., that return objects with chainable `connect()` methods. This is for testing audio graph construction without a real audio environment.

**6. CI Configuration (`/.github/workflows/ci.yml`):**
*   Generate a GitHub Actions workflow file.
*   **Workflow Steps:**
    1.  Checkout the code.
    2.  Set up Node.js (use a matrix strategy for Node 18+).
    3.  Install npm dependencies (`npm ci`).
    4.  Run all tests (`npm test`).
    *   The workflow should be triggered on `push` and `pull_request` to the `main` branch.

**7. Configuration Artifacts (`/.ci/thresholds.json`):**
*   Create the `thresholds.json` file with the initial values as specified in the plan:
    ```json
    {
      "coverage": { "min": 60, "ratchet": true },
      "perf": { "testRunner": 2000, "schedulerTickP95": 3 }
    }
    ```

**8. Verification Test Module (`/tests/bootstrap.test.js`):**
*   Create a test file that validates the entire bootstrap setup itself.
*   **Test Cases to Include:**
    *   **Harness Sanity Check:** A simple test suite with one passing `assert.ok(true)` test and one intentionally failing `assert.equal(true, false)` test (commented out) to prove the runner can detect both success and failure.
    *   **Assertion Library Validation:** A test for each function in `assert.js` to ensure it behaves correctly (e.g., `assert.deepEqual` correctly compares nested objects, `assert.close` works for floats).
    *   **Mock Interface Adherence:** A test that imports the mock modules and asserts that they have the expected methods (e.g., `assert.ok(new MockEngine().schedule)`).
    *   **CI Failure Simulation:** A primary test that runs a dummy suite and asserts success. The harness must be configured to cause the CI pipeline to fail if this test file reports an error.

---

### **Definition of Done (Gates for Segment 0):**

The generated output will be considered complete and correct when the following conditions are met **without any modification**:

1.  **All Tests Pass:** Running `npm test` locally executes the `bootstrap.test.js` suite and reports 100% success.
2.  **CI Pipeline Passes:** A commit of the generated code to a GitHub repository triggers the `ci.yml` workflow, and it completes successfully.
3.  **Failure is Detected:** If a test in `bootstrap.test.js` is changed to fail (e.g., `assert.ok(false)`), both the local `npm test` command and the CI pipeline must fail.
4.  **Performance Sanity Check:** The total execution time for the local test runner (as reported by `harness.js`) must be less than 2 seconds.
5.  **Coverage Threshold:** The initial test suite must achieve a minimum of 60% code coverage on the `harness.js` and `assert.js` modules (this can be checked manually or by adding a coverage script using `c8`).
6.  **Artifacts are Correct:** All generated files (`.yml`, `.json`, `.js`) are present in the correct locations and contain the specified content.

When all these gates are passed, the bootstrap phase is complete, and the project is ready for **Segment 1: Platform Primitives**.