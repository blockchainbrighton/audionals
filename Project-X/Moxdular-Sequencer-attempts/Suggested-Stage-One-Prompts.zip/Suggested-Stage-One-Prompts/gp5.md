Here’s a clean, complete **first-segment generation prompt** that covers **all modules, test modules, computations, result reporting, and pass criteria** for the bootstrap phase.
It’s designed so that if you feed it into a code generation system, you’ll get a working, verifiable, and self-diagnosing test harness for the Modular Web3 DAW build plan v2.0.

---

**Prompt:**

> You are to generate the **first segment** of the Modular Web3 DAW system (Plan v2.0 – Final & Production-Ready with Mock-First Integration). This segment is **Phase 0: Bootstrap, CI Spine, & Test Infrastructure** — the foundation on which all further phases will depend.
>
> **Goals:**
>
> 1. Implement all modules in Phase 0 exactly as described in the build plan.
> 2. Implement corresponding unit tests, contract validation tests, and mock modules.
> 3. Implement result reporting that clearly:
>
>    * Shows which tests passed/failed.
>    * Shows performance metrics.
>    * Shows coverage results.
>    * Explains exactly *why* a failure occurred.
> 4. Clearly define **pass criteria** and automatically determine if we can move on to the next stage.
>
> ---
>
> **Scope to Implement Now:**
>
> * **Core Files:**
>
>   * `/tests/harness.js`: Minimal async-capable test runner with:
>
>     * Grouping and labeling of tests
>     * Timing per test
>     * Fail-fast option
>   * `/tests/assert.js`: Assertion utilities:
>
>     * `assert.equal(a, b)`
>     * `assert.deepEqual(a, b)`
>     * `assert.bufferEqual(buf1, buf2)` (binary comparison)
>     * `assert.close(a, b, epsilon)` (floats)
>     * Diff output for arrays/objects
>   * `/tests/mocks/`:
>
>     * `mock-engine.js`: Implements `Engine` contract, logs scheduled events with timestamps.
>     * `mock-resolver.js`: Implements `InscriptionResolver`, returns fixture data from memory.
>     * `mock-worker-scheduler.js`: Simulates deterministic clock ticks without real-time waits.
>     * `mock-audio-context.js`: Simulates Web Audio API nodes.
>   * `/package.json`: Scripts:
>
>     * `test` → run all tests
>     * `test:unit`
>     * `test:contract`
>     * `test:int`
>     * `lint`
>     * `build`
>     * `perf`
>     * `golden:update`
>   * `.github/workflows/ci.yml`: GitHub Actions CI pipeline:
>
>     * Node + headless Chrome
>     * Steps: lint → unit → contract → integration → coverage check
>     * Upload performance and coverage artifacts
>   * `/.ci/thresholds.json`: Performance & coverage gates:
>
>     ```json
>     {
>       "coverage": { "min": 60, "ratchet": true },
>       "perf": { "testRunner": 2000, "schedulerTickP95": 3 }
>     }
>     ```
>
> ---
>
> **Testing Requirements for This Phase:**
>
> * Runner must execute a **dummy suite** with:
>
>   * Passing test
>   * Failing test
>   * Async test
>   * Performance measurement
> * CI must fail if:
>
>   * Any test fails
>   * Coverage < 60%
>   * Test runner time > 2s (local)
>   * Scheduler tick p95 > 3ms (simulated in mock-worker-scheduler)
> * All mocks must conform to their **contract interfaces** (`/contracts/*.json`).
>
> ---
>
> **Output & Reporting Requirements:**
>
> * Console output must show:
>
>   * **Green check** for passed tests
>   * **Red X** for failed tests, with stack trace
>   * Per-test timing
>   * Coverage summary
>   * Performance metrics
> * At end of run:
>
>   * Show "**PHASE 0: PASS**" if all gates met.
>   * Show "**PHASE 0: FAIL – \[reason list]**" if not.
>   * List all reasons for failure in plain English.
>
> ---
>
> **Pass Criteria to Advance:**
>
> * ✅ All tests pass
> * ✅ Coverage ≥ 60%
> * ✅ Test runner time < 2s local
> * ✅ Scheduler tick p95 < 3ms (mocked)
> * ✅ All mocks match contracts
>
> ---
>
> **Deliverables for This Prompt:**
>
> 1. All source modules listed above.
> 2. All corresponding test files.
> 3. Fully working CI config.
> 4. Example run output (showing both pass and fail cases).
> 5. Inline comments explaining how to extend the harness for later phases.
>
> The result should be **self-contained**, **runnable immediately**, and **fully verifiable** as the first step in the larger build plan.

---

If you want, I can now adapt this into an **actual runnable starter code** for `/tests/harness.js`, `/tests/assert.js`, and the mocks so that Phase 0 is immediately functional. That would make the next stage plug-and-play.
