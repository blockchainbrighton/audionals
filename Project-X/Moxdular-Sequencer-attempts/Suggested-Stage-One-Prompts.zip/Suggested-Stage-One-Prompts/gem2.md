Of course. Based on the comprehensive "Modular Web3 DAW Build Plan (v2.0)," here is a clear and exhaustive prompt designed to generate the entire first segment: **"Bootstrap, CI Spine, & Test Infrastructure."**

This prompt is structured to ensure the generated output includes all specified modules, tests, mock implementations, and configuration artifacts, precisely defining the success criteria for this initial stage.

---

### **Prompt for Generating Segment 0: Bootstrap & Test Infrastructure**

**You are an expert software engineer specializing in Test-Driven Development (TDD), Continuous Integration (CI), and modern JavaScript infrastructure. Your task is to generate the complete and production-ready codebase for the foundational "Segment 0: Bootstrap, CI Spine, & Test Infrastructure" of the Modular Web3 DAW project.**

Generate all the necessary files as a complete system. Each file must be fully implemented according to the specifications below, including comments explaining key logic. The entire system must be self-contained and immediately usable for the subsequent development phases.

The final output must be a set of clearly labeled code blocks, each containing a single file with its full path.

---

### **Project Structure to Generate:**

```
/
├── .ci/
│   └── thresholds.json
├── .github/
│   └── workflows/
│       └── ci.yml
├── tests/
│   ├── mocks/
│   │   ├── mock-audio-context.js
│   │   ├── mock-engine.js
│   │   ├── mock-resolver.js
│   │   └── mock-worker-scheduler.js
│   ├── assert.js
│   ├── harness.js
│   └── bootstrap.test.js  // A dummy suite to test the harness itself
└── package.json
```

---

### **Detailed File Generation Requirements:**

**1. Test Harness: `/tests/harness.js`**

Generate a minimal, modern, async-aware test runner with no external dependencies.
- **Functionality:**
    - A `test(description, testFn)` function for defining individual test cases. `testFn` can be synchronous or async.
    - A `group(description, groupFn)` function for grouping related tests.
    - It must automatically discover and run test files.
    - Use `console.log` with basic color-coding (e.g., green for pass, red for fail) to report results clearly.
    - It must measure and report the execution time for each test and the total suite duration.
    - It must handle and log errors thrown during test execution without crashing the entire run.
    - The process must exit with a non-zero status code if any test fails, to ensure CI pipelines fail correctly.

**2. Assertion Library: `/tests/assert.js`**

Generate a lightweight assertion library with no external dependencies, tailored for audio and data verification.
- **Exports:**
    - `assert.ok(value, message)`: Checks for truthiness.
    - `assert.equal(actual, expected, message)`: Uses `===` for strict equality.
    - `assert.deepEqual(actual, expected, message)`: Performs a recursive, deep comparison of objects and arrays.
    - `assert.close(actual, expected, epsilon, message)`: Asserts that two floating-point numbers are within a specified `epsilon` of each other. This is critical for audio computations.
    - `assert.throws(fn, message)`: Asserts that the function `fn` throws an error.
    - `assert.bufferEqual(buf1, buf2, message)`: Performs a byte-for-byte comparison of two ArrayBuffer or Buffer objects.
    - Each assertion must throw a descriptive `AssertionError` on failure.

**3. Mock Implementations: `/tests/mocks/*.js`**

Generate all initial mock stubs. Each mock must be a lightweight, in-memory fake that implements the intended contract interface. They should log method calls for inspection during tests.

- **`/tests/mocks/mock-engine.js`**:
    - Implements the `Engine` contract.
    - Must have a `schedule(event, whenSec)` method that pushes the event and timestamp into an internal `log` array.
    - Include methods like `setTempo`, `connectTrack`, and `dispose` that log their invocation.
    - Provide a `clear()` method to reset its internal log for subsequent tests.

- **`/tests/mocks/mock-resolver.js`**:
    - Implements the `InscriptionResolver` contract.
    - Must have a `resolve(inscriptionId)` method.
    - It should be pre-populated with a small in-memory map of fixture data (e.g., `{ "inscription-123": "mock data" }`).
    - It should return fixture data from memory without making any network requests.

- **`/tests/mocks/mock-worker-scheduler.js`**:
    - Simulates the `WorkerScheduler` contract.
    - Must have `start()` and `stop()` methods.
    - It should not use real-time waits. Instead, provide a manual `tick()` method that simulates a clock tick for deterministic testing.

- **`/tests/mocks/mock-audio-context.js`**:
    - Fakes the Web Audio API's `AudioContext`.
    - Provide stubbed methods like `createGain()`, `createOscillator()`, etc., that return objects with a `connect` method to allow for graph testing without a real audio environment.

**4. Core Configuration: `package.json`**

Generate the `package.json` file for the project.
- **`scripts` section must include:**
    - `test`: "node tests/harness.js"
    - `test:unit`: "node tests/harness.js --grep=unit" (or similar filtering logic)
    - `test:contract`: "node tests/harness.js --grep=contract"
    - `test:int`: "node tests/harness.js --grep=integration"
    - `lint`: "echo 'Linting not yet configured'"
    - `build`: "echo 'Build not yet configured'"
    - `perf`: "echo 'Performance tests not yet configured'"
    - `golden:update`: "echo 'Golden update not yet configured'"
- Include standard fields like `name`, `version`, and `type: "module"`.

**5. CI and Performance Thresholds: `/.ci/thresholds.json`**

Generate the JSON file that stores performance and coverage baselines.
- **Content:**
    ```json
    {
      "coverage": {
        "min": 60,
        "ratchet": true
      },
      "perf": {
        "testRunner": 2000,
        "schedulerTickP95": 3
      }
    }
    ```

**6. CI Pipeline: `.github/workflows/ci.yml`**

Generate the GitHub Actions workflow file for the CI pipeline.
- **Workflow:**
    - Trigger on `push` to `main` and on `pull_request`.
    - Use a matrix strategy to test against Node.js versions 18.x and 20.x.
    - The job steps must run in the correct order: `lint`, then `test`.
    - The `test` step must execute the `npm test` script.
    - Include placeholders for future steps like coverage reporting and artifact storage.

**7. Bootstrap Verification Test: `/tests/bootstrap.test.js`**

Generate a dummy test suite that uses the `harness` and `assert` library to verify that the test infrastructure itself is working correctly. This is the **Definition of Done** for this entire segment.
- **Tests:**
    - A simple synchronous test that uses `assert.equal` and passes.
    - A simple asynchronous test (using `async/await`) that passes.
    - A test that uses `assert.deepEqual` on two objects to confirm it works.
    - A test designed to **intentionally fail** (e.g., `assert.equal(true, false)`), which can be commented out but proves that the test runner correctly identifies and reports failures and exits with a non-zero code.
    - A test demonstrating the use of `group()` to structure output.
    - A test that verifies a mock (e.g., `mock-engine`) can be imported and its methods can be called.

---

### **Final Output Instructions:**

Please generate all the files listed above. Each file should be presented in a separate, clearly labeled code block with its full path as a header. For example:

```
--- /package.json ---
{
  // ... content ...
}

--- /tests/harness.js ---
// ... content ...
```