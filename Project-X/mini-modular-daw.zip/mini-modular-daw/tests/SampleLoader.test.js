import { test, equal, ok } from './assert.js';
import SampleLoader from '../src/audio/SampleLoader.js';
import { createToneStub } from './testUtils.js';

test('SampleLoader caches players and loads multisamples', async () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const loader = new SampleLoader();
  const url = 'http://example.com/kick.wav';
  const first = await loader.loadSample(url);
  ok(first instanceof stub.Player, 'first call returns Player');
  const second = await loader.loadSample(url);
  equal(first, second, 'second call returns cached Player');
  // multisample
  const mapping = { C4: 'c4.wav', D4: 'd4.wav' };
  const sampler = await loader.loadMultiSample(mapping);
  ok(sampler instanceof stub.Sampler, 'multisample returns Sampler');
});