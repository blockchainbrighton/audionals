import { test, equal } from './assert.js';
import ArrangementSequencerCore from '../src/sequencing/ArrangementSequencerCore.js';
import { createToneStub } from './testUtils.js';

test('ArrangementSequencerCore schedules events with correct offsets', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const arranger = new ArrangementSequencerCore();
  // Fake channels with trigger methods to satisfy schedule
  const channelA = { trigger: () => {} };
  const channelB = { trigger: () => {} };
  const trackA = arranger.addTrack(channelA);
  const trackB = arranger.addTrack(channelB);
  // Add a clip on track A starting at 0.5s with two events at 0 and 1s
  arranger.addClip(trackA, {
    start: 0.5,
    duration: 2,
    events: [ { time: 0 }, { time: 1 } ],
  });
  // Add a clip on track B starting at 1s with one event carrying a note
  arranger.addClip(trackB, {
    start: 1,
    duration: 2,
    events: [ { time: 0.25, note: 'C4', duration: '8n', velocity: 0.8 } ],
  });
  // Inspect scheduled events in the Tone.Transport stub
  const scheduled = stub._scheduled;
  // We expect three scheduled calls
  equal(scheduled.length, 3, 'three events scheduled');
  // Find first clip events
  const times = scheduled.map((e) => e.time).sort((a, b) => a - b);
  // times should be [0.5, 1.5, 1.25] sorted -> 0.5, 1.25, 1.5
  equal(times[0], 0.5, 'first event at 0.5s');
  equal(times[1], 1.25, 'second event at 1.25s (1 + 0.25)');
  equal(times[2], 1.5, 'third event at 1.5s (0.5 + 1)');
});