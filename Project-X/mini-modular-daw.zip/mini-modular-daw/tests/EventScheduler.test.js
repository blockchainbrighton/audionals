import { test, equal } from './assert.js';
import EventScheduler from '../src/sequencing/EventScheduler.js';

test('EventScheduler triggers events within scheduleAheadTime and lookahead changes do not affect absolute times', () => {
  // We'll override the scheduler's _now method to control time manually
  const scheduler = new EventScheduler();
  let currentTime = 0;
  scheduler._now = () => currentTime;
  scheduler.setScheduleAheadTime(0.05);
  scheduler.setLookahead(5);
  const triggered = [];
  const events = [
    { time: 0.05, callback: (t) => triggered.push(t) },
    { time: 0.1, callback: (t) => triggered.push(t) },
    { time: 0.15, callback: (t) => triggered.push(t) },
  ];
  scheduler.start(events);
  // First tick at t=0 should trigger the first event (0.05 <= 0 + 0.05)
  scheduler._tick();
  equal(triggered.length, 1, 'first event triggered');
  equal(triggered[0], 0.05, 'first event time recorded');
  // Advance time and tick again
  currentTime = 0.05;
  scheduler._tick();
  equal(triggered.length, 2, 'second event triggered');
  equal(triggered[1], 0.1, 'second event time recorded');
  currentTime = 0.1;
  scheduler._tick();
  equal(triggered.length, 3, 'third event triggered');
  equal(triggered[2], 0.15, 'third event time recorded');
  // All events processed, scheduler should stop
  equal(scheduler._events.length, 0, 'events cleared');
  // Restart with different lookahead; times should not change
  triggered.length = 0;
  scheduler.setLookahead(50);
  currentTime = 0;
  scheduler.start(events);
  scheduler._tick();
  equal(triggered[0], 0.05, 'lookahead change does not affect event time');
});