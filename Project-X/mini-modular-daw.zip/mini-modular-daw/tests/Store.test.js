import { test, equal } from './assert.js';
import Store from '../src/state/Store.js';

test('Store dispatches mutate state and notify subscribers', () => {
  const initial = {
    bpm: 120,
    stepPattern: [ Array(4).fill(false), Array(4).fill(false) ],
    clips: [],
  };
  const store = new Store(initial);
  let calls = 0;
  store.subscribe(() => {
    calls++;
  });
  // toggle step
  store.dispatch('toggleStep', { channel: 0, step: 1 });
  equal(store.state.stepPattern[0][1], true, 'step toggled');
  equal(calls, 1, 'subscriber notified');
  // setBpm
  store.dispatch('setBpm', 90);
  equal(store.state.bpm, 90, 'BPM updated');
  // add clip
  store.dispatch('addClip', { clip: { id: 1 } });
  equal(store.state.clips.length, 1, 'clip added');
  // remove clip
  store.dispatch('removeClip', { clipId: 1 });
  equal(store.state.clips.length, 0, 'clip removed');
});