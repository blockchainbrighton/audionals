import { test, equal, ok } from './assert.js';
import SynthFactory from '../src/audio/SynthFactory.js';
import { createToneStub } from './testUtils.js';

test('SynthFactory creates synth types and triggers notes', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const types = ['synth', 'fm', 'am', 'poly'];
  types.forEach((type) => {
    const inst = SynthFactory.createSynth(type);
    ok(inst.synth, `${type} synth created`);
    inst.triggerAttackRelease('C4', '8n', 0, 0.5);
    // All synths should record a trigger call
    if (type === 'poly') {
      ok(inst.synth.triggerCalls.length === 1, `${type} synth recorded trigger`);
    } else {
      ok(inst.synth.triggerCalls.length === 1, `${type} synth recorded trigger`);
    }
  });
});