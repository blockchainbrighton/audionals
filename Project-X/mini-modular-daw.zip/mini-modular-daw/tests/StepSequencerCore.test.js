import { test, equal, ok } from './assert.js';
import StepSequencerCore from '../src/sequencing/StepSequencerCore.js';
import { createToneStub } from './testUtils.js';

test('StepSequencerCore toggles steps and fires callbacks in order', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const seq = new StepSequencerCore(2, 16);
  // Toggle a couple of steps
  seq.toggleStep(0, 0, true);
  seq.toggleStep(1, 1, true);
  equal(seq.grid[0][0], true, 'first cell active');
  equal(seq.grid[1][1], true, 'second row second step active');
  const steps = [];
  seq.onStep((step) => {
    steps.push(step);
  });
  seq.schedule();
  // Simulate 5 ticks of the loop
  for (let i = 0; i < 5; i++) {
    // The loop callback is stored on seq.loop.callback
    seq.loop.callback(i * 0.25);
  }
  // We should have received steps 0..4 in order
  equal(steps.length, 5, 'five steps recorded');
  for (let i = 0; i < 5; i++) {
    equal(steps[i], i, `step ${i} received`);
  }
});