import { test, equal, ok, approx } from './assert.js';
import AudioContextManager from '../src/audio/AudioContextManager.js';
import { createToneStub } from './testUtils.js';

test('AudioContextManager start resolves and updates state', async () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const mgr = new AudioContextManager();
  mgr.init(120);
  equal(stub.Transport.bpm.value, 120, 'initial BPM set');
  await mgr.start();
  ok(createToneStub.startCalled === true, 'Tone.start was called');
  // Advance time in stub and ensure now() reflects it
  stub._setNow(1);
  approx(mgr.now(), 1, 1e-6, 'now reflects stub time');
  mgr.setBpm(140);
  equal(stub.Transport.bpm.value, 140, 'BPM updated on transport');
  mgr.stop();
});