/*
 * Minimal TAP‑like assertion library and test runner.
 *
 * Tests can register with `test(name, fn)` and then call `run()` to
 * execute all registered tests.  Assertion helpers throw on failure.
 */

const tests = [];

export function test(name, fn) {
  tests.push({ name, fn });
}

export function equal(actual, expected, message = '') {
  if (actual !== expected) {
    throw new Error(message || `expected ${actual} to equal ${expected}`);
  }
}

export function ok(value, message = '') {
  if (!value) {
    throw new Error(message || `expected value to be truthy`);
  }
}

export function approx(actual, expected, tolerance = 1e-3, message = '') {
  if (Math.abs(actual - expected) > tolerance) {
    throw new Error(message || `expected ${actual} to be within ${tolerance} of ${expected}`);
  }
}

export async function run() {
  let failures = 0;
  for (const { name, fn } of tests) {
    try {
      await fn();
      console.log(`ok - ${name}`);
    } catch (err) {
      failures++;
      console.log(`not ok - ${name}`);
      console.error(err.message || err);
    }
  }
  console.log(`1..${tests.length}`);
  if (failures > 0) {
    // non‑zero exit code on failure
    process.exitCode = failures;
  }
}