import { test, equal, ok } from './assert.js';
import SamplerChannel from '../src/channels/SamplerChannel.js';
import { createToneStub } from './testUtils.js';

test('SamplerChannel triggers sample and respects gain/pan and mute', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const channel = new SamplerChannel();
  // Create a fake player with a start() spy
  const fakePlayer = {
    startCalls: [],
    start: function(time) { this.startCalls.push(time); },
    connect: function(node) { this.connected = node; },
    disconnect: function() {},
  };
  channel.setPlayer(fakePlayer);
  channel.setGain(0.5);
  equal(channel.gainNode.gain.value, 0.5, 'gain set');
  channel.setPan(-0.2);
  equal(channel.panNode.pan.value, -0.2, 'pan set');
  // Trigger at time 0
  channel.trigger(0);
  equal(fakePlayer.startCalls.length, 1, 'player start called');
  equal(fakePlayer.startCalls[0], 0, 'start called at correct time');
  // Muting prevents triggering
  channel.muted = true;
  channel.trigger(1);
  equal(fakePlayer.startCalls.length, 1, 'muted channel does not trigger');
});