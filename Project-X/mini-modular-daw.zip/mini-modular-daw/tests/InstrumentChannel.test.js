import { test, equal, ok } from './assert.js';
import InstrumentChannel from '../src/channels/InstrumentChannel.js';
import { createToneStub } from './testUtils.js';

test('InstrumentChannel add/remove notes and trigger behaviour', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  const channel = new InstrumentChannel('synth');
  // Underlying synth
  const synth = channel.synth;
  // Add a note
  const id = channel.addNote('C4', 0, '8n', 0.8);
  equal(channel.notes.length, 1, 'note added');
  // Trigger without specifying note should schedule stored notes
  channel.trigger(0);
  equal(synth.triggerCalls.length, 1, 'stored note triggered');
  const call = synth.triggerCalls[0];
  equal(call.note, 'C4', 'correct note triggered');
  // Remove the note
  channel.removeNote(id);
  equal(channel.notes.length, 0, 'note removed');
  // Trigger again should not produce additional calls
  channel.trigger(1);
  equal(synth.triggerCalls.length, 1, 'no new trigger after removal');
  // Trigger a single note explicitly
  channel.trigger(2, 'D4', '4n', 0.5);
  equal(synth.triggerCalls.length, 2, 'explicit note triggered');
  const call2 = synth.triggerCalls[1];
  equal(call2.note, 'D4', 'explicit note correct');
  equal(call2.duration, '4n', 'duration passed through');
});