import { run } from './assert.js';

// Dynamically import each test module.  Tests register themselves with
// the assertion library and will be executed when run() is called.
const testFiles = [
  './AudioContextManager.test.js',
  './SampleLoader.test.js',
  './SynthFactory.test.js',
  './StepSequencerCore.test.js',
  './ArrangementSequencerCore.test.js',
  './EventScheduler.test.js',
  './SamplerChannel.test.js',
  './InstrumentChannel.test.js',
  './Store.test.js',
  './sequencer.integration.test.js',
];

for (const file of testFiles) {
  await import(file);
}
// Run all registered tests
await run();