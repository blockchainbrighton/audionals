import { test, equal, ok } from './assert.js';
import AudioContextManager from '../src/audio/AudioContextManager.js';
import StepSequencerCore from '../src/sequencing/StepSequencerCore.js';
import ArrangementSequencerCore from '../src/sequencing/ArrangementSequencerCore.js';
import SamplerChannel from '../src/channels/SamplerChannel.js';
import InstrumentChannel from '../src/channels/InstrumentChannel.js';
import Store from '../src/state/Store.js';
import { createToneStub } from './testUtils.js';

test('Integration: step sequencer and arrangement trigger channels correctly', () => {
  const stub = createToneStub();
  globalThis.Tone = stub;
  // Setup audio manager and sequencers
  const audioMgr = new AudioContextManager();
  audioMgr.init(120);
  const sampleChannel = new SamplerChannel();
  const instrumentChannel = new InstrumentChannel('synth');
  const stepSeq = new StepSequencerCore(2, 16);
  const arranger = new ArrangementSequencerCore();
  const samplerTrack = arranger.addTrack(sampleChannel);
  const synthTrack = arranger.addTrack(instrumentChannel);
  const store = new Store({ bpm: 120, stepPattern: [ Array(4).fill(false), Array(4).fill(false) ], clips: [] });
  // Attach step callback to trigger channels based on store state
  stepSeq.onStep((step, time) => {
    const pattern = store.getState().stepPattern;
    if (pattern[0][step]) sampleChannel.trigger(time);
    if (pattern[1][step]) instrumentChannel.trigger(time, 'C4', '8n', 0.8);
  });
  // Assign fake player to sampler channel
  const fakePlayer = {
    startCalls: [],
    start: function(t) { this.startCalls.push(t); },
    connect: function(node) {},
    disconnect: function() {},
  };
  sampleChannel.setPlayer(fakePlayer);
  // Set pattern: first channel triggers on step 0, second channel on step 1
  stepSeq.toggleStep(0, 0, true);
  store.dispatch('toggleStep', { channel: 0, step: 0 });
  stepSeq.toggleStep(1, 1, true);
  store.dispatch('toggleStep', { channel: 1, step: 1 });
  stepSeq.schedule();
  // Simulate two step callbacks
  stepSeq.loop.callback(0);
  stepSeq.loop.callback(0.25);
  // The sampler should have triggered at first callback only
  equal(fakePlayer.startCalls.length, 1, 'sampler triggered once');
  equal(fakePlayer.startCalls[0], 0, 'sampler time correct');
  // The synth should have one call in its triggerCalls after second callback
  equal(instrumentChannel.synth.triggerCalls.length, 1, 'synth triggered once');
  equal(instrumentChannel.synth.triggerCalls[0].note, 'C4', 'synth triggered correct note');
  // Arrange a clip on synth track at time 1 with an event at 0.5
  arranger.addClip(synthTrack, {
    start: 1,
    duration: 2,
    events: [ { time: 0.5, note: 'D4', duration: '8n', velocity: 0.7 } ],
  });
  // Should schedule one event at absolute time 1.5
  const scheduled = stub._scheduled;
  const ev = scheduled.find((e) => Math.abs(e.time - 1.5) < 1e-6);
  ok(ev !== undefined, 'arrangement scheduled event at correct absolute time');
  // Changing BPM updates transport BPM
  audioMgr.setBpm(150);
  equal(stub.Transport.bpm.value, 150, 'transport BPM updated via manager');
});