/*
 * Utilities for tests: createToneStub returns a minimal stub of the
 * Tone.js API used by the application.  Each stub contains only the
 * methods and properties referenced in the source code.  Scheduled
 * events are recorded for inspection in tests.
 */

export function createToneStub() {
  // internal current time value for Tone.now()
  let currentTime = 0;
  // store scheduled events
  const scheduled = [];

  function parseTime(val) {
    if (typeof val === 'number') return val;
    if (!val) return 0;
    // Handle notation like '0:1', '0:2', etc.  Convert beats to seconds
    if (typeof val === 'string' && val.includes(':')) {
      const parts = val.split(':').map((p) => parseInt(p, 10));
      // bars:beats:sixteenths -> assume 4 beats per bar, 1 second per beat
      let seconds = 0;
      if (parts.length === 2) {
        const [bars, beats] = parts;
        seconds = bars * 4 + beats;
      } else if (parts.length === 3) {
        const [bars, beats, sixteenths] = parts;
        seconds = bars * 4 + beats + sixteenths / 4;
      }
      return seconds;
    }
    // Note values like '8n', '16n', '4n', '2n', '1m'
    if (typeof val === 'string' && val.endsWith('n')) {
      const num = parseInt(val);
      // 4n = 1, 8n = 0.5, 16n = 0.25, 2n = 2
      return 4 / num;
    }
    if (val === '1m') return 4;
    return 0;
  }

  class Player {
    constructor(url, onload) {
      this.url = url;
      this.startCalls = [];
      if (typeof onload === 'function') {
        // asynchronously invoke the onload callback to simulate loading
        setTimeout(() => onload(), 0);
      }
    }
    start(time) {
      this.startCalls.push(time);
    }
    connect(node) {
      this.connected = node;
    }
    disconnect() {}
  }
  class Sampler {
    constructor(mapping, onload) {
      this.mapping = mapping;
      this.triggerCalls = [];
      if (typeof onload === 'function') {
        setTimeout(() => onload(), 0);
      }
    }
    triggerAttackRelease(notes, duration, time, velocity) {
      this.triggerCalls.push({ notes, duration, time, velocity });
    }
    connect(node) {
      this.connected = node;
    }
    disconnect() {}
  }
  class Synth {
    constructor() {
      this.triggerCalls = [];
      this.params = {};
    }
    triggerAttack(note, time, velocity) {
      this.triggerCalls.push({ type: 'attack', note, time, velocity });
    }
    triggerRelease(note, time) {
      this.triggerCalls.push({ type: 'release', note, time });
    }
    triggerAttackRelease(note, duration, time, velocity) {
      this.triggerCalls.push({ type: 'attackRelease', note, duration, time, velocity });
    }
    set(params) {
      Object.assign(this.params, params);
    }
    toDestination() {}
    connect(node) {}
    disconnect() {}
  }
  class PolySynth {
    constructor(baseClass) {
      this.baseClass = baseClass;
      this.triggerCalls = [];
    }
    triggerAttack(note, time, velocity) {
      this.triggerCalls.push({ type: 'attack', note, time, velocity });
    }
    triggerRelease(note, time) {
      this.triggerCalls.push({ type: 'release', note, time });
    }
    triggerAttackRelease(note, duration, time, velocity) {
      this.triggerCalls.push({ type: 'attackRelease', note, duration, time, velocity });
    }
    set(params) {}
    toDestination() {}
    connect(node) {}
    disconnect() {}
  }
  class Gain {
    constructor(val = 1) {
      this.gain = { value: val };
    }
    connect(node) { this.connected = node; }
    disconnect() {}
  }
  class Panner {
    constructor(val = 0) {
      this.pan = { value: val };
    }
    connect(node) { this.connected = node; }
    disconnect() {}
    toDestination() {}
  }
  class Loop {
    constructor(callback, interval) {
      this.callback = callback;
      this.interval = interval;
      this.started = false;
    }
    start(startTime) {
      this.started = true;
    }
    stop() {
      this.started = false;
    }
    dispose() {
      this.started = false;
    }
  }
  const Transport = {
    bpm: { value: 120 },
    _scheduled: scheduled,
    start: () => { Transport.running = true; },
    stop: () => { Transport.running = false; },
    schedule: (cb, time) => {
      const id = scheduled.length;
      scheduled.push({ cb, time });
      return id;
    },
    clear: (id) => {
      if (scheduled[id]) scheduled[id].cleared = true;
    },
    now: () => currentTime,
    get seconds() {
      return currentTime;
    },
  };
  return {
    Transport,
    start: () => {
      createToneStub.startCalled = true;
      return Promise.resolve();
    },
    now: () => currentTime,
    Player,
    Sampler,
    Synth,
    FMSynth: Synth,
    AMSynth: Synth,
    PolySynth,
    Gain,
    Panner,
    Loop,
    Time: (val) => ({ toSeconds: () => parseTime(val) }),
    // Destination placeholder
    Destination: {},
    // Utilities to control stub time and inspect scheduled events
    _setNow: (t) => { currentTime = t; },
    _scheduled: scheduled,
  };
}