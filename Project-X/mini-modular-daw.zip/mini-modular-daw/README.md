# Mini Modular DAW

This repository contains a self‑contained, browser‑based mini Digital Audio Workstation (DAW) implemented using vanilla JavaScript and [Tone.js](https://tonejs.github.io/).  The goal of the project is to demonstrate sequencing, arrangement and basic audio processing concepts without relying on any build tools or heavy frameworks.

## Features

- **Step Sequencer:** A 2‑row × 16‑step grid lets you toggle individual steps for a sampler (kick drum) and a monosynth.  The sequencer runs at a sixteenth‑note resolution and will immediately reflect changes in the UI and audio output.
- **Arrangement Sequencer:** Create multiple tracks, add or move clips, and schedule events on the global transport.  The built‑in “Add Demo Clip” button inserts a short ascending melody on the instrument track and schedules it automatically.
- **Audio Engine:** The application wraps the Tone.js `Transport` in an `AudioContextManager` which defers starting until the user clicks **Play**, exposes tempo control, and broadcasts run state changes to subscribers.
- **Channel Abstractions:** A `SamplerChannel` loads and plays back external audio files, while an `InstrumentChannel` manages a synth created via the `SynthFactory`.  Both expose simple APIs for triggering notes, setting gain/pan and serialising state.
- **State Management:** A minimal event‑driven store holds the step patterns, BPM and clip list.  UI components dispatch actions and subscribe to store updates rather than mutating audio objects directly.
- **Vanilla UI:** The interface uses plain HTML, CSS and JavaScript.  It provides transport controls, a BPM slider, a step grid with labelled rows, and an arranger panel for clips.  The dark theme and subtle hover states keep the layout clean and unobtrusive.
- **No Web3:** There are no references to Web3, wallets, lightning or blockchain technologies anywhere in the codebase.

## Running the App

No build step is required.  Simply open the `index.html` file in a modern browser.  Because browsers require a user gesture to start audio, click **Play** to unlock the audio context and begin playback.

1. Clone or download this repository.
2. Open `index.html` in a modern browser (Chrome, Firefox, Edge or Safari).
3. Click **Play**.  Toggle steps in the grid and add/remove clips from the arrangement panel.

## Running Tests

The project includes a tiny test harness in the `tests` folder.  You can run all tests with Node:

```sh
node tests/run-all.js
```

Each individual test can also be executed directly, for example:

```sh
node tests/AudioContextManager.test.js
```

The tests stub out Tone.js classes so no real audio is produced.  They verify scheduling logic, sequencing order, channel triggering and state management.

## Audio Unlock

Modern browsers require a user gesture (such as a click) to start the audio context.  The DAW defers starting `Tone.start()` until the **Play** button is pressed.  Until then, no sound will be produced.  After the first click, the transport will run and audio will be scheduled normally.

## Sample Source

The kick drum sample used by default comes from the open CR‑78 drum machine sample pack hosted by the Oramics “sampled” project and is public domain.  The list of available sample files includes `kick.wav`, which is loaded by default.  The file is safe to hotlink from the application.

Enjoy experimenting!