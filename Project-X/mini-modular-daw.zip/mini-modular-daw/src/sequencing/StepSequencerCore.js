/*
 * StepSequencerCore
 *
 * Maintains a grid of booleans representing active steps across multiple
 * channels, and schedules callbacks on each sixteenth‑note interval.  The
 * callback(s) registered via `onStep` receive the step index and Tone.js
 * time whenever a step occurs.  Consumers can query the current grid to
 * determine which channels are active for that step.
 */

export default class StepSequencerCore {
  /**
   * Create a step sequencer with the given number of channels and steps.
   *
   * @param {number} numChannels
   * @param {number} stepsPerBar
   */
  constructor(numChannels = 2, stepsPerBar = 16) {
    this.loop = null;
    this.stepCallbacks = [];
    this.create(numChannels, stepsPerBar);
  }

  /**
   * Initialize or resize the grid.
   */
  create(numChannels, stepsPerBar) {
    this.numChannels = numChannels;
    this.stepsPerBar = stepsPerBar;
    this.grid = Array.from({ length: numChannels }, () => Array(stepsPerBar).fill(false));
  }

  /**
   * Toggle a single step.  If `value` is provided the step is set
   * explicitly; otherwise it flips the current state.
   */
  toggleStep(channel, step, value) {
    if (channel < 0 || channel >= this.numChannels) return;
    if (step < 0 || step >= this.stepsPerBar) return;
    if (typeof value === 'undefined') {
      this.grid[channel][step] = !this.grid[channel][step];
    } else {
      this.grid[channel][step] = !!value;
    }
  }

  /**
   * Replace the entire pattern of a channel.  Expects an array of booleans
   * equal in length to stepsPerBar.
   */
  setPattern(channel, pattern) {
    if (channel < 0 || channel >= this.numChannels) return;
    this.grid[channel] = pattern.slice(0, this.stepsPerBar);
    // pad if shorter
    while (this.grid[channel].length < this.stepsPerBar) {
      this.grid[channel].push(false);
    }
  }

  /**
   * Register a callback fired on every step.  The callback receives the
   * current step index and the Tone.js time value.
   */
  onStep(cb) {
    this.stepCallbacks.push(cb);
  }

  /**
   * Start scheduling the sequencer using Tone.Loop.  Existing loops are
   * disposed of before a new one is created.
   */
  schedule() {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    // Dispose any previous loop
    if (this.loop) {
      this.loop.dispose();
    }
    let stepIndex = 0;
    this.loop = new Tone.Loop((time) => {
      const current = stepIndex;
      // Invoke callbacks
      for (const cb of this.stepCallbacks) {
        try {
          cb(current, time);
        } catch (e) {
          console.error(e);
        }
      }
      stepIndex = (stepIndex + 1) % this.stepsPerBar;
    }, '16n');
    this.loop.start(0);
  }

  /**
   * Clear the grid and stop scheduling.  Does not remove listeners.
   */
  clear() {
    for (const row of this.grid) {
      row.fill(false);
    }
    if (this.loop) {
      this.loop.stop();
    }
  }

  /**
   * Serialize the current state into a plain object.
   */
  serialize() {
    return {
      numChannels: this.numChannels,
      stepsPerBar: this.stepsPerBar,
      grid: this.grid.map((row) => row.slice()),
    };
  }

  /**
   * Restore the state from a serialized object.
   */
  deserialize(data) {
    this.numChannels = data.numChannels;
    this.stepsPerBar = data.stepsPerBar;
    this.grid = data.grid.map((row) => row.slice());
  }
}