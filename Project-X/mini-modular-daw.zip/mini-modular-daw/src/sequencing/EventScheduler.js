/*
 * EventScheduler
 *
 * Implements a simple look‑ahead scheduler suitable for scheduling events
 * outside of Tone.js.  The design follows the pattern described in the
 * MDN Web Audio scheduling article: a timer fires at regular intervals
 * (lookahead) and walks a list of events, invoking callbacks for those
 * occurring within the scheduleAheadTime window.  Changing the lookahead
 * interval does not affect the absolute timing of events; it merely
 * influences how frequently the scheduler checks for events to trigger.
 */

export default class EventScheduler {
  constructor() {
    // Timer resolution (in milliseconds) used for polling events
    this._lookahead = 25;
    // How far ahead to schedule events (in seconds)
    this._scheduleAheadTime = 0.1;
    this._events = [];
    this._index = 0;
    this._timerId = null;
    // Use Tone.now() when available; fall back to performance.now()/1000
    this._now = () => {
      const Tone = globalThis.Tone;
      if (Tone && typeof Tone.now === 'function') return Tone.now();
      return (typeof performance !== 'undefined' ? performance.now() : Date.now()) / 1000;
    };
  }

  /**
   * Start the scheduler with a sorted list of events.  Each event must
   * contain a `time` (in seconds) and a `callback` function.  Events can
   * optionally include other properties but they will be ignored by the
   * scheduler.
   *
   * @param {Array<{time: number, callback: Function}>} events
   */
  start(events) {
    this.stop();
    this._events = events.slice().sort((a, b) => a.time - b.time);
    this._index = 0;
    this._timerId = setInterval(() => this._tick(), this._lookahead);
  }

  /**
   * Stop the scheduler and clear any pending events.
   */
  stop() {
    if (this._timerId !== null) {
      clearInterval(this._timerId);
      this._timerId = null;
    }
    this._events = [];
    this._index = 0;
  }

  /**
   * Set the polling interval in milliseconds.  Updating the lookahead
   * restarts the internal timer using the new period but does not alter
   * the scheduled event times.
   */
  setLookahead(ms) {
    this._lookahead = ms;
    if (this._timerId !== null) {
      clearInterval(this._timerId);
      this._timerId = setInterval(() => this._tick(), this._lookahead);
    }
  }

  /**
   * Set how far ahead, in seconds, events should be scheduled.  A larger
   * window trades latency for potentially more scheduling overhead.
   */
  setScheduleAheadTime(sec) {
    this._scheduleAheadTime = sec;
  }

  /**
   * Internal tick function invoked by setInterval.  Iterates over events
   * that fall within the lookahead window and invokes their callbacks.
   */
  _tick() {
    const currentTime = this._now();
    while (this._index < this._events.length) {
      const event = this._events[this._index];
      if (event.time <= currentTime + this._scheduleAheadTime) {
        try {
          event.callback(event.time);
        } catch (e) {
          console.error(e);
        }
        this._index++;
      } else {
        break;
      }
    }
    // Stop when all events have been processed
    if (this._index >= this._events.length) {
      this.stop();
    }
  }
}