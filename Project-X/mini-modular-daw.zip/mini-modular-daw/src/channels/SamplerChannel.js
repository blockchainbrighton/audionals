/*
 * SamplerChannel
 *
 * Wraps a Tone.Player or Tone.Sampler and provides simple level and pan
 * control.  The channel can be muted or soloed.  Effects can be connected
 * via `connectEffects`, though the default implementation simply wires the
 * player into a gain node, panner and then the destination.
 */

export default class SamplerChannel {
  constructor() {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    this.player = null;
    this.gainNode = new Tone.Gain(1);
    this.panNode = new Tone.Panner(0);
    // Chain gain → pan → destination
    this.gainNode.connect(this.panNode);
    this.panNode.toDestination();
    this.muted = false;
    this.solo = false;
    this.effects = [];
  }

  /**
   * Trigger playback at the given time.  If muted or no player is loaded
   * nothing is triggered.
   *
   * @param {number} time Tone.js time in seconds.
   */
  trigger(time) {
    if (this.muted) return;
    if (!this.player) return;
    if (typeof this.player.start === 'function') {
      this.player.start(time);
    }
  }

  /**
   * Set the channel gain (0–1).  This updates the underlying Tone.Gain.
   */
  setGain(value) {
    this.gainNode.gain.value = value;
  }

  /**
   * Set the stereo pan position (–1 left to 1 right).
   */
  setPan(value) {
    this.panNode.pan.value = value;
  }

  /**
   * Connect a set of effects in series between the player and the gain
   * node.  Previous effects are disconnected.  Effects are assumed to
   * expose a `connect` method and will be connected in the order
   * provided.  If no effects are passed the player is connected directly
   * to the gain node.
   */
  connectEffects(effectsArray) {
    this.disconnectEffects();
    this.effects = effectsArray || [];
    if (!this.player) return;
    if (this.effects.length === 0) {
      this.player.connect(this.gainNode);
      return;
    }
    let prev = this.player;
    for (const effect of this.effects) {
      if (prev && typeof prev.connect === 'function') {
        prev.connect(effect);
      }
      prev = effect;
    }
    if (prev && typeof prev.connect === 'function') {
      prev.connect(this.gainNode);
    }
  }

  /**
   * Disconnect all effects and reconnect the player directly to the gain
   * node.
   */
  disconnectEffects() {
    if (this.player && typeof this.player.disconnect === 'function') {
      try {
        this.player.disconnect();
      } catch (e) {}
    }
    for (const eff of this.effects) {
      if (typeof eff.disconnect === 'function') {
        try {
          eff.disconnect();
        } catch (e) {}
      }
    }
    this.effects = [];
    if (this.player) {
      this.player.connect(this.gainNode);
    }
  }

  /**
   * Load a new sample or sampler into this channel.  Accepts either a
   * Tone.Player or a Tone.Sampler.  The loader (e.g. SampleLoader) should
   * instantiate and load the underlying player/sampler before passing it
   * here.  The player will be wired into the current effect chain and
   * output.
   */
  setPlayer(player) {
    this.player = player;
    // Reconnect through effects chain or directly to gain
    if (this.effects.length > 0) {
      this.connectEffects(this.effects);
    } else if (this.player) {
      this.player.connect(this.gainNode);
    }
  }

  /**
   * Serialize the channel state.
   */
  serialize() {
    return {
      gain: this.gainNode.gain.value,
      pan: this.panNode.pan.value,
      muted: this.muted,
    };
  }

  /**
   * Restore the channel state from serialized data.  Does not restore the
   * player or effects.
   */
  deserialize(data) {
    if (!data) return;
    if (typeof data.gain === 'number') this.setGain(data.gain);
    if (typeof data.pan === 'number') this.setPan(data.pan);
    this.muted = !!data.muted;
  }
}