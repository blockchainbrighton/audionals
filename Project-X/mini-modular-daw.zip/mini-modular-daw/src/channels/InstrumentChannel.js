/*
 * InstrumentChannel
 *
 * Holds a synthesiser created via SynthFactory and a list of notes.  Notes
 * are objects containing a pitch, offset, duration and velocity.  When
 * triggered without arguments the channel will schedule all stored notes
 * relative to the trigger time.  Alternatively, passing a specific note
 * and duration will trigger that note immediately, which is useful for
 * step sequencers.
 */

import SynthFactory from '../audio/SynthFactory.js';

export default class InstrumentChannel {
  constructor(type = 'synth') {
    const { synth, triggerAttack, triggerRelease, triggerAttackRelease } = SynthFactory.createSynth(type);
    this.synth = synth;
    this._triggerAttack = triggerAttack;
    this._triggerRelease = triggerRelease;
    this._triggerAttackRelease = triggerAttackRelease;
    this.notes = [];
    this._noteIdCounter = 0;
  }

  /**
   * Add a note to be played when the channel is triggered.  Returns an
   * identifier which can be used to remove the note later.
   *
   * @param {string} note The pitch (e.g. 'C4').
   * @param {string|number} startTime When the note starts relative to the trigger time.
   * @param {string|number} duration Duration of the note (e.g. '8n').
   * @param {number} velocity Note velocity (0–1).
   */
  addNote(note, startTime, duration, velocity = 1) {
    const id = this._noteIdCounter++;
    this.notes.push({ id, note, startTime, duration, velocity });
    return id;
  }

  /**
   * Remove a previously added note by ID.
   */
  removeNote(id) {
    const idx = this.notes.findIndex((n) => n.id === id);
    if (idx !== -1) {
      this.notes.splice(idx, 1);
    }
  }

  /**
   * Update synth parameters.  Delegates to Tone.js' set() method when
   * available.
   */
  setSynthParams(params) {
    if (this.synth && typeof this.synth.set === 'function') {
      this.synth.set(params);
    }
  }

  /**
   * Trigger the channel.  If a note is provided only that note will be
   * triggered.  Otherwise all stored notes will be scheduled relative to
   * the given time.  Passing duration and velocity only makes sense when
   * triggering a single note.
   */
  trigger(time, note, duration, velocity) {
    const Tone = globalThis.Tone;
    if (note) {
      // Single note trigger
      const dur = duration || '8n';
      const vel = typeof velocity === 'number' ? velocity : 1;
      this._triggerAttackRelease(note, dur, time, vel);
    } else {
      // Schedule all stored notes
      for (const n of this.notes) {
        const offset = n.startTime || 0;
        const absoluteTime = Tone ? Tone.Time(time).toSeconds() + Tone.Time(offset).toSeconds() : time + offset;
        this._triggerAttackRelease(n.note, n.duration, absoluteTime, n.velocity);
      }
    }
  }

  /**
   * Serialize the note list.
   */
  serialize() {
    return {
      notes: this.notes.map((n) => ({ ...n })),
    };
  }

  /**
   * Restore the note list from serialized data.
   */
  deserialize(data) {
    this.notes = (data.notes || []).map((n) => ({ ...n }));
  }
}