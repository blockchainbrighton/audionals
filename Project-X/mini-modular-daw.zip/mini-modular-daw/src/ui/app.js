import AudioContextManager from '../audio/AudioContextManager.js';
import SampleLoader from '../audio/SampleLoader.js';
import StepSequencerCore from '../sequencing/StepSequencerCore.js';
import ArrangementSequencerCore from '../sequencing/ArrangementSequencerCore.js';
import SamplerChannel from '../channels/SamplerChannel.js';
import InstrumentChannel from '../channels/InstrumentChannel.js';
import Store from '../state/Store.js';

// URL of a small public domain kick drum sample from the CR‑78 drum machine
const SAMPLE_URL = 'https://oramics.github.io/sampled/DM/CR-78/samples/kick.wav';

// Instantiate core components
const audioManager = new AudioContextManager();
// Set initial BPM
audioManager.init(120);

const sampleLoader = new SampleLoader();
const sampleChannel = new SamplerChannel();
const instrumentChannel = new InstrumentChannel('synth');
const stepSequencer = new StepSequencerCore(2, 16);
const arrangementSequencer = new ArrangementSequencerCore();

// Add tracks to the arranger.  Order matters: the first track corresponds
// to the sampler and the second to the instrument.
const samplerTrackId = arrangementSequencer.addTrack(sampleChannel);
const instrumentTrackId = arrangementSequencer.addTrack(instrumentChannel);

// Application state.  Holds BPM, step patterns (2×16) and a list of clips.
const initialState = {
  bpm: 120,
  stepPattern: [
    Array(16).fill(false),
    Array(16).fill(false),
  ],
  clips: [],
};
const store = new Store(initialState);

// Load the kick sample and assign it to the sampler channel
sampleLoader.loadSample(SAMPLE_URL).then((player) => {
  sampleChannel.setPlayer(player);
}).catch((err) => console.error(err));

// Configure the step sequencer callback.  For each step we query the store
// state to see which channels are active and trigger the appropriate
// channels.  The second channel triggers a short C4 note on the synth.
stepSequencer.onStep((step, time) => {
  const state = store.getState();
  const pattern = state.stepPattern;
  if (pattern[0][step]) {
    sampleChannel.trigger(time);
  }
  if (pattern[1][step]) {
    instrumentChannel.trigger(time, 'C4', '8n', 0.8);
  }
});

/**
 * Build the user interface.  Creates DOM elements for transport controls,
 * step grid and arranger panel and binds event handlers to dispatch
 * actions and schedule audio.
 */
function buildUI() {
  const appEl = document.getElementById('app');
  // Clear any existing content
  appEl.innerHTML = '';

  // Transport controls
  const transportDiv = document.createElement('div');
  transportDiv.className = 'transport';
  const playBtn = document.createElement('button');
  playBtn.textContent = 'Play';
  const stopBtn = document.createElement('button');
  stopBtn.textContent = 'Stop';
  const bpmLabel = document.createElement('span');
  bpmLabel.textContent = `BPM: ${store.getState().bpm}`;
  const bpmSlider = document.createElement('input');
  bpmSlider.type = 'range';
  bpmSlider.min = '60';
  bpmSlider.max = '180';
  bpmSlider.value = store.getState().bpm;
  bpmSlider.id = 'bpm-slider';
  transportDiv.appendChild(playBtn);
  transportDiv.appendChild(stopBtn);
  transportDiv.appendChild(bpmLabel);
  transportDiv.appendChild(bpmSlider);
  appEl.appendChild(transportDiv);

  // Step sequencer grid
  const gridDiv = document.createElement('div');
  gridDiv.className = 'step-grid';
  const rowNames = ['Sampler (Kick)', 'Instrument (Synth)'];
  for (let ch = 0; ch < 2; ch++) {
    const rowDiv = document.createElement('div');
    rowDiv.className = 'step-row';
    const label = document.createElement('span');
    label.className = 'step-row-label';
    label.textContent = rowNames[ch];
    rowDiv.appendChild(label);
    for (let s = 0; s < 16; s++) {
      const cell = document.createElement('div');
      cell.className = 'step-cell';
      cell.dataset.ch = ch.toString();
      cell.dataset.step = s.toString();
      cell.addEventListener('click', () => {
        // Toggle cell state in both the sequencer and the store
        stepSequencer.toggleStep(ch, s);
        store.dispatch('toggleStep', { channel: ch, step: s });
      });
      rowDiv.appendChild(cell);
    }
    gridDiv.appendChild(rowDiv);
  }
  appEl.appendChild(gridDiv);

  // Arranger panel
  const arrangerDiv = document.createElement('div');
  arrangerDiv.className = 'arranger';
  const addClipBtn = document.createElement('button');
  addClipBtn.textContent = 'Add Demo Clip (Synth)';
  arrangerDiv.appendChild(addClipBtn);
  const clipList = document.createElement('ul');
  clipList.className = 'arranger-list';
  arrangerDiv.appendChild(clipList);
  appEl.appendChild(arrangerDiv);

  // Event bindings
  playBtn.addEventListener('click', async () => {
    await audioManager.start();
    stepSequencer.schedule();
    arrangementSequencer.scheduleClips();
  });
  stopBtn.addEventListener('click', () => {
    audioManager.stop();
  });
  bpmSlider.addEventListener('input', () => {
    const bpm = parseInt(bpmSlider.value, 10);
    bpmLabel.textContent = `BPM: ${bpm}`;
    audioManager.setBpm(bpm);
    store.dispatch('setBpm', bpm);
  });
  addClipBtn.addEventListener('click', () => {
    // Create a simple ascending melody clip
    const events = [
      { time: 0, note: 'C4', duration: '8n', velocity: 0.8 },
      { time: '0:1', note: 'D4', duration: '8n', velocity: 0.8 },
      { time: '0:2', note: 'E4', duration: '8n', velocity: 0.8 },
      { time: '0:3', note: 'G4', duration: '8n', velocity: 0.8 },
    ];
    const clipId = arrangementSequencer.addClip(instrumentTrackId, {
      start: 0,
      duration: '1m',
      events,
    });
    store.dispatch('addClip', { clip: { id: clipId, name: 'Demo Clip' } });
    updateClipList();
  });

  // UI update helpers
  function updateGrid() {
    const state = store.getState();
    const pattern = state.stepPattern;
    const cells = gridDiv.querySelectorAll('.step-cell');
    cells.forEach((cell) => {
      const ch = parseInt(cell.dataset.ch, 10);
      const st = parseInt(cell.dataset.step, 10);
      if (pattern[ch][st]) {
        cell.classList.add('active');
      } else {
        cell.classList.remove('active');
      }
    });
  }
  function updateClipList() {
    clipList.innerHTML = '';
    const clips = store.getState().clips;
    clips.forEach((clip) => {
      const li = document.createElement('li');
      const nameSpan = document.createElement('span');
      nameSpan.textContent = clip.name || `Clip ${clip.id}`;
      const removeBtn = document.createElement('button');
      removeBtn.textContent = 'Remove';
      removeBtn.addEventListener('click', () => {
        arrangementSequencer.removeClip(clip.id);
        store.dispatch('removeClip', { clipId: clip.id });
        updateClipList();
      });
      li.appendChild(nameSpan);
      li.appendChild(removeBtn);
      clipList.appendChild(li);
    });
  }
  // Subscribe to store updates to refresh the grid and BPM label
  store.subscribe(() => {
    updateGrid();
    bpmLabel.textContent = `BPM: ${store.getState().bpm}`;
  });
  // Initial render
  updateGrid();
  updateClipList();
}

// Build the interface once the DOM is ready
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', buildUI);
} else {
  buildUI();
}