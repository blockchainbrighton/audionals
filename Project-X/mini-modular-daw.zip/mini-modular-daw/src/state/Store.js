/*
 * Store
 *
 * A simple observable store to hold application state.  State changes
 * propagate via subscribed listeners.  Actions mutate the state in place
 * following a simple reducer pattern.  Only minimal actions needed for
 * this project are implemented.
 */

export default class Store {
  constructor(initialState = {}) {
    // Deep clone the initial state to avoid accidental external mutation
    this.state = JSON.parse(JSON.stringify(initialState));
    this.listeners = [];
  }

  /**
   * Retrieve a snapshot of the current state.  Consumers should not
   * mutate the returned object directly.
   */
  getState() {
    return this.state;
  }

  /**
   * Dispatch an action.  Supported actions are:
   *   - setBpm: payload is the new BPM
   *   - toggleStep: payload { channel, step, value? }
   *   - setPattern: payload { channel, pattern }
   *   - addClip: payload { clip }
   *   - removeClip: payload { clipId }
   */
  dispatch(type, payload) {
    switch (type) {
      case 'setBpm':
        this.state.bpm = payload;
        break;
      case 'toggleStep': {
        const { channel, step, value } = payload;
        if (this.state.stepPattern && this.state.stepPattern[channel]) {
          if (typeof value === 'undefined') {
            this.state.stepPattern[channel][step] = !this.state.stepPattern[channel][step];
          } else {
            this.state.stepPattern[channel][step] = !!value;
          }
        }
        break;
      }
      case 'setPattern': {
        const { channel, pattern } = payload;
        if (this.state.stepPattern && this.state.stepPattern[channel]) {
          this.state.stepPattern[channel] = pattern.slice();
        }
        break;
      }
      case 'addClip':
        this.state.clips.push(payload.clip);
        break;
      case 'removeClip':
        this.state.clips = this.state.clips.filter((c) => c.id !== payload.clipId);
        break;
      default:
        break;
    }
    // Notify listeners
    for (const listener of this.listeners) {
      try {
        listener();
      } catch (err) {
        console.error(err);
      }
    }
  }

  /**
   * Subscribe to state changes.  Returns an unsubscribe function.
   */
  subscribe(fn) {
    this.listeners.push(fn);
    return () => this.unsubscribe(fn);
  }

  /**
   * Remove a previously added listener.
   */
  unsubscribe(fn) {
    this.listeners = this.listeners.filter((l) => l !== fn);
  }
}