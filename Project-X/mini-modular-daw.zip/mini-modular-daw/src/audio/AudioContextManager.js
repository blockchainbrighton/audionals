/*
 * AudioContextManager
 *
 * This class wraps Tone.js' global Transport and manages starting and stopping
 * the audio context.  Browsers require a user gesture to begin audio
 * playback, so the `start()` method must be called from a UI event handler.
 *
 * It exposes a simple event emitter API so interested parties can react
 * whenever the transport starts, stops or the tempo changes.  All Tone.js
 * calls are pulled from the global `Tone` object rather than imported so
 * that the same code works both in the browser (where Tone is loaded via
 * importmap) and in Node tests (where Tone is stubbed on `globalThis`).
 */

export default class AudioContextManager {
  constructor() {
    this._listeners = [];
    this._started = false;
  }

  /**
   * Initialize the transport with a starting BPM.  Calling this will not
   * start audio; it merely configures the transport.  You should call
   * `start()` in response to a user gesture to unlock the audio context.
   *
   * @param {number} bpm The initial beats‑per‑minute value.
   */
  init(bpm = 120) {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    Tone.Transport.bpm.value = bpm;
    this._emit({ type: 'bpm', payload: bpm });
  }

  /**
   * Start the audio context and begin the transport.  Returns a promise
   * because Tone.start() is asynchronous.  Once resolved, the transport
   * will be running and subscribers will receive a `'running'` event.
   */
  async start() {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    // If already started, do nothing
    if (this._started) return;
    await Tone.start();
    Tone.Transport.start();
    this._started = true;
    this._emit({ type: 'running' });
  }

  /**
   * Stop the transport.  Does not reset the transport time; use Tone.Transport
   * methods directly if you need to rewind.
   */
  stop() {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    Tone.Transport.stop();
    this._started = false;
    this._emit({ type: 'stopped' });
  }

  /**
   * Set the BPM on the transport.  Emits a `'bpm'` event for listeners.
   *
   * @param {number} bpm The new tempo.
   */
  setBpm(bpm) {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    Tone.Transport.bpm.value = bpm;
    this._emit({ type: 'bpm', payload: bpm });
  }

  /**
   * Get the current time from Tone.js.  Falls back to the transport's
   * seconds property if Tone.now is not available (for stubs).
   */
  now() {
    const Tone = globalThis.Tone;
    if (!Tone) return 0;
    if (typeof Tone.now === 'function') {
      return Tone.now();
    }
    if (Tone.Transport && typeof Tone.Transport.seconds === 'number') {
      return Tone.Transport.seconds;
    }
    return 0;
  }

  /**
   * Expose the Tone.Transport for advanced usage.  Tests rely on this
   * accessor to stub out scheduling functions.
   */
  getTransport() {
    const Tone = globalThis.Tone;
    return Tone ? Tone.Transport : null;
  }

  /**
   * Register an event listener.  Listeners are called with objects
   * containing `{type, payload?}` fields.
   *
   * @param {Function} listener
   */
  on(listener) {
    this._listeners.push(listener);
  }

  /**
   * Internal helper to emit events to all listeners.
   *
   * @param {Object} evt The event object.
   */
  _emit(evt) {
    for (const listener of this._listeners) {
      try {
        listener(evt);
      } catch (err) {
        // swallow listener errors so others still receive events
        console.error(err);
      }
    }
  }
}