/*
 * SynthFactory
 *
 * Creates common synthesiser types using Tone.js.  Synth types supported
 * include:
 *   - 'synth': a basic monosynth (Tone.Synth)
 *   - 'fm': an FM synthesiser (Tone.FMSynth)
 *   - 'am': an AM synthesiser (Tone.AMSynth)
 *   - 'poly': a polyphonic synthesiser built from Tone.Synth instances
 *
 * Each call returns an object containing the underlying synth and thin
 * wrappers around the trigger methods.  These wrappers mirror the Tone.js
 * API but allow easy substitution in tests.
 */

export default class SynthFactory {
  /**
   * Create a synth of the given type.  All synths are connected to the
   * Tone.js master output by default.
   *
   * @param {string} type One of 'synth', 'fm', 'am', or 'poly'.
   * @returns {Object} An object with the synth and trigger helpers.
   */
  static createSynth(type = 'synth') {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    let synth;
    switch (type) {
      case 'fm':
        synth = new Tone.FMSynth();
        break;
      case 'am':
        synth = new Tone.AMSynth();
        break;
      case 'poly':
        synth = new Tone.PolySynth(Tone.Synth);
        break;
      case 'synth':
      default:
        synth = new Tone.Synth();
        break;
    }
    synth.toDestination();
    return {
      synth,
      /** Trigger the attack portion of a note. */
      triggerAttack: (note, time, velocity) => {
        return synth.triggerAttack(note, time, velocity);
      },
      /** Trigger the release portion of a note. */
      triggerRelease: (note, time) => {
        return synth.triggerRelease(note, time);
      },
      /** Trigger a note for a specific duration. */
      triggerAttackRelease: (note, duration, time, velocity) => {
        return synth.triggerAttackRelease(note, duration, time, velocity);
      },
    };
  }
}