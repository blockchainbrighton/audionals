/*
 * SampleLoader
 *
 * Provides convenience methods for loading single or multisample instruments
 * using Tone.js.  A simple in‑memory cache stores previously loaded players
 * keyed by their URL so that subsequent requests do not fetch or decode
 * again.  Multi‑sample instruments return a Tone.Sampler instance.
 */

export default class SampleLoader {
  constructor() {
    /**
     * Map of URL → Tone.Player.  We reuse players when the same URL is
     * requested again.  Tone.js buffers each player internally, so sharing
     * the player avoids multiple decodes.
     */
    this._cache = new Map();
  }

  /**
   * Load a single audio sample.  Returns a Promise which resolves with a
   * Tone.Player.  Reuses cached players when available.
   *
   * @param {string} url URL to an audio file.
   * @returns {Promise<Object>} Resolves with a Tone.Player.
   */
  async loadSample(url) {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    if (this._cache.has(url)) {
      return this._cache.get(url);
    }
    return new Promise((resolve) => {
      const player = new Tone.Player(url, () => {
        this._cache.set(url, player);
        resolve(player);
      });
    });
  }

  /**
   * Load a multi‑sample instrument mapping into a Tone.Sampler.  The mapping
   * should be an object where the keys are note names and the values are
   * relative or absolute URLs.  Returns a Promise which resolves with the
   * loaded Sampler.
   *
   * @param {Object} mapping An object of note→url pairs.
   * @returns {Promise<Object>} Resolves with a Tone.Sampler instance.
   */
  async loadMultiSample(mapping) {
    const Tone = globalThis.Tone;
    if (!Tone) throw new Error('Tone.js must be available on globalThis');
    return new Promise((resolve) => {
      const sampler = new Tone.Sampler(mapping, () => {
        resolve(sampler);
      });
    });
  }
}