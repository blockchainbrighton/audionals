**Badge links for Audionauts**

**45 Unique Badge Image URLS**
**Badges have rough rarity values written in text**
---

**Original Audionals Inscription --COMMON**
[https://ordinals.com/content/40136786a9eb1020c87f54c63de1505285ec371ff35757b44d2cc57dbd932f22i0](https://ordinals.com/content/40136786a9eb1020c87f54c63de1505285ec371ff35757b44d2cc57dbd932f22i0)

**Original Audionals Inscription - AI ORIGINAL --ULTRA RARE (Only one in whole collection)**
[https://ordinals.com/content/129ffaa02e85dea60fed32b84cd31436ccba1ff5b534fcb0b4efdddd2a0ddd05i0](https://ordinals.com/content/129ffaa02e85dea60fed32b84cd31436ccba1ff5b534fcb0b4efdddd2a0ddd05i0)


**3rd Party Audionals Logo I found --RARE**
[https://ordinals.com/content/72389b804f1f673caf52fea6e8f0733058b5605c879bea1938aa680f67fbe141i0](https://ordinals.com/content/72389b804f1f673caf52fea6e8f0733058b5605c879bea1938aa680f67fbe141i0)

---
**Based.btc OB1 --RARE**
[https://ordinals.com/content/e716f0e3832dbdd818f2291ad8cb0395f3bbec4f5ba762c05108a719842c9f6di0](https://ordinals.com/content/e716f0e3832dbdd818f2291ad8cb0395f3bbec4f5ba762c05108a719842c9f6di0)

---

**BAM LOGO -  --COMMON**
[https://ordinals.com/content/09b4bbb0337af857d9afa934205fb820bb704596a00f2e7f5bb37195853eee32i0](https://ordinals.com/content/09b4bbb0337af857d9afa934205fb820bb704596a00f2e7f5bb37195853eee32i0)
---

**Hathaway Bitcoin Logo - COMMON**
[https://ordinals.com/content/a1491d4b9c780799f53cd93fe0e5cad4ece52e1e638dd74de44fe74514f00bcfi0](https://ordinals.com/content/a1491d4b9c780799f53cd93fe0e5cad4ece52e1e638dd74de44fe74514f00bcfi0)

---

**Vikings - --COMMON**
[https://ordinals.com/content/3a504956f370c0362e48f7a1daf53d51c250c3c0d2054eb0b018d60caad0be77i0](https://ordinals.com/content/3a504956f370c0362e48f7a1daf53d51c250c3c0d2054eb0b018d60caad0be77i0)

---

**Nat Atlas - RARE**
[https://ordinals.com/content/515cfa9ca12ff4968b7f9b73cefdba1410ef6fcbf76868559c8b1b77ad13f497i0](https://ordinals.com/content/515cfa9ca12ff4968b7f9b73cefdba1410ef6fcbf76868559c8b1b77ad13f497i0)
[https://ordinals.com/content/16e4d2fae0ff944bb29a56f1c35ba5187207c4ada96d5b9c8f6cf3a1f618fb1di0](https://ordinals.com/content/16e4d2fae0ff944bb29a56f1c35ba5187207c4ada96d5b9c8f6cf3a1f618fb1di0)
<!-- [https://ordinals.com/content/54c993cd080be71ea859a9ada9946d1cac7390a2fce6636bea39e98ce5b47d71i0](https://ordinals.com/content/54c993cd080be71ea859a9ada9946d1cac7390a2fce6636bea39e98ce5b47d71i0) -->

---

**THIS IS #1** 

**Ordinals - Genesis Collection ULTRA RARE Only 1 of each in whole collection**

Channel #1 - #56330 - [https://ordinals.com/content/726fd43250acf6543273eab0e8a52db8df969af672107297f03b866424d8b0f4i0](https://ordinals.com/content/726fd43250acf6543273eab0e8a52db8df969af672107297f03b866424d8b0f4i0)
This Is Number One - #75140 - [https://ordinals.com/content/8d3c82c15a662cfe4b998e45bf8c71c00f16d532c5d4c546f59802e6f7730f3ei0](https://ordinals.com/content/8d3c82c15a662cfe4b998e45bf8c71c00f16d532c5d4c546f59802e6f7730f3ei0)
Number One Smiley - #75141 - [https://ordinals.com/content/0668de6cd3f66acc85063026232fa7c6da01666aeb6fec965d5c34ca093fda49i0](https://ordinals.com/content/0668de6cd3f66acc85063026232fa7c6da01666aeb6fec965d5c34ca093fda49i0)
Now Is Not Enough - #75017 - [https://ordinals.com/content/cc8b85b8984cd30a9e26c755e766bca8ce1a25fdefb813bc0fb2eb411fb67a0bi0](https://ordinals.com/content/cc8b85b8984cd30a9e26c755e766bca8ce1a25fdefb813bc0fb2eb411fb67a0bi0)
Mine - #74963 - [https://ordinals.com/content/f6cd2ba6f2f2e95c818cfb9f613ac5b246473d430de8a48e99686210ca9ef21fi0](https://ordinals.com/content/f6cd2ba6f2f2e95c818cfb9f613ac5b246473d430de8a48e99686210ca9ef21fi0)

---

**NarcotiX - COMMON once per timeline**
[https://ordinals.com/content/17627f1b267798eb488206cacfb55089b1b268885c3f136d6265547cb71c5b72i0](https://ordinals.com/content/17627f1b267798eb488206cacfb55089b1b268885c3f136d6265547cb71c5b72i0)

---

**HASH ONES - ULTRA RARE Only 1 of each in whole collection**

Hash One #92 - #68263 - [https://ordinals.com/content/fba6c1abe4c6d7e8f654da1fe6550e4110c6c3b5c4899cb91ad9ef88dbed96eci0](https://ordinals.com/content/fba6c1abe4c6d7e8f654da1fe6550e4110c6c3b5c4899cb91ad9ef88dbed96eci0)
Hash One #93 - #72619 - [https://ordinals.com/content/020d36560a95677d12845ade78c5ea59a3903d8c3e14953f407fb12f229be71bi0](https://ordinals.com/content/020d36560a95677d12845ade78c5ea59a3903d8c3e14953f407fb12f229be71bi0)
Hash One #94 - #72621 - [https://ordinals.com/content/88f7e4621dcaa8207f6eb39791001afe2fee2ede36c9f2372705b813002a5530i0](https://ordinals.com/content/88f7e4621dcaa8207f6eb39791001afe2fee2ede36c9f2372705b813002a5530i0)
Hash One #95 - #72640 - [https://ordinals.com/content/f3dc74d01e07d6a88cf30fc1a6acf53d3f73517b3861a8949fa50f6114dc1bfai0](https://ordinals.com/content/f3dc74d01e07d6a88cf30fc1a6acf53d3f73517b3861a8949fa50f6114dc1bfai0)
Hash One #96 - #73968 - [https://ordinals.com/content/542faa1be5014212bdf57a7afd41eb878dfcc4332a3718f23e7d1d8604f0c7c2i0](https://ordinals.com/content/542faa1be5014212bdf57a7afd41eb878dfcc4332a3718f23e7d1d8604f0c7c2i0)
Hash One #97 - #73959 - [https://ordinals.com/content/8a312ad605ce2a15d59f7714e3b7b0fe77ca1aeaa8b68376569ccf2bf2105f5ci0](https://ordinals.com/content/8a312ad605ce2a15d59f7714e3b7b0fe77ca1aeaa8b68376569ccf2bf2105f5ci0)
Hash One #98 - #73948 - [https://ordinals.com/content/d5243217dd0a214ed7dd17b71d35bdc68fae854a191dfcf740a32aa5a7880610i0](https://ordinals.com/content/d5243217dd0a214ed7dd17b71d35bdc68fae854a191dfcf740a32aa5a7880610i0)
Hash One #99 - #73936 - [https://ordinals.com/content/f7ed8da190670f462b7e1193a228c5daf07cddd89103d72a7d1ca3adcc05c62bi0](https://ordinals.com/content/f7ed8da190670f462b7e1193a228c5daf07cddd89103d72a7d1ca3adcc05c62bi0)
Hash One #100 - #73866 - [https://ordinals.com/content/ad77943f52877acac2a08410ac41f5ae1e56d4ccb2b82c1accf4ef1cb7038c1fi0](https://ordinals.com/content/ad77943f52877acac2a08410ac41f5ae1e56d4ccb2b82c1accf4ef1cb7038c1fi0)
Hash One #101 - #73878 - [https://ordinals.com/content/e2c683f6ec6c0b71808b05527a136627c49cd996ae3fd5970d18329ee28a56a8i0](https://ordinals.com/content/e2c683f6ec6c0b71808b05527a136627c49cd996ae3fd5970d18329ee28a56a8i0)
Hash One #102 - #73935 - [https://ordinals.com/content/89f92c9916b542314781f821cacb670722f38e21f5994e9dce9f7c7e9926a520i0](https://ordinals.com/content/89f92c9916b542314781f821cacb670722f38e21f5994e9dce9f7c7e9926a520i0)
Hash One #103 - #73956 - [https://ordinals.com/content/8816cdd828135675fdf5146a658823a9bae98a67da55a930483a1db21bf6c235i0](https://ordinals.com/content/8816cdd828135675fdf5146a658823a9bae98a67da55a930483a1db21bf6c235i0)
Hash One #104 - #74570 - [https://ordinals.com/content/b0958c0c68430291c2f1b1fbd7c98624cb78991c03855a1319d4bf29c7cc2372i0](https://ordinals.com/content/b0958c0c68430291c2f1b1fbd7c98624cb78991c03855a1319d4bf29c7cc2372i0)
Hash One #105 - #74578 - [https://ordinals.com/content/c785aa38f6dd2461be35c63b7f1849b2d4caf027b1d05fa3986e515ea0130fc6i0](https://ordinals.com/content/c785aa38f6dd2461be35c63b7f1849b2d4caf027b1d05fa3986e515ea0130fc6i0)
Hash One #106 - #74566 - [https://ordinals.com/content/31281b871fb6e16df8f57aa734092fab82de62611a83c15c7cfe8e695559ad59i0](https://ordinals.com/content/31281b871fb6e16df8f57aa734092fab82de62611a83c15c7cfe8e695559ad59i0)
Hash One #107 - #74631 - [https://ordinals.com/content/425210e56972ba2adc1c05e980e5275eae1241c7a75a16f08e04bc464863bc74i0](https://ordinals.com/content/425210e56972ba2adc1c05e980e5275eae1241c7a75a16f08e04bc464863bc74i0)
Hash One #108 - #74651 - [https://ordinals.com/content/3a270ee2ecdacf6d8bb8e62f285f3e3487fdfd028169fccc62d5ba0cbeab219ci0](https://ordinals.com/content/3a270ee2ecdacf6d8bb8e62f285f3e3487fdfd028169fccc62d5ba0cbeab219ci0)
Hash One #109 - #74643 - [https://ordinals.com/content/57cac42c8bbb018e3dbc066f23669422c655166a47ce72ccccc2dc0f5a63488ei0](https://ordinals.com/content/57cac42c8bbb018e3dbc066f23669422c655166a47ce72ccccc2dc0f5a63488ei0)
Hash One #110 - #74608 - [https://ordinals.com/content/777232a28c83a5ccf908fb6913c44b3f95405e8a7ec83358b3db330f30a7b435i0](https://ordinals.com/content/777232a28c83a5ccf908fb6913c44b3f95405e8a7ec83358b3db330f30a7b435i0)
Hash One #111 - #74569 - [https://ordinals.com/content/067982e5ea64a2a8d1f226318e4c0714e99a0e3e6114f9d1a0f4a4642dc7b871i0](https://ordinals.com/content/067982e5ea64a2a8d1f226318e4c0714e99a0e3e6114f9d1a0f4a4642dc7b871i0)

---



**DO WE ADD SQYZY ARTWORKS?**
Sqyzy -  X

# 130573 - I - [https://ordinals.com/content/bfd05a40892d872c033994d2375c6382eb90789db6739a7b18f7246a396f5a3di0](https://ordinals.com/content/bfd05a40892d872c033994d2375c6382eb90789db6739a7b18f7246a396f5a3di0)

# 130596 - II - [https://ordinals.com/content/5a2b8214a9411c62bed0acb1f1f0b296bf049da181178120311520f25254c365i0](https://ordinals.com/content/5a2b8214a9411c62bed0acb1f1f0b296bf049da181178120311520f25254c365i0)

# 130609 - III - [https://ordinals.com/content/fe22987aae2d261c1848c0e69f571ad605aa5f1f7e03ab8ae460436919da837ai0](https://ordinals.com/content/fe22987aae2d261c1848c0e69f571ad605aa5f1f7e03ab8ae460436919da837ai0)

# 130558 - IV - [https://ordinals.com/content/a3e850c3070f255d08b86b334000e35bb2af101c61e0a871d1e6a1b9c41a5322i0](https://ordinals.com/content/a3e850c3070f255d08b86b334000e35bb2af101c61e0a871d1e6a1b9c41a5322i0)

# 130650 - V - [https://ordinals.com/content/06f24846f17ed13bc54db280209ad6e8cd3b9db46839cd5109920d24090ad7aai0](https://ordinals.com/content/06f24846f17ed13bc54db280209ad6e8cd3b9db46839cd5109920d24090ad7aai0)

# 130645 - VI - [https://ordinals.com/content/24b8261d1560ecbfdc8fa43c60b8fe9f79150f19e021b476fc605c3962ae78a2i0](https://ordinals.com/content/24b8261d1560ecbfdc8fa43c60b8fe9f79150f19e021b476fc605c3962ae78a2i0)

# 130610 - VII - [https://ordinals.com/content/5c67ed83db55258aad2d4aa18e80693b4002d5ac0e555928666deeb12692fa80i0](https://ordinals.com/content/5c67ed83db55258aad2d4aa18e80693b4002d5ac0e555928666deeb12692fa80i0)

# 130658 - VIII - [https://ordinals.com/content/7027ca7504d5767930a7e90cdfd8b0553c2a5133fe5fcdf5887dc0311e9486bci0](https://ordinals.com/content/7027ca7504d5767930a7e90cdfd8b0553c2a5133fe5fcdf5887dc0311e9486bci0)

# 130692 - IX - [https://ordinals.com/content/57b066a9d5769be2a64fd74e1941e35c034b5265d42e3a868615980aa576a371i0](https://ordinals.com/content/57b066a9d5769be2a64fd74e1941e35c034b5265d42e3a868615980aa576a371i0)

# 130694 - X - [https://ordinals.com/content/35349fc8e0badad460b6d7125fe2f833dcbec129a8064c9d7cd5e64172274325i0](https://ordinals.com/content/35349fc8e0badad460b6d7125fe2f833dcbec129a8064c9d7cd5e64172274325i0)

---

**COLLIDERS?**GIFs - May need update to work
Colliders

# 457195 - Lightning text - [https://ordinals.com/content/e9e5f4862c1e486d07b4bb91c5b85edf8d044e0c0cdd1b235959be8bd49355d6i0](https://ordinals.com/content/e9e5f4862c1e486d07b4bb91c5b85edf8d044e0c0cdd1b235959be8bd49355d6i0)

# 457953 - Colliders Character Sheet - [https://ordinals.com/content/248e46f24ea63968aef2bcd1a58e7b97d1cf5e7260be5802f5765567f0d17df4i0](https://ordinals.com/content/248e46f24ea63968aef2bcd1a58e7b97d1cf5e7260be5802f5765567f0d17df4i0)

---

**PUNX?** GIFs - May need update to work

# 512517 - PUNX LOGO HI-RES - [https://ordinals.com/content/c2beb99dbc32188e56ea2ca3750c99a6ce9145892678473b51802ce680cb5f16i0](https://ordinals.com/content/c2beb99dbc32188e56ea2ca3750c99a6ce9145892678473b51802ce680cb5f16i0)

# 641577 - PUNX LOGO PIXEL RES - [https://ordinals.com/content/c9d39d2aef6f2f3d744b2e8e5aab9fb11ba65274e8d19aef777c21f264426b71i0](https://ordinals.com/content/c9d39d2aef6f2f3d744b2e8e5aab9fb11ba65274e8d19aef777c21f264426b71i0)

# 457885 - PUNX #1 - [https://ordinals.com/content/4e38c53382a55659ef518fe9385f807fc5b827fe99f0854ff0d2a22a0a78b175i0](https://ordinals.com/content/4e38c53382a55659ef518fe9385f807fc5b827fe99f0854ff0d2a22a0a78b175i0)


**Solemn - All Animations - Might need work**
[https://ordinals.com/content/2c762a593dc60bcd92169b07de5a60d588a94819d165178ca317d45e4eeb2b11i0](https://ordinals.com/content/2c762a593dc60bcd92169b07de5a60d588a94819d165178ca317d45e4eeb2b11i0)
[https://ordinals.com/content/3ff701e8197231883785902d1076ffa747b28f951a0dbe2445ba2690df134575i0](https://ordinals.com/content/3ff701e8197231883785902d1076ffa747b28f951a0dbe2445ba2690df134575i0)
[https://ordinals.com/content/810350843b5011b0cd78ebf2134fb7df751f584d1c5eeaf578d214adb020b329i0](https://ordinals.com/content/810350843b5011b0cd78ebf2134fb7df751f584d1c5eeaf578d214adb020b329i0)
[https://ordinals.com/content/566ac7f4fe8cc5e41513f2e15aa376eb77d0883dc211a64f249e5145746957b0i0](https://ordinals.com/content/566ac7f4fe8cc5e41513f2e15aa376eb77d0883dc211a64f249e5145746957b0i0)

---



---

**I love Cheese player - Might not work:** --HTML FORMAT
[https://ordinals.com/content/38c24932ff414e5dd03b728338243389ea80edfcd19dd7430950630f2622f5ffi0](https://ordinals.com/content/38c24932ff414e5dd03b728338243389ea80edfcd19dd7430950630f2622f5ffi0)

**Audionals Pump Player - Might not work** --HTML FORMAT
[https://ordinals.com/content/20c939e91ac29bff0d96ecb1f567beb25a6ee80462c5a6927cd2acae8cb41fedi0](https://ordinals.com/content/20c939e91ac29bff0d96ecb1f567beb25a6ee80462c5a6927cd2acae8cb41fedi0)

---



More IDS that might need updates to work:

Chordinal #1
aa43e0a7d229f460c6f9310e938ae8ec50a26f5b09df1f6d801d9e8a8741afc3i0
