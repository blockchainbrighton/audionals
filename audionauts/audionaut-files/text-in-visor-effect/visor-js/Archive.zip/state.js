// visor-js/state.js
export const PLAYBACK_STATE = {
    running: false
  };
  