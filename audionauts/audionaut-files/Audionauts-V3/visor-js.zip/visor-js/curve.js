// visor-js/curve.js
export const curve = (t, e, o) => o * (1 - 4 * (t / e - .5) ** 2);
