There is a clock problem
The synth was originally set uo as a standalone synth and now there are issues with two clocks when it is in the sequencer
The Synth Needs to have a slave mode where all time is handed to the sequencer with an allowance to still play its own stored note arrays etc but timing MUST be streamlined and synced to the master clock when the synth is in the sequencer.