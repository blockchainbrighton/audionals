import * as core from './pixelCore.js';
import * as ui from './pixelUI.js';
import * as text from './pixelText.js';
import * as scroll from './scrollLayer.js';

// Utility selector
const $ = ui.$;

let scrollInterval = null;

function stopScrollText() {
  if (scrollInterval) clearInterval(scrollInterval);
  scrollInterval = null;
  $('#scrollText').textContent = "Scroll";
  scroll.clearScrollLayer();
}

function startScrollText() {
  stopScrollText();
  const textVal = $('#textInput').value.trim();
  if (!textVal) return;
  $('#scrollText').textContent = "Stop";
  const buf = scroll.makeTextColorBuffer(textVal, core.letterScale, core.letterColorHex);
  let frame = 0;
  const visorWidth = core.visorRight - core.visorLeft + 1;
  const maxFrame = Math.max(1, buf[0].length - visorWidth);
  const doScroll = () => {
    scroll.renderScrollToLayer(buf, frame);
    frame = (frame + 1) % maxFrame;
  };
  doScroll();
  scrollInterval = setInterval(doScroll, +$('#scrollSpeed').value);
}

function bindUI() {
  // Canvas controls
  $('#clearCanvas').onclick = () => {
    core.clearArr(core.gridArray);
    core.clearArr(core.originalArray);
    ui.drawGrid();
    core.pushUndo();
    ui.updateArrayDisplay();
  };
  $('#undoBtn').onclick = () => {
    if (core.popUndo) core.popUndo();
    ui.drawGrid();
    ui.updateArrayDisplay();
  };
  $('#latchToggle').onclick = () => {
    core.latchMode = !core.latchMode;
    $('#latchToggle').classList.toggle('on', core.latchMode);
    $('#latchToggle').textContent = core.latchMode ? 'Latch: On' : 'Latch: Off';
  };

  $('#scrollText').onclick = function () {
    if (scrollInterval) {
      stopScrollText();
    } else {
      startScrollText();
    }
  };
  $('#scrollSpeed').oninput = function () {
    if (scrollInterval) {
      stopScrollText();
      startScrollText();
    }
  };
  $('#placeText').onclick = () => {
    stopScrollText();
    const textVal = $('#textInput').value.trim();
    if (textVal) text.insertLetter(textVal, core.letterScale);
  };

  // Project save/load
  $('#saveProject').onclick = () => {
    const blob = new Blob([core.serialiseProject()], { type: 'application/json' });
    const a = document.createElement('a');
    const ts = new Date().toISOString().replace(/[:T]/g, '-').slice(0, 19);
    a.href = URL.createObjectURL(blob);
    a.download = `pixelart-${ts}.pxproj`;
    a.click();
    URL.revokeObjectURL(a.href);
  };
  $('#loadProjectBtn').onclick = () => $('#projectLoader').click();
  $('#projectLoader').onchange = e => {
    const f = e.target.files[0];
    if (!f) return;
    const r = new FileReader();
    r.onload = evt => {
      try {
        if (core.loadProjectObj) {
          core.loadProjectObj(JSON.parse(evt.target.result));
        } else if (core.loadProject) {
          core.loadProject(evt.target.result);
        }
        ui.createColorButtons();
        ui.setupUserColorsUI();
        ui.drawGrid();
        core.pushUndo();
      } catch (e) {
        alert('Could not load project: ' + e);
      }
      e.target.value = '';
    };
    r.readAsText(f);
  };

  // --- Load Array (.txt/.rtf) ---
  $('#loadArrayBtn').onclick = () => $('#arrayLoader').click();
  $('#arrayLoader').onchange = e => {
    const file = e.target.files[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = evt => {
      let loaded = false;
      if (core.loadArrayFromText) {
        core.loadArrayFromText(evt.target.result);
        loaded = true;
      } else if (ui.loadArrayFromText) {
        ui.loadArrayFromText(evt.target.result);
        loaded = true;
      }
      if (!loaded) {
        alert('No loadArrayFromText function found in core or ui!');
        return;
      }
      ui.createColorButtons();
      ui.setupUserColorsUI();
      ui.drawGrid();
      core.pushUndo();
      e.target.value = '';
    };
    reader.readAsText(file);
  };

  // --- Text Size, Place, Scroll controls ---
  document.querySelectorAll('[data-size]').forEach(btn => {
    btn.onclick = () => {
      core.letterScale = +btn.dataset.size;
      $('#textSizeValue').textContent = btn.dataset.size;
      document.querySelectorAll('[data-size]').forEach(b => b.classList.toggle('selected', +b.dataset.size === +btn.dataset.size));
      $('#textSizeSlider').value = btn.dataset.size;
    };
  });
  $('#textSizeSlider').oninput = e => {
    core.letterScale = +e.target.value;
    $('#textSizeValue').textContent = e.target.value;
    document.querySelectorAll('[data-size]').forEach(btn =>
      btn.classList.toggle('selected', +btn.dataset.size === +e.target.value));
  };

  // --- Scroll / Stop Scroll Text ---
  $('#scrollText').onclick = function () {
    // End scroll if running
    if (scrollInterval) {
      clearInterval(scrollInterval);
      scrollInterval = null;
      this.textContent = "Scroll";
      if (ui.clearScrollLayer) ui.clearScrollLayer();
      return;
    }
    // Start scrolling
    const textVal = $('#textInput').value.trim();
    if (!textVal) return;
    this.textContent = "Stop";
    const buf = scroll.makeTextColorBuffer(textVal, core.letterScale, core.letterColorHex);
    let frame = 0;
    const visorWidth = core.visorRight - core.visorLeft + 1;
    const maxFrame = Math.max(1, buf[0].length - visorWidth);
    const doScroll = () => {
      if (ui.renderScrollToLayer) ui.renderScrollToLayer(buf, frame);
      frame = (frame + 1) % maxFrame;
    };
    doScroll();
    scrollInterval = setInterval(doScroll, +$('#scrollSpeed').value);
  };
  $('#scrollSpeed').oninput = function () {
    if (scrollInterval) {
      $('#scrollText').click(); // stop
      $('#scrollText').click(); // restart with new speed
    }
  };

  // --- Place Text (ends scroll) ---
  $('#placeText').onclick = () => {
    if (scrollInterval) {
      clearInterval(scrollInterval);
      scrollInterval = null;
      $('#scrollText').textContent = "Scroll";
      if (ui.clearScrollLayer) ui.clearScrollLayer();
    }
    const textVal = $('#textInput').value.trim();
    if (textVal) text.insertLetter(textVal, core.letterScale);
  };

  // --- Array export (copy, PNG, SVG, RTF) ---
  $('#arrayCopyBtn').onclick = () => {
    $('#arrayDataOutput').select();
    document.execCommand('copy');
  };
  $('#downloadPNG').onclick = () => {
    const canvas = document.createElement('canvas');
    canvas.width = core.SIZE; canvas.height = core.SIZE;
    const ctx = canvas.getContext('2d'), imgData = ctx.createImageData(core.SIZE, core.SIZE);
    for (let r = 0; r < core.SIZE; r++) for (let c = 0; c < core.SIZE; c++) {
      const i = (r * core.SIZE + c) * 4, idx = core.gridArray[r][c], col = core.palette[idx];
      if (idx === 0) imgData.data[i + 3] = 0;
      else imgData.data[i] = col[0], imgData.data[i + 1] = col[1], imgData.data[i + 2] = col[2], imgData.data[i + 3] = 255;
    }
    ctx.putImageData(imgData, 0, 0);
    const link = document.createElement('a');
    link.download = 'pixelart.png'; link.href = canvas.toDataURL('image/png'); link.click();
  };
  $('#downloadSVG').onclick = () => {
    let svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${core.SIZE}" height="${core.SIZE}" shape-rendering="crispEdges" style="background:none">`;
    for (let y = 0; y < core.SIZE; y++) for (let x = 0; x < core.SIZE; x++) {
      const idx = core.gridArray[y][x], c = core.palette[idx];
      if (idx) svg += `<rect x="${x}" y="${y}" width="1" height="1" fill="rgb(${c[0]},${c[1]},${c[2]})"/>`;
    }
    svg += '</svg>';
    const blob = new Blob([svg], { type: 'image/svg+xml' }), link = document.createElement('a');
    link.download = 'pixelart.svg'; link.href = URL.createObjectURL(blob); link.click(); URL.revokeObjectURL(link.href);
  };

  // --- Save Array as RTF ---
  $('#saveArrayRTF').onclick = function () {
    const arr = $('#arrayDataOutput').value.trim();
    if (!arr) return alert('No array data to save!');
    const rtf = `{\\rtf1\\ansi\\deff0{\\fonttbl{\\f0\\fnil\\fcharset0 Consolas;}}\\fs20\\f0 ${arr.replace(/[\n\r]+/g, '\\line ')} }`;
    const blob = new Blob([rtf], { type: "application/rtf" });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = 'pixelart-array.rtf';
    a.click();
    URL.revokeObjectURL(a.href);
  };

  // --- Block right-click default context menu on grid ---
  document.addEventListener('contextmenu', e => e.preventDefault());
}

// App startup
document.addEventListener("DOMContentLoaded", () => {
    ui.buildGrid();
    ui.setupUserColorsUI();
    ui.createColorButtons();
    ui.drawGrid();
    scroll.initScrollLayer(); // <--- Add this
    bindUI();
  });
